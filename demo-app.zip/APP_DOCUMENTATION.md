# Bank Account Linking Experience - Application Documentation

## Table of Contents
1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Theming System](#theming-system)
4. [Application Flow](#application-flow)
5. [Component Library](#component-library)
6. [Data Models](#data-models)
7. [Integration Guide](#integration-guide)
8. [Development Setup](#development-setup)
9. [Deployment](#deployment)
10. [Security Considerations](#security-considerations)

## Overview

The Bank Account Linking Experience is a comprehensive React application built for financial institutions to provide a seamless account linking process. The application features a sophisticated theming system, multiple authentication flows, and responsive design that can be embedded in various client environments.

### Key Features
- **Multi-theme Support**: Customizable branding for different financial institutions
- **Multiple Auth Flows**: OAuth, legacy username/password, and manual connection methods
- **Responsive Design**: Works across desktop, tablet, and mobile devices
- **iframe Integration**: Can be embedded in client applications
- **Comprehensive Flow**: From consent to successful account linking
- **Mock Data**: Complete simulation environment for development and demo

### Technology Stack
- **Frontend Framework**: React 19.1.1 with TypeScript 4.9.5
- **UI Framework**: Salt Design System (@salt-ds/core, @salt-ds/icons, @salt-ds/lab)
- **Routing**: React Router DOM 7.8.2
- **Build Tool**: Create React App 5.0.1
- **CSS**: CSS Modules and CSS Custom Properties
- **Font System**: Open Sans via @fontsource

## Architecture

### Project Structure
```
hosted-demo/
├── public/
│   ├── index.html              # Main HTML template
│   ├── oauth/
│   │   └── callback.html       # OAuth callback handler
│   └── manifest.json           # PWA manifest
├── src/
│   ├── App.tsx                 # Main application component
│   ├── components/             # UI components
│   ├── data/                   # Mock data and types
│   ├── theme/                  # Theming system
│   └── index.tsx              # Application entry point
└── package.json
```

### Component Architecture
The application follows a container-component pattern with clear separation of concerns:

- **App.tsx**: Main orchestrator managing flow state and routing
- **BrandingThemeProvider**: Theme context provider and CSS custom properties manager
- **Screen Components**: Individual flow steps (Consent, FI Selection, OAuth, etc.)
- **Utility Components**: Reusable UI elements (ThemeSelector, etc.)

## Theming System

### Core Concept
The theming system is built around a comprehensive theme configuration that transforms client branding requirements into CSS custom properties, enabling dynamic styling without rebuilding the application.

### Theme Configuration Structure

```typescript
interface ClientTheme {
  name: string;
  colors: {
    primary: string;          // Main brand color
    secondary: string;        // Secondary brand color  
    accent: string;           // Accent/neutral color
    background: string;       // Main background
    surface: string;          // Card/surface background
    text: {
      primary: string;        // Main text color
      secondary: string;      // Secondary text color
      inverse: string;        // Inverse text (on dark backgrounds)
    };
    status: {
      success: string;        // Success state color
      warning: string;        // Warning state color
      error: string;          // Error state color
      info: string;           // Info state color
    };
  };
  typography: {
    fontFamily: string;       // Primary font family
    fontSize: {
      small: string;          // Small text (0.875rem)
      base: string;           // Base text (1rem)
      large: string;          // Large text (1.125rem)
      xlarge: string;         // Extra large text (1.25rem)
    };
    fontWeight: {
      normal: string;         // Normal weight (400)
      medium: string;         // Medium weight (500)
      semibold: string;       // Semibold weight (600)
      bold: string;           // Bold weight (700)
    };
  };
  spacing: {
    xs: string;               // Extra small spacing (0.25rem)
    sm: string;               // Small spacing (0.5rem)
    md: string;               // Medium spacing (1rem)
    lg: string;               // Large spacing (1.5rem)
    xl: string;               // Extra large spacing (2rem)
    xxl: string;              // Double extra large (3rem)
  };
  borderRadius: {
    sm: string;               // Small border radius
    md: string;               // Medium border radius
    lg: string;               // Large border radius
  };
  shadows: {
    sm: string;               // Small shadow
    md: string;               // Medium shadow
    lg: string;               // Large shadow
  };
}
```

### Available Themes

#### 1. JPMorgan Chase Theme (`jpmorgan`)
- **Primary Color**: #005CB9 (Corporate blue)
- **Font**: Open Sans
- **Style**: Professional, conservative banking aesthetic
- **Use Case**: Traditional banking institutions

#### 2. Fintech Modern Theme (`fintech`)
- **Primary Color**: #6366F1 (Modern purple)
- **Font**: Inter
- **Style**: Contemporary, tech-forward design
- **Use Case**: Fintech companies, modern digital banks

#### 3. Traditional Banking Theme (`banking`)
- **Primary Color**: #1E3A8A (Navy blue)
- **Font**: Source Sans Pro
- **Style**: Conservative, trustworthy appearance
- **Use Case**: Established banks, credit unions

### CSS Custom Properties
The theming system applies 40+ CSS custom properties that components can reference:

```css
/* Color Properties */
--brand-color-primary
--brand-color-secondary
--brand-color-accent
--brand-color-background
--brand-color-surface
--brand-color-text-primary
--brand-color-text-secondary
--brand-color-text-inverse
--brand-color-success
--brand-color-warning
--brand-color-error
--brand-color-info

/* Typography Properties */
--brand-font-family
--brand-font-size-small
--brand-font-size-base
--brand-font-size-large
--brand-font-size-xlarge
--brand-font-weight-normal
--brand-font-weight-medium
--brand-font-weight-semibold
--brand-font-weight-bold

/* Spacing Properties */
--brand-spacing-xs
--brand-spacing-sm
--brand-spacing-md
--brand-spacing-lg
--brand-spacing-xl
--brand-spacing-xxl

/* Border Radius Properties */
--brand-border-radius-sm
--brand-border-radius-md
--brand-border-radius-lg

/* Shadow Properties */
--brand-shadow-sm
--brand-shadow-md
--brand-shadow-lg
```

### BrandingThemeProvider
The `BrandingThemeProvider` component manages theme state and applies CSS custom properties:

```typescript
interface ThemeContextType {
  currentTheme: ClientTheme | null;
  themeName: ThemeName | 'salt';
  setTheme: (themeName: ThemeName | 'salt') => void;
  availableThemes: typeof availableThemes;
  isCustomThemeActive: boolean;
}
```

**Key Features**:
- Dynamic CSS custom property injection
- localStorage persistence
- PostMessage API for iframe integration
- Fallback to Salt Design System defaults
- Runtime theme switching

## Application Flow

### Flow States
The application manages user progression through these states:

1. **Consent Screen** (`consent`)
   - Purpose: Obtain user consent for account linking
   - Actions: Continue or Cancel
   - Next: FI Selection

2. **Financial Institution Selection** (`fiSelection`)
   - Purpose: Choose bank or financial institution
   - Features: Search, popular banks, manual entry
   - Actions: Select FI, Manual Connection, Back
   - Next: OAuth, Legacy Login, or Manual Connect

3. **Authentication Flows**:
   - **OAuth Screen** (`oauth`) - Modern banks with OAuth
   - **Legacy Login** (`legacyLogin`) - Username/password banks
   - **Manual Connect** (`manualConnect`) - Manual credential entry

4. **Account Selection** (`accountSelection`)
   - Purpose: Choose specific account to link
   - Features: Multiple account display, account details
   - Actions: Select account, Back
   - Next: Success

5. **Success Screen** (`success`)
   - Purpose: Confirm successful linking
   - Features: Account details, next steps, analytics
   - Actions: Close, Start Over

### State Management
The main App component uses React hooks for state management:

```typescript
const [currentStep, setCurrentStep] = useState<FlowStep>('consent');
const [selectedFI, setSelectedFI] = useState<any>(null);
const [linkedAccount, setLinkedAccount] = useState<BankAccount | null>(null);
const [oauthData, setOAuthData] = useState<OAuthSuccessData | null>(null);
```

### Flow Logic
The application determines authentication flow based on FI type:

```typescript
if (fi.type === 'legacy') {
  setCurrentStep('legacyLogin');
} else if (fi.type === 'fintech' || fi.type === 'investment' || 
           ['chase', 'bank_of_america', 'wells_fargo'].includes(fi.id)) {
  setCurrentStep('oauth');
} else {
  setCurrentStep('oauth'); // Default to OAuth
}
```

## Component Library

### Screen Components

#### ConsentScreen
- **Purpose**: Initial consent collection
- **Props**: `onContinue`, `onCancel`
- **Features**: Legal text, consent checkboxes, responsive design

#### FISelectorScreen  
- **Purpose**: Financial institution selection
- **Props**: `onFISelected`, `onBack`, `onManualConnection`
- **Features**: 
  - Search functionality across 70+ financial institutions
  - Popular banks display
  - Categorization (Banks, Credit Unions, Investment, Fintech, Legacy)
  - Responsive grid layout

#### OAuthScreen
- **Purpose**: OAuth authentication simulation
- **Props**: `selectedFI`, `onBack`, `onSuccess`, `onError`
- **Features**:
  - Realistic OAuth flow simulation
  - Error handling and retry logic
  - Loading states and progress indicators
  - Real-world bank branding simulation

#### LegacyLoginScreen
- **Purpose**: Username/password authentication
- **Props**: `onBack`, `onLogin`, `bankName`
- **Features**:
  - Form validation
  - Security messaging
  - Responsive form layout

#### ManualConnectScreen
- **Purpose**: Manual credential entry
- **Props**: `onBack`, `onConnect`
- **Features**:
  - Multi-field forms
  - Input validation
  - Help text and guidance

#### AccountSelectionScreen
- **Purpose**: Account type selection
- **Props**: `onBack`, `onAccountSelected`, `bankName`
- **Features**:
  - Multiple account types (checking, savings, credit)
  - Account details display
  - Balance information

#### SuccessScreen
- **Purpose**: Confirmation and completion
- **Props**: `onStartOver`, `onClose`, `selectedFI`, `linkedAccount`, `merchantId`, `onLinkingComplete`
- **Features**:
  - Success confirmation
  - Account summary
  - Analytics tracking
  - Next steps guidance
  - Integration callbacks

### Utility Components

#### ThemeSelector
- **Purpose**: Development theme switching
- **Props**: `className`, `showLabel`
- **Features**: 
  - Runtime theme switching
  - URL display for testing
  - Visual theme indicators

#### ClientDemo
- **Purpose**: Client demonstration page
- **Features**:
  - Theme comparison
  - Integration examples
  - URL generation for demos

### Form Components
Built on Salt Design System components with custom styling:

- **Text**: Typography with brand font families
- **Button**: Branded buttons with theme colors
- **Card**: Surfaces with theme shadows and borders
- **FlexLayout**: Responsive layout containers
- **Input**: Form inputs with validation
- **Badge**: Status and type indicators

## Data Models

### Financial Institution Model

```typescript
interface FinancialInstitution {
  id: string;                    // Unique identifier
  name: string;                  // Display name
  description?: string;          // Description text
  type: 'bank' | 'credit_union' | 'investment' | 'fintech' | 'legacy';
  logo?: string;                 // Logo URL
  isPopular?: boolean;           // Popular bank flag
  searchTerms: string[];         // Search keywords
}
```

### Bank Account Model

```typescript
interface BankAccount {
  id: string;                    // Account identifier
  accountName: string;           // Account display name
  accountNumber: string;         // Masked account number
  routingNumber: string;         // Bank routing number
  accountType: 'checking' | 'savings' | 'credit' | 'investment';
  balance?: number;              // Current balance
  currency?: string;             // Currency code
  isActive: boolean;             // Account status
}
```

### OAuth Data Models

```typescript
interface OAuthSuccessData {
  authCode: string;              // Authorization code
  state: string;                 // OAuth state parameter
  institutionId: string;         // FI identifier
  institutionName: string;       // FI name
  userId: string;                // User identifier
  accessToken?: string;          // Access token
  tokenType?: string;            // Token type
  expiresIn?: number;           // Token expiration
  refreshToken?: string;        // Refresh token
  scope?: string;               // Token scope
  timestamp: number;            // Success timestamp
}

interface OAuthError {
  error: string;                 // Error code
  errorDescription?: string;     // Error description
  errorUri?: string;            // Error documentation URL
  state?: string;               // OAuth state
  institutionId: string;        // FI identifier
  institutionName: string;      // FI name
  timestamp: number;            // Error timestamp
}
```

### Account Linking Details

```typescript
interface AccountLinkingDetails {
  accountId: string;             // Linked account ID
  institutionId: string;         // Financial institution ID
  institutionName: string;       // FI name
  accountName: string;           // Account display name
  accountType: string;           // Account type
  linkingMethod: 'oauth' | 'legacy' | 'manual';
  timestamp: number;             // Linking timestamp
  merchantId: string;            // Client merchant ID
  userId?: string;              // User identifier
  metadata?: Record<string, any>; // Additional data
}
```

## Integration Guide

### Basic Integration

```tsx
import React from 'react';
import { BrandingThemeProvider } from './theme';
import App from './App';

function ClientApp() {
  return (
    <BrandingThemeProvider initialTheme="jpmorgan">
      <App 
        showThemeSelector={false}
        clientId="client_merchant_123"
        mode="flow"
      />
    </BrandingThemeProvider>
  );
}

export default ClientApp;
```

### iframe Integration

```html
<!-- Parent page -->
<iframe 
  src="https://your-domain.com/bank-linking?theme=jpmorgan&clientId=client_123"
  width="100%" 
  height="600"
  frameborder="0"
  id="bank-linking-frame">
</iframe>

<script>
// Theme switching via postMessage
const frame = document.getElementById('bank-linking-frame');
frame.contentWindow.postMessage({
  type: 'SET_THEME',
  theme: 'fintech'
}, '*');
</script>
```

### URL Parameters

The application supports several URL parameters for configuration:

- `?theme=jpmorgan` - Set theme
- `?demo=true` - Show demo page
- `?clientId=abc123` - Set client identifier
- `?mode=flow` - Set application mode

### Event Integration

Listen for completion events:

```typescript
// In parent window
window.addEventListener('message', (event) => {
  if (event.data.type === 'ACCOUNT_LINKING_SUCCESS') {
    const linkingDetails = event.data.linkingDetails;
    console.log('Account linked:', linkingDetails);
    // Handle successful linking
  }
});
```

### Custom Theme Creation

1. Define theme configuration:

```typescript
export const myCustomTheme: ClientTheme = {
  name: 'custom-client',
  colors: {
    primary: '#your-primary-color',
    secondary: '#your-secondary-color',
    accent: '#your-accent-color',
    background: '#ffffff',
    surface: '#f8f9fa',
    text: {
      primary: '#212529',
      secondary: '#6c757d',
      inverse: '#ffffff',
    },
    status: {
      success: '#28a745',
      warning: '#ffc107',
      error: '#dc3545',
      info: '#17a2b8',
    },
  },
  typography: {
    fontFamily: "'Your Font', sans-serif",
    fontSize: {
      small: '0.875rem',
      base: '1rem',
      large: '1.125rem',
      xlarge: '1.25rem',
    },
    fontWeight: {
      normal: '400',
      medium: '500',
      semibold: '600',
      bold: '700',
    },
  },
  spacing: {
    xs: '0.25rem',
    sm: '0.5rem',
    md: '1rem',
    lg: '1.5rem',
    xl: '2rem',
    xxl: '3rem',
  },
  borderRadius: {
    sm: '0.25rem',
    md: '0.5rem',
    lg: '0.75rem',
  },
  shadows: {
    sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
    md: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
    lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
  },
};
```

2. Add to available themes:

```typescript
export const availableThemes = {
  jpmorgan: jpMorganTheme,
  fintech: fintechTheme,
  banking: bankingTheme,
  'custom-client': myCustomTheme,
} as const;
```

## Development Setup

### Prerequisites
- Node.js (v16+)
- npm or yarn package manager
- Modern web browser

### Installation

```bash
# Clone the repository
git clone [repository-url]
cd hosted-demo

# Install dependencies
npm install

# Start development server
npm start
```

### Development URLs
- **Main Flow**: http://localhost:3000
- **Demo Page**: http://localhost:3000?demo=true
- **Theme Testing**: 
  - http://localhost:3000?theme=jpmorgan
  - http://localhost:3000?theme=fintech
  - http://localhost:3000?theme=banking

### Available Scripts

```bash
# Development server
npm start

# Production build
npm run build

# Run tests
npm test

# Eject configuration (one-way)
npm run eject
```

### Development Workflow

1. **Component Development**: Create new components in `src/components/`
2. **Theme Updates**: Modify `src/theme/themeConfig.ts`
3. **Data Updates**: Update mock data in `src/data/mockBanks.ts`
4. **Styling**: Use CSS custom properties for theme-aware styling
5. **Testing**: Test across all available themes

## Deployment

### Build Process

```bash
# Create production build
npm run build

# Output directory: build/
# Contains optimized static files
```

### Deployment Options

#### Static Hosting
- **Netlify**: Connect repository for automatic deploys
- **Vercel**: Zero-config deployment with custom domains
- **AWS S3 + CloudFront**: Enterprise-grade static hosting
- **GitHub Pages**: Free hosting for public repositories

#### Docker Deployment

```dockerfile
FROM nginx:alpine
COPY build/ /usr/share/nginx/html/
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

#### Environment Configuration

Create `.env.production` file:

```bash
REACT_APP_API_BASE_URL=https://api.yourdomain.com
REACT_APP_OAUTH_CALLBACK_URL=https://yourdomain.com/oauth/callback
REACT_APP_CLIENT_ID=your-production-client-id
```

### Performance Optimization

1. **Code Splitting**: React.lazy() for component chunks
2. **Image Optimization**: Compress and serve optimal formats
3. **Font Loading**: Preload critical fonts
4. **Caching**: Configure cache headers for static assets
5. **CDN**: Use CDN for improved global performance

## Security Considerations

### Content Security Policy (CSP)
Implement strict CSP headers:

```http
Content-Security-Policy: 
  default-src 'self';
  style-src 'self' 'unsafe-inline' fonts.googleapis.com;
  font-src 'self' fonts.gstatic.com;
  script-src 'self';
  connect-src 'self' https://api.yourdomain.com;
```

### iframe Security
When embedding in iframes:

1. **Origin Validation**: Always validate postMessage origins
2. **Sandbox Attributes**: Use restrictive sandbox permissions
3. **HTTPS Only**: Enforce secure connections
4. **X-Frame-Options**: Control framing permissions

```typescript
// Validate postMessage origins
window.addEventListener('message', (event) => {
  const allowedOrigins = ['https://trusted-domain.com'];
  if (!allowedOrigins.includes(event.origin)) {
    return; // Ignore untrusted messages
  }
  // Process trusted message
});
```

### Data Protection

1. **No Sensitive Data Storage**: Never store credentials in localStorage
2. **Token Expiration**: Implement proper token lifecycle management
3. **Input Validation**: Sanitize all user inputs
4. **Error Handling**: Don't expose sensitive information in errors

### OAuth Security

1. **State Parameter**: Always use and validate OAuth state
2. **PKCE**: Implement Proof Key for Code Exchange when possible
3. **Secure Callbacks**: Validate callback URLs and parameters
4. **Token Storage**: Use secure, httpOnly cookies for tokens

### Production Checklist

- [ ] Remove development theme selector
- [ ] Implement proper error boundaries
- [ ] Add monitoring and logging
- [ ] Configure security headers
- [ ] Validate all environment variables
- [ ] Test iframe integration security
- [ ] Implement rate limiting
- [ ] Add accessibility testing
- [ ] Verify responsive design
- [ ] Test theme switching functionality

---

## Conclusion

This Bank Account Linking Experience application provides a comprehensive, themeable solution for financial account connection flows. The sophisticated theming system, robust component architecture, and flexible integration options make it suitable for a wide range of financial institutions and use cases.

For questions, issues, or contributions, please refer to the project repository documentation and issue tracking system.

**Version**: 1.0.0  
**Last Updated**: August 2025  
**Author**: Development Team
