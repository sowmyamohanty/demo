# Bank Account Linking - Theming System

This application includes a comprehensive theming system that allows for client-specific branding using the BrandingThemeProvider.

## Features

- **Multiple Pre-built Themes**: JPMorgan Chase, Modern Fintech, and Traditional Banking themes
- **CSS Custom Properties**: All theme values are applied as CSS custom properties for easy customization
- **URL-based Theme Selection**: Themes can be set via URL parameters for easy testing
- **PostMessage Integration**: Support for theme changes via iframe communication
- **Responsive Design**: All themes adapt to different screen sizes
- **Theme Persistence**: Selected themes are saved to localStorage

## Usage

### Basic Integration

```tsx
import { BrandingThemeProvider } from './theme';
import App from './App';

function MyApp() {
  return (
    <BrandingThemeProvider initialTheme="jpmorgan">
      <App showThemeSelector={false} />
    </BrandingThemeProvider>
  );
}
```

### Available Themes

1. **jpmorgan**: Traditional JPMorgan Chase branding with corporate blue colors
2. **fintech**: Modern fintech theme with purple accent colors  
3. **banking**: Conservative banking theme with navy blue colors

### URL Parameters

You can test different themes by adding URL parameters:

- `?theme=jpmorgan` - JPMorgan Chase theme
- `?theme=fintech` - Modern Fintech theme
- `?theme=banking` - Traditional Banking theme
- `?demo=true` - Show the client demo page

### Custom Theme Creation

To create a new theme, add it to the `themeConfig.ts` file:

```typescript
export const myCustomTheme: ClientTheme = {
  name: 'custom',
  colors: {
    primary: '#your-primary-color',
    secondary: '#your-secondary-color',
    // ... other color properties
  },
  typography: {
    fontFamily: "'Your Font', sans-serif",
    // ... other typography properties
  },
  // ... other theme properties
};

export const availableThemes = {
  jpmorgan: jpMorganTheme,
  fintech: fintechTheme,
  banking: bankingTheme,
  custom: myCustomTheme,
} as const;
```

### CSS Custom Properties

The theming system applies the following CSS custom properties:

#### Colors
- `--brand-color-primary`
- `--brand-color-secondary`
- `--brand-color-accent`
- `--brand-color-background`
- `--brand-color-surface`
- `--brand-color-text-primary`
- `--brand-color-text-secondary`
- `--brand-color-text-inverse`

#### Typography
- `--brand-font-family`
- `--brand-font-size-small`
- `--brand-font-size-base`
- `--brand-font-size-large`
- `--brand-font-size-xlarge`
- `--brand-font-weight-normal`
- `--brand-font-weight-medium`
- `--brand-font-weight-semibold`
- `--brand-font-weight-bold`

#### Spacing
- `--brand-spacing-xs`
- `--brand-spacing-sm`
- `--brand-spacing-md`
- `--brand-spacing-lg`
- `--brand-spacing-xl`
- `--brand-spacing-xxl`

#### Border Radius
- `--brand-border-radius-sm`
- `--brand-border-radius-md`
- `--brand-border-radius-lg`

#### Shadows
- `--brand-shadow-sm`
- `--brand-shadow-md`
- `--brand-shadow-lg`

### iframe Integration

For iframe integrations, you can send theme changes via postMessage:

```typescript
// From parent window
iframe.contentWindow.postMessage({
  type: 'SET_THEME',
  theme: 'fintech'
}, '*');
```

### Production Deployment

For production deployments:

1. Set `showThemeSelector={false}` to hide the theme selector
2. Set the `initialTheme` prop to the client's desired theme
3. Ensure proper Content Security Policy (CSP) headers
4. Validate message origins in iframe communication

## Development

To run the development server with theme testing:

```bash
npm start
```

Visit these URLs to test different themes:
- http://localhost:3000?theme=jpmorgan
- http://localhost:3000?theme=fintech
- http://localhost:3000?theme=banking
- http://localhost:3000?demo=true (for client demo page)

## Security Considerations

- Always validate message origins in production iframe integrations
- Use proper CSP headers to prevent XSS attacks
- Validate theme names before applying them
- Sanitize any user-provided styling data
