import React, { useState, useEffect } from 'react';
import { SaltProvider } from '@salt-ds/core';
import '@salt-ds/theme/index.css';
import '@fontsource/open-sans/300.css';
import '@fontsource/open-sans/400.css';
import '@fontsource/open-sans/500.css';
import '@fontsource/open-sans/600.css';
import '@fontsource/open-sans/700.css';
import { ConsentScreen, ThemeSelector, ClientDemo, FISelectorScreen, ManualConnectScreen, LegacyLoginScreen, AccountSelectionScreen, SuccessScreen, OAuthScreen, type BankCredentials, type LegacyLoginCredentials, type BankAccount, type AccountLinkingDetails, type OAuthSuccessData, type OAuthError } from './components';
import { BrandingThemeProvider, ThemeName, availableThemes } from './theme';
import './App.css';

type FlowStep = 'consent' | 'fiSelection' | 'oauth' | 'manualConnect' | 'legacyLogin' | 'authentication' | 'accountSelection' | 'success';
type AppMode = 'demo' | 'flow';

interface AppProps {
  // Props that can be passed when embedding the component
  initialTheme?: ThemeName;
  showThemeSelector?: boolean;
  clientId?: string;
  mode?: AppMode;
}

function App({ initialTheme, showThemeSelector = true, clientId, mode }: AppProps = {}) {
  const [currentStep, setCurrentStep] = useState<FlowStep>('consent');
  const [selectedFI, setSelectedFI] = useState<any>(null);
  const [linkedAccount, setLinkedAccount] = useState<BankAccount | null>(null);
  const [oauthData, setOAuthData] = useState<OAuthSuccessData | null>(null);

  // Determine app mode from URL
  const getAppMode = (): AppMode => {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('demo') === 'true' ? 'demo' : 'flow';
  };

  const [appMode, setAppMode] = useState<AppMode>(mode || getAppMode());

  // Get theme from URL parameters, props, or default to jpmorgan
  const getInitialTheme = (): ThemeName => {
    // Check URL parameters first (for demo purposes)
    const urlParams = new URLSearchParams(window.location.search);
    const themeParam = urlParams.get('theme') as ThemeName;
    
    if (themeParam && availableThemes[themeParam]) {
      return themeParam;
    }
    
    // Check props
    if (initialTheme && availableThemes[initialTheme]) {
      return initialTheme;
    }
    
    // Default theme
    return 'jpmorgan';
  };

  const [selectedTheme, setSelectedTheme] = useState<ThemeName>(getInitialTheme());

  const handleConsentContinue = () => {
    console.log('Consent given, proceeding to FI selection');
    setCurrentStep('fiSelection');
  };

  const handleConsentCancel = () => {
    console.log('User cancelled consent');
    alert('Account linking cancelled. You will be redirected back to the merchant.');
  };

  const handleFISelected = (fi: any) => {
    console.log('FI selected:', fi);
    setSelectedFI(fi);
    
    // Check the flow type based on FI type
    if (fi.type === 'legacy') {
      // Legacy banks require username/password login
      setCurrentStep('legacyLogin');
    } else if (fi.type === 'fintech' || fi.type === 'investment' || 
               ['chase', 'bank_of_america', 'wells_fargo', 'citi', 'us_bank', 'pnc', 'capital_one'].includes(fi.id)) {
      // OAuth-enabled banks (major banks and fintech companies)
      console.log(`Starting OAuth flow for ${fi.name}`);
      setCurrentStep('oauth');
    } else {
      // Default to OAuth for other banks (they can also implement OAuth)
      console.log(`Starting OAuth flow for ${fi.name} (default OAuth flow)`);
      setCurrentStep('oauth');
    }
  };

  const handleBackToConsent = () => {
    setCurrentStep('consent');
  };

  const handleManualConnection = () => {
    setCurrentStep('manualConnect');
  };

  const handleBackToFISelection = () => {
    setCurrentStep('fiSelection');
  };

  const handleManualConnect = (credentials: BankCredentials) => {
    console.log('Manual connection credentials:', credentials);
    setCurrentStep('accountSelection');
  };

  const handleLegacyLogin = (credentials: LegacyLoginCredentials) => {
    console.log('Legacy login credentials:', credentials);
    setCurrentStep('accountSelection');
  };

  const handleOAuthSuccess = (authData: OAuthSuccessData) => {
    console.log('OAuth authentication successful:', authData);
    setOAuthData(authData);
    
    // Log detailed OAuth information
    console.group('🔐 OAuth Authentication Details');
    console.log('🏦 Bank:', authData.institutionName);
    console.log('🔑 Auth Code:', authData.authCode);
    console.log('📋 State:', authData.state);
    console.log('👤 User ID:', authData.userId);
    console.log('🎫 Access Token:', authData.accessToken?.substring(0, 20) + '...');
    console.log('⏰ Timestamp:', authData.timestamp);
    console.groupEnd();

    // Proceed to account selection
    setCurrentStep('accountSelection');
  };

  const handleOAuthError = (error: OAuthError) => {
    console.error('OAuth authentication failed:', error);
    
    // Log detailed error information
    console.group('❌ OAuth Authentication Error');
    console.log('🏦 Bank:', error.institutionName);
    console.log('⚠️ Error:', error.error);
    console.log('📝 Description:', error.errorDescription);
    console.log('🔗 Error URI:', error.errorUri);
    console.log('⏰ Timestamp:', error.timestamp);
    console.groupEnd();

    // Stay on the OAuth screen - don't advance to account selection
    // The OAuth screen will handle displaying the error and providing retry options
    // We intentionally don't change the currentStep here so user stays on OAuth screen
  };

  const handleAccountSelected = (account: BankAccount) => {
    console.log('Account selected:', account);
    setLinkedAccount(account);
    setCurrentStep('success');
  };

  const handleLinkingComplete = (linkingDetails: AccountLinkingDetails) => {
    console.log('Account linking completed successfully:', linkingDetails);
    
    // Here you could send the details to your backend or perform other actions
    // For example, store in localStorage, send to analytics, etc.
    localStorage.setItem('lastLinkingDetails', JSON.stringify(linkingDetails));
  };

  const handleStartOver = () => {
    setCurrentStep('consent');
    setSelectedFI(null);
    setLinkedAccount(null);
    setOAuthData(null);
  };

  const handleCloseFlow = () => {
    // In a real implementation, this might redirect to the merchant's website
    console.log('Closing account linking flow');
    alert('Thank you! Redirecting back to merchant...');
    // window.location.href = 'https://merchant.example.com/success';
  };

  // Handle messages from parent window (for iframe integration)
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      // Verify origin for security in production
      // if (event.origin !== expectedOrigin) return;
      
      if (event.data.type === 'SET_THEME' && event.data.theme) {
        const theme = event.data.theme as ThemeName;
        if (availableThemes[theme]) {
          setSelectedTheme(theme);
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const renderContent = () => {
    if (appMode === 'demo') {
      return <ClientDemo />;
    }

    // Render the actual flow
    switch (currentStep) {
      case 'consent':
        return (
          <ConsentScreen 
            onContinue={handleConsentContinue} 
            onCancel={handleConsentCancel} 
          />
        );
      case 'fiSelection':
        return (
          <FISelectorScreen
            onFISelected={handleFISelected}
            onBack={handleBackToConsent}
            onManualConnection={handleManualConnection}
          />
        );
      case 'manualConnect':
        return (
          <ManualConnectScreen
            onBack={handleBackToFISelection}
            onConnect={handleManualConnect}
          />
        );
      case 'oauth':
        return (
          <OAuthScreen
            selectedFI={selectedFI}
            onBack={handleBackToFISelection}
            onSuccess={handleOAuthSuccess}
            onError={handleOAuthError}
          />
        );
      case 'legacyLogin':
        return (
          <LegacyLoginScreen
            onBack={handleBackToFISelection}
            onLogin={handleLegacyLogin}
            bankName={selectedFI?.name}
          />
        );
      case 'accountSelection':
        return (
          <AccountSelectionScreen
            onBack={handleBackToFISelection}
            onAccountSelected={handleAccountSelected}
            bankName={selectedFI?.name}
          />
        );
      case 'success':
        return (
          <SuccessScreen
            onStartOver={handleStartOver}
            onClose={handleCloseFlow}
            selectedFI={selectedFI}
            linkedAccount={linkedAccount || undefined}
            merchantId={clientId || 'demo_merchant_001'}
            onLinkingComplete={handleLinkingComplete}
          />
        );
      default:
        return (
          <div style={{ padding: '20px', textAlign: 'center' }}>
            <h2>Step: {currentStep}</h2>
            <p>This step will be implemented next.</p>
            <button onClick={() => setCurrentStep('consent')}>
              Back to Consent
            </button>
            {selectedFI && (
              <div style={{ marginTop: '20px' }}>
                <p>Selected FI: {selectedFI.name}</p>
              </div>
            )}
          </div>
        );
    }
  };

  return (
    <BrandingThemeProvider initialTheme={selectedTheme}>
      <SaltProvider mode="light" theme="modern" >
        <div className="App">
          {showThemeSelector && appMode === 'flow' && <ThemeSelector />}
          {renderContent()}
        </div>
      </SaltProvider>
    </BrandingThemeProvider>
  );
}

export default App;
