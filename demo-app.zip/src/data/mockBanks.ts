export interface FinancialInstitution {
  id: string;
  name: string;
  description?: string;
  type: 'bank' | 'credit_union' | 'investment' | 'fintech' | 'legacy';
  logo?: string;
  isPopular?: boolean;
  searchTerms: string[];
}

export const mockBanks: FinancialInstitution[] = [
  // Popular Banks (will be shown by default)
  {
    id: 'chase',
    name: 'Chase Bank',
    description: 'One of the largest banks in the United States',
    type: 'bank',
    isPopular: true,
    searchTerms: ['chase', 'jpmorgan', 'jp morgan chase']
  },
  {
    id: 'bank_of_america',
    name: 'Bank of America',
    description: 'Major American multinational investment bank',
    type: 'bank',
    isPopular: true,
    searchTerms: ['bank of america', 'boa', 'bofa']
  },
  {
    id: 'wells_fargo',
    name: 'Wells Fargo',
    description: 'American multinational financial services company',
    type: 'bank',
    isPopular: true,
    searchTerms: ['wells fargo', 'wells']
  },
  {
    id: 'citi',
    name: 'Citi',
    description: 'American multinational investment bank',
    type: 'bank',
    isPopular: true,
    searchTerms: ['citi', 'citibank', 'citicorp']
  },
  {
    id: 'us_bank',
    name: 'U.S. Bank',
    description: 'Fifth largest commercial bank in the United States',
    type: 'bank',
    isPopular: true,
    searchTerms: ['us bank', 'u.s. bank', 'usbank']
  },
  {
    id: 'pnc',
    name: 'PNC Bank',
    description: 'American bank holding corporation',
    type: 'bank',
    isPopular: true,
    searchTerms: ['pnc', 'pnc bank']
  },
  
  // Additional Banks
  {
    id: 'capital_one',
    name: 'Capital One',
    description: 'American bank holding company',
    type: 'bank',
    searchTerms: ['capital one', 'capitalone']
  },
  {
    id: 'td_bank',
    name: 'TD Bank',
    description: 'American national bank',
    type: 'bank',
    searchTerms: ['td bank', 'td', 'toronto dominion']
  },
  {
    id: 'bb_t',
    name: 'Truist Bank',
    description: 'American bank holding company',
    type: 'bank',
    searchTerms: ['truist', 'bb&t', 'bbt', 'suntrust']
  },
  {
    id: 'regions',
    name: 'Regions Bank',
    description: 'American commercial bank',
    type: 'bank',
    searchTerms: ['regions', 'regions bank']
  },
  {
    id: 'key_bank',
    name: 'KeyBank',
    description: 'American regional bank',
    type: 'bank',
    searchTerms: ['keybank', 'key bank', 'key']
  },
  {
    id: 'fifth_third',
    name: 'Fifth Third Bank',
    description: 'American regional banking corporation',
    type: 'bank',
    searchTerms: ['fifth third', 'fifth third bank', '5/3']
  },
  {
    id: 'ally',
    name: 'Ally Bank',
    description: 'Online-only bank',
    type: 'bank',
    searchTerms: ['ally', 'ally bank']
  },
  {
    id: 'discover',
    name: 'Discover Bank',
    description: 'Digital bank and payment services',
    type: 'bank',
    searchTerms: ['discover', 'discover bank']
  },
  {
    id: 'marcus',
    name: 'Marcus by Goldman Sachs',
    description: 'Online personal banking platform',
    type: 'bank',
    searchTerms: ['marcus', 'goldman sachs', 'goldman']
  },
  {
    id: 'american_express',
    name: 'American Express Bank',
    description: 'Personal and business banking services',
    type: 'bank',
    searchTerms: ['american express', 'amex', 'american express bank']
  },
  {
    id: 'synchrony',
    name: 'Synchrony Bank',
    description: 'Consumer financial services company',
    type: 'bank',
    searchTerms: ['synchrony', 'synchrony bank']
  },
  {
    id: 'huntington',
    name: 'Huntington Bank',
    description: 'Regional bank holding company',
    type: 'bank',
    searchTerms: ['huntington', 'huntington bank']
  },
  {
    id: 'comerica',
    name: 'Comerica Bank',
    description: 'Financial services company',
    type: 'bank',
    searchTerms: ['comerica', 'comerica bank']
  },
  {
    id: 'zions',
    name: 'Zions Bank',
    description: 'Regional financial institution',
    type: 'bank',
    searchTerms: ['zions', 'zions bank']
  },
  {
    id: 'citizens',
    name: 'Citizens Bank',
    description: 'American bank holding company',
    type: 'bank',
    searchTerms: ['citizens', 'citizens bank']
  },
  {
    id: 'suntrust',
    name: 'SunTrust Bank',
    description: 'Now part of Truist Bank',
    type: 'bank',
    searchTerms: ['suntrust', 'sun trust', 'truist']
  },
  {
    id: 'santander',
    name: 'Santander Bank',
    description: 'Spanish-owned bank in the US',
    type: 'bank',
    searchTerms: ['santander', 'santander bank']
  },
  {
    id: 'hsbc',
    name: 'HSBC Bank USA',
    description: 'American subsidiary of HSBC',
    type: 'bank',
    searchTerms: ['hsbc', 'hsbc bank']
  },
  {
    id: 'bmo_harris',
    name: 'BMO Harris Bank',
    description: 'American subsidiary of Bank of Montreal',
    type: 'bank',
    searchTerms: ['bmo', 'bmo harris', 'bank of montreal']
  },
  
  // Credit Unions
  {
    id: 'navy_federal',
    name: 'Navy Federal Credit Union',
    description: 'Largest credit union in the United States',
    type: 'credit_union',
    searchTerms: ['navy federal', 'nfcu', 'navy federal credit union']
  },
  {
    id: 'state_employees',
    name: 'State Employees Credit Union',
    description: 'Credit union serving state employees',
    type: 'credit_union',
    searchTerms: ['state employees', 'secu', 'state employees credit union']
  },
  {
    id: 'pentagon_federal',
    name: 'Pentagon Federal Credit Union',
    description: 'Federal credit union',
    type: 'credit_union',
    searchTerms: ['pentagon federal', 'penfed', 'pentagon federal credit union']
  },
  {
    id: 'schools_first',
    name: 'SchoolsFirst Federal Credit Union',
    description: 'Credit union for education employees',
    type: 'credit_union',
    searchTerms: ['schools first', 'schoolsfirst', 'schools first federal']
  },
  {
    id: 'golden_1',
    name: 'Golden 1 Credit Union',
    description: 'California-based credit union',
    type: 'credit_union',
    searchTerms: ['golden 1', 'golden one', 'golden 1 credit union']
  },
  
  // Investment/Fintech Companies
  {
    id: 'schwab',
    name: 'Charles Schwab Bank',
    description: 'Investment and banking services',
    type: 'investment',
    searchTerms: ['schwab', 'charles schwab', 'charles schwab bank']
  },
  {
    id: 'fidelity',
    name: 'Fidelity Cash Management',
    description: 'Investment and cash management',
    type: 'investment',
    searchTerms: ['fidelity', 'fidelity investments', 'fidelity cash']
  },
  {
    id: 'vanguard',
    name: 'Vanguard',
    description: 'Investment management company',
    type: 'investment',
    searchTerms: ['vanguard', 'vanguard investments']
  },
  {
    id: 'etrade',
    name: 'E*TRADE Bank',
    description: 'Online brokerage and banking',
    type: 'investment',
    searchTerms: ['etrade', 'e*trade', 'e-trade', 'etrade bank']
  },
  {
    id: 'ameritrade',
    name: 'TD Ameritrade',
    description: 'Online brokerage company',
    type: 'investment',
    searchTerms: ['td ameritrade', 'ameritrade', 'tda']
  },
  {
    id: 'robinhood',
    name: 'Robinhood',
    description: 'Commission-free investing platform',
    type: 'fintech',
    searchTerms: ['robinhood', 'robin hood']
  },
  {
    id: 'sofi',
    name: 'SoFi',
    description: 'Digital personal finance company',
    type: 'fintech',
    searchTerms: ['sofi', 'social finance']
  },
  {
    id: 'chime',
    name: 'Chime',
    description: 'Digital banking platform',
    type: 'fintech',
    searchTerms: ['chime', 'chime bank']
  },
  {
    id: 'current',
    name: 'Current',
    description: 'Mobile banking for modern life',
    type: 'fintech',
    searchTerms: ['current', 'current bank']
  },
  {
    id: 'varo',
    name: 'Varo Bank',
    description: 'Digital bank with no fees',
    type: 'fintech',
    searchTerms: ['varo', 'varo bank', 'varo money']
  },
  
  // Regional Banks
  {
    id: 'first_citizens',
    name: 'First Citizens Bank',
    description: 'Regional banking corporation',
    type: 'bank',
    searchTerms: ['first citizens', 'first citizens bank']
  },
  {
    id: 'first_national',
    name: 'First National Bank',
    description: 'Community banking services',
    type: 'bank',
    searchTerms: ['first national', 'first national bank', 'fnb']
  },
  {
    id: 'umb',
    name: 'UMB Bank',
    description: 'Multi-state financial holding company',
    type: 'bank',
    searchTerms: ['umb', 'umb bank', 'united missouri bank']
  },
  {
    id: 'prosperity',
    name: 'Prosperity Bank',
    description: 'Texas-based banking company',
    type: 'bank',
    searchTerms: ['prosperity', 'prosperity bank']
  },
  {
    id: 'cullen_frost',
    name: 'Frost Bank',
    description: 'Texas regional bank',
    type: 'bank',
    searchTerms: ['frost', 'frost bank', 'cullen frost']
  },
  {
    id: 'synovus',
    name: 'Synovus Bank',
    description: 'Financial services company',
    type: 'bank',
    searchTerms: ['synovus', 'synovus bank']
  },
  {
    id: 'iberiabank',
    name: 'Iberiabank',
    description: 'Now part of First Horizon Bank',
    type: 'bank',
    searchTerms: ['iberiabank', 'iberia bank', 'first horizon']
  },
  {
    id: 'old_national',
    name: 'Old National Bank',
    description: 'Regional bank holding company',
    type: 'bank',
    searchTerms: ['old national', 'old national bank', 'onb']
  },
  {
    id: 'first_horizon',
    name: 'First Horizon Bank',
    description: 'Regional banking corporation',
    type: 'bank',
    searchTerms: ['first horizon', 'first horizon bank', 'first tennessee']
  },
  {
    id: 'webster',
    name: 'Webster Bank',
    description: 'Commercial bank holding company',
    type: 'bank',
    searchTerms: ['webster', 'webster bank']
  },
  
  // Legacy Banks (require username/password login)
  {
    id: 'legacy_community_bank',
    name: 'Community First Bank',
    description: 'Local community bank with legacy banking system',
    type: 'legacy',
    searchTerms: ['community first', 'community bank', 'legacy bank']
  },
  {
    id: 'legacy_farmers_bank',
    name: 'Farmers & Merchants Bank',
    description: 'Traditional regional bank with legacy system',
    type: 'legacy',
    searchTerms: ['farmers', 'merchants', 'farmers merchants', 'legacy farmers']
  },
  {
    id: 'legacy_heritage_bank',
    name: 'Heritage Trust Bank',
    description: 'Established bank with legacy authentication',
    type: 'legacy',
    searchTerms: ['heritage', 'heritage trust', 'legacy heritage']
  },
  {
    id: 'legacy_first_state',
    name: 'First State Bank',
    description: 'State-chartered bank with legacy login system',
    type: 'legacy',
    searchTerms: ['first state', 'state bank', 'legacy state']
  }
];

// Helper function to get popular banks
export const getPopularBanks = (): FinancialInstitution[] => {
  return mockBanks.filter(bank => bank.isPopular);
};

// Helper function to search banks
export const searchBanks = (query: string): FinancialInstitution[] => {
  if (!query.trim()) {
    return getPopularBanks();
  }
  
  const lowercaseQuery = query.toLowerCase();
  return mockBanks.filter(bank => 
    bank.name.toLowerCase().includes(lowercaseQuery) ||
    bank.searchTerms.some(term => term.toLowerCase().includes(lowercaseQuery)) ||
    (bank.description && bank.description.toLowerCase().includes(lowercaseQuery))
  );
};
