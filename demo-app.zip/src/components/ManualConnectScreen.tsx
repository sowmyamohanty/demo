import React, { useState } from 'react';
import {
  FlexLayout,
  Button,
  Text,
  Card,
  Input,
  FormField,
  FormFieldLabel,
  FormFieldHelperText,
  Checkbox,
  StackLayout,
  RadioButton,
  RadioButtonGroup,
} from '@salt-ds/core';
import { 
  ChevronLeftIcon, 
  InfoSolidIcon
} from '@salt-ds/icons';
import { useBrandingTheme } from '../theme';
import './ManualConnectScreen.css';

interface ManualConnectScreenProps {
  onBack: () => void;
  onConnect: (credentials: BankCredentials) => void;
}

export interface BankCredentials {
  bankName: string;
  accountNumber: string;
  confirmAccountNumber: string;
  accountType: 'savings' | 'checking';
  routingNumber: string;
  acceptedTerms: boolean;
}

export const ManualConnectScreen: React.FC<ManualConnectScreenProps> = ({
  onBack,
  onConnect,
}) => {
  const { currentTheme } = useBrandingTheme();
  
  // Form state
  const [credentials, setCredentials] = useState<BankCredentials>({
    bankName: '',
    accountNumber: '',
    confirmAccountNumber: '',
    accountType: 'checking',
    routingNumber: '',
    acceptedTerms: false,
  });
  
  // UI state
  const [isConnecting, setIsConnecting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Handle input changes
  const handleInputChange = (field: keyof BankCredentials, value: string | boolean) => {
    setCredentials(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error for this field when user starts typing
    if (errors[field]) {
      const newErrors = { ...errors };
      delete newErrors[field];
      setErrors(newErrors);
    }
  };

  // Validate form
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!credentials.bankName.trim()) {
      newErrors.bankName = 'Bank name is required';
    }
    
    if (!credentials.accountNumber.trim()) {
      newErrors.accountNumber = 'Account number is required';
    } else if (credentials.accountNumber.length < 8) {
      newErrors.accountNumber = 'Account number must be at least 8 characters';
    }
    
    if (!credentials.confirmAccountNumber.trim()) {
      newErrors.confirmAccountNumber = 'Please confirm your account number';
    } else if (credentials.accountNumber !== credentials.confirmAccountNumber) {
      newErrors.confirmAccountNumber = 'Account numbers do not match';
    }
    
    if (!credentials.routingNumber.trim()) {
      newErrors.routingNumber = 'Routing number is required';
    } else if (!isValidRoutingNumber(credentials.routingNumber)) {
      newErrors.routingNumber = 'Please enter a valid 9-digit routing number';
    }
    
    if (!credentials.acceptedTerms) {
      newErrors.acceptedTerms = 'You must accept the terms to continue';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Utility functions
  const isValidRoutingNumber = (routing: string): boolean => {
    return /^\d{9}$/.test(routing);
  };

  // Handle form submission
  const handleConnect = async () => {
    if (!validateForm()) {
      return;
    }

    setIsConnecting(true);
    
    try {
      // Simulate connection process
      await new Promise(resolve => setTimeout(resolve, 2000));
      onConnect(credentials);
    } catch (error) {
      console.error('Connection failed:', error);
      // Handle error appropriately
    } finally {
      setIsConnecting(false);
    }
  };

  const togglePasswordVisibility = () => {
    // Function removed as password field is no longer used
  };

  const toggleAdvanced = () => {
    // Function removed as advanced options are no longer used
  };

  return (
    <div className="manual-connect-screen">
      {/* Header */}
      <div className="manual-connect-header">
        <Button
          variant="secondary"
          onClick={onBack}
          className="back-button"
          disabled={isConnecting}
        >
          <ChevronLeftIcon /> Back
        </Button>
        
        <div className="header-content">
          <Text styleAs="h1" variant="primary">
            Link Bank Account
          </Text>
          <Text variant="secondary">
            Enter your bank account details to securely link your account
          </Text>
        </div>
      </div>

      {/* Connection Form */}
      <Card className="connection-form-card">
        <StackLayout gap={4}>
          <div className="form-header">
            <Text styleAs="h2" variant="primary">
              Bank Account Details
            </Text>
            <Text variant="secondary">
              Please enter your bank account information to complete the linking process
            </Text>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleConnect(); }}>
            <StackLayout gap={3}>
              {/* Bank Name */}
              <FormField className={errors.bankName ? 'error' : ''}>
                <FormFieldLabel>Bank Name *</FormFieldLabel>
                <Input
                  value={credentials.bankName}
                  onChange={(e) => handleInputChange('bankName', (e.target as HTMLInputElement).value)}
                  placeholder="e.g., Chase Bank, Bank of America"
                  disabled={isConnecting}
                />
                {errors.bankName && (
                  <FormFieldHelperText>
                    {errors.bankName}
                  </FormFieldHelperText>
                )}
              </FormField>

              {/* Account Number */}
              <FormField className={errors.accountNumber ? 'error' : ''}>
                <FormFieldLabel>Bank Account Number *</FormFieldLabel>
                <Input
                  value={credentials.accountNumber}
                  onChange={(e) => handleInputChange('accountNumber', (e.target as HTMLInputElement).value)}
                  placeholder="Enter your bank account number"
                  disabled={isConnecting}
                />
                {errors.accountNumber && (
                  <FormFieldHelperText>
                    {errors.accountNumber}
                  </FormFieldHelperText>
                )}
              </FormField>

              {/* Confirm Account Number */}
              <FormField className={errors.confirmAccountNumber ? 'error' : ''}>
                <FormFieldLabel>Confirm Bank Account Number *</FormFieldLabel>
                <Input
                  value={credentials.confirmAccountNumber}
                  onChange={(e) => handleInputChange('confirmAccountNumber', (e.target as HTMLInputElement).value)}
                  placeholder="Re-enter your bank account number"
                  disabled={isConnecting}
                />
                {errors.confirmAccountNumber && (
                  <FormFieldHelperText>
                    {errors.confirmAccountNumber}
                  </FormFieldHelperText>
                )}
              </FormField>

              {/* Account Type */}
              <FormField>
                <FormFieldLabel>Account Type *</FormFieldLabel>
                <RadioButtonGroup 
                  direction="horizontal"
                  value={credentials.accountType}
                  onChange={(event) => handleInputChange('accountType', event.target.value as 'checking' | 'savings')}
                >
                  <RadioButton label="Checking" value="checking" disabled={isConnecting} />
                  <RadioButton label="Savings" value="savings" disabled={isConnecting} />
                </RadioButtonGroup>
              </FormField>

              {/* Routing Number */}
              <FormField className={errors.routingNumber ? 'error' : ''}>
                <FormFieldLabel>Routing Number *</FormFieldLabel>
                <Input
                  value={credentials.routingNumber}
                  onChange={(e) => handleInputChange('routingNumber', (e.target as HTMLInputElement).value)}
                  placeholder="9-digit routing number"
                  disabled={isConnecting}
                />
                <FormFieldHelperText>
                  You can find this 9-digit number on your check or bank statement
                </FormFieldHelperText>
                {errors.routingNumber && (
                  <FormFieldHelperText>
                    {errors.routingNumber}
                  </FormFieldHelperText>
                )}
              </FormField>

              {/* Terms Agreement */}
              <div className="terms-section">
                <Checkbox
                  checked={credentials.acceptedTerms}
                  onChange={(e) => handleInputChange('acceptedTerms', e.target.checked)}
                  disabled={isConnecting}
                  label={
                    <Text color="secondary">
                      I agree to the{' '}
                      <a href="#" className="terms-link">Terms of Service</a>
                      {' '}and{' '}
                      <a href="#" className="terms-link">Privacy Policy</a>
                      {' '}and authorize the linking of my bank account.
                    </Text>
                  }
                />
                {errors.acceptedTerms && (
                  <FormFieldHelperText style={{ marginTop: '8px' }}>
                    {errors.acceptedTerms}
                  </FormFieldHelperText>
                )}
              </div>

              {/* Submit Button */}
              <Button
                variant="cta"
                onClick={handleConnect}
                disabled={isConnecting}
                className="connect-button"
                type="submit"
                style={{
                  backgroundColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
                  borderColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
                }}
              >
                {isConnecting ? 'Authorizing...' : 'Authorize'}
              </Button>
            </StackLayout>
          </form>
        </StackLayout>
      </Card>
    </div>
  );
};
