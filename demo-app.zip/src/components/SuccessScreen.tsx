import React, { useEffect, useState, useCallback } from 'react';
import {
  Button,
  Text,
  Card,
  StackLayout,
  Badge,
} from '@salt-ds/core';
import { 
  SuccessCircleIcon as CheckIcon,
  BankIcon,
  RefreshIcon
} from '@salt-ds/icons';
import { useBrandingTheme } from '../theme';
import { BankAccount } from './AccountSelectionScreen';
import './SuccessScreen.css';

interface SuccessScreenProps {
  onStartOver?: () => void;
  onClose?: () => void;
  selectedFI?: {
    name: string;
    id: string;
    logo?: string;
  };
  linkedAccount?: BankAccount;
  merchantId?: string;
  sessionId?: string;
  onLinkingComplete?: (linkingDetails: AccountLinkingDetails) => void;
}

export interface AccountLinkingDetails {
  success: boolean;
  timestamp: string;
  sessionId: string;
  merchantId?: string;
  linkedAccount: {
    id: string;
    accountNumber: string;
    accountType: string;
    accountName: string;
    lastFourDigits: string;
    bankName: string;
    bankId: string;
  };
  metadata: {
    linkingMethod: 'oauth' | 'credentials' | 'manual';
    ipAddress: string;
    userAgent: string;
    completionTime: number; // Time taken to complete linking in milliseconds
  };
}

// Generate session ID helper function
function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export const SuccessScreen: React.FC<SuccessScreenProps> = ({
  onStartOver,
  onClose,
  selectedFI,
  linkedAccount,
  merchantId = 'demo_merchant_001',
  sessionId = generateSessionId(),
  onLinkingComplete,
}) => {
  const { currentTheme } = useBrandingTheme();
  const [isProcessingCallback, setIsProcessingCallback] = useState(false);
  const [callbackSent, setCallbackSent] = useState(false);

  // Prepare linking details for callback
  const prepareLinkingDetails = useCallback((): AccountLinkingDetails => {
    const completionTime = performance.now(); // This should ideally track from the start of the flow
    
    return {
      success: true,
      timestamp: new Date().toISOString(),
      sessionId,
      merchantId,
      linkedAccount: {
        id: linkedAccount?.id || 'unknown',
        accountNumber: linkedAccount?.accountNumber || '****0000',
        accountType: linkedAccount?.accountType || 'unknown',
        accountName: linkedAccount?.accountName || 'Unknown Account',
        lastFourDigits: linkedAccount?.lastFourDigits || '0000',
        bankName: selectedFI?.name || 'Unknown Bank',
        bankId: selectedFI?.id || 'unknown_bank'
      },
      metadata: {
        linkingMethod: 'oauth', // This could be determined based on the flow
        ipAddress: 'client-side', // In real implementation, this would come from backend
        userAgent: navigator.userAgent,
        completionTime: completionTime
      }
    };
  }, [sessionId, merchantId, linkedAccount, selectedFI]);

  // Simulate webhook call to merchant's endpoint
  const simulateWebhookCall = useCallback(async (details: AccountLinkingDetails): Promise<void> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log('📡 Webhook sent to merchant endpoint:', {
          url: 'https://merchant.example.com/webhooks/account-linking',
          method: 'POST',
          payload: details,
          headers: {
            'Content-Type': 'application/json',
            'X-Session-ID': details.sessionId,
            'X-Merchant-ID': details.merchantId
          }
        });
        resolve();
      }, 1000);
    });
  }, []);

  // Send callback to merchant/parent window
  const sendLinkingCallback = useCallback(async (details: AccountLinkingDetails) => {
    setIsProcessingCallback(true);

    try {
      // Log all details to console as requested
      console.group('🎉 Account Linking Successful');
      console.log('📋 Linking Details:', details);
      console.log('🏦 Bank Information:', {
        name: selectedFI?.name,
        id: selectedFI?.id
      });
      console.log('💳 Account Information:', {
        id: linkedAccount?.id,
        name: linkedAccount?.accountName,
        type: linkedAccount?.accountType,
        number: linkedAccount?.accountNumber,
        balance: linkedAccount?.balance,
        currency: linkedAccount?.currency
      });
      console.log('🔒 Session Information:', {
        sessionId: details.sessionId,
        merchantId: details.merchantId,
        timestamp: details.timestamp
      });
      console.log('📊 Metadata:', details.metadata);
      console.groupEnd();

      // Call the callback prop if provided
      if (onLinkingComplete) {
        onLinkingComplete(details);
      }

      // Send message to parent window (for iframe integration)
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({
          type: 'ACCOUNT_LINKING_SUCCESS',
          data: details
        }, '*'); // In production, specify the actual origin
        console.log('✅ Success callback sent to parent window');
      }

      // Simulate API call to merchant's webhook (in real implementation)
      console.log('🌐 Simulating webhook call to merchant...');
      await simulateWebhookCall(details);
      
      setCallbackSent(true);
    } catch (error) {
      console.error('❌ Error sending linking callback:', error);
    } finally {
      setIsProcessingCallback(false);
    }
  }, [selectedFI, linkedAccount, onLinkingComplete, simulateWebhookCall]);

  // Automatically trigger callback when component mounts
  useEffect(() => {
    const linkingDetails = prepareLinkingDetails();
    sendLinkingCallback(linkingDetails);
  }, [prepareLinkingDetails, sendLinkingCallback]);

  const formatBalance = (balance: number, currency: string): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(balance);
  };

  const handleClose = () => {
    // Log final action
    console.log('🚪 User closed account linking flow');
    
    if (onClose) {
      onClose();
    } else {
      // Default behavior - redirect back to merchant
      console.log('🔄 Redirecting back to merchant...');
      window.history.back();
    }
  };

  const handleStartOver = () => {
    console.log('🔄 User chose to start over');
    if (onStartOver) {
      onStartOver();
    }
  };

  return (
    <div className="success-screen">
      {/* Success Header */}
      <div className="success-header">
        <div className="success-icon-container">
          <div 
            className="success-icon"
            style={{
              backgroundColor: currentTheme?.colors?.status?.success || '#22C55E',
            }}
          >
            <CheckIcon />
          </div>
        </div>
        
        <Text styleAs="h1" variant="primary" className="success-title">
          Account Successfully Linked!
        </Text>
        
        <Text variant="secondary" className="success-subtitle">
          Your {selectedFI?.name || 'bank'} account has been securely connected
        </Text>
      </div>

      {/* Account Details Card */}
      {linkedAccount && (
        <Card className="success-details-card">
          <StackLayout gap={3}>
            <div className="success-card-header">
              <BankIcon className="bank-icon" />
              <div>
                <Text styleAs="h3" variant="primary">
                  Linked Account Details
                </Text>
                <Text variant="secondary">
                  The following account is now connected
                </Text>
              </div>
            </div>

            <div className="account-info-grid">
              <div className="info-item">
                <Text variant="secondary" className="info-label">Bank</Text>
                <Text variant="primary" className="info-value">
                  {selectedFI?.name || 'Unknown Bank'}
                </Text>
              </div>
              
              <div className="info-item">
                <Text variant="secondary" className="info-label">Account Name</Text>
                <Text variant="primary" className="info-value">
                  {linkedAccount.accountName}
                </Text>
              </div>
              
              <div className="info-item">
                <Text variant="secondary" className="info-label">Account Type</Text>
                <Badge className="account-type-badge">
                  {linkedAccount.accountType.charAt(0).toUpperCase() + linkedAccount.accountType.slice(1)}
                </Badge>
              </div>
              
              <div className="info-item">
                <Text variant="secondary" className="info-label">Account Number</Text>
                <Text variant="primary" className="info-value">
                  {linkedAccount.accountNumber}
                </Text>
              </div>
              
              {linkedAccount.balance && (
                <div className="info-item">
                  <Text variant="secondary" className="info-label">Available Balance</Text>
                  <Text variant="primary" className="info-value balance">
                    {formatBalance(linkedAccount.balance, linkedAccount.currency)}
                  </Text>
                </div>
              )}
              
              <div className="info-item">
                <Text variant="secondary" className="info-label">Session ID</Text>
                <Text variant="secondary" className="info-value session-id">
                  {sessionId}
                </Text>
              </div>
            </div>
          </StackLayout>
        </Card>
      )}

      {/* Callback Status */}
      <Card className="callback-status-card">
        <StackLayout gap={2}>
          <Text styleAs="h4" variant="primary">
            Integration Status
          </Text>
          
          <div className="status-item">
            <div className="status-indicator">
              {callbackSent ? (
                <CheckIcon className="status-icon success" />
              ) : isProcessingCallback ? (
                <RefreshIcon className="status-icon processing" />
              ) : (
                <div className="status-icon pending" />
              )}
            </div>
            <div className="status-content">
              <Text variant="primary">
                {callbackSent 
                  ? 'Merchant notification sent successfully'
                  : isProcessingCallback 
                    ? 'Sending notification to merchant...'
                    : 'Preparing merchant notification...'
                }
              </Text>
              <Text variant="secondary" className="status-detail">
                {callbackSent 
                  ? 'Your linked account information has been securely shared with the merchant'
                  : 'Securely transmitting account linking confirmation'
                }
              </Text>
            </div>
          </div>
        </StackLayout>
      </Card>

      {/* Action Buttons */}
      <div className="success-actions">
        <Button
          variant="cta"
          onClick={handleClose}
          className="close-button"
          style={{
            backgroundColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
            borderColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
          }}
        >
          Continue to Merchant
        </Button>
        
        <Button
          variant="secondary"
          onClick={handleStartOver}
          className="start-over-button"
        >
          Link Another Account
        </Button>
      </div>

      {/* Security Note */}
      <div className="security-note">
        <Text variant="secondary" className="security-text">
          🔒 Your account information is encrypted and securely stored. 
          You can revoke access at any time through your account settings.
        </Text>
      </div>
    </div>
  );
};
