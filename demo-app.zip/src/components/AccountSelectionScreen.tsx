import React, { useState } from 'react';
import {
  Button,
  Text,
  Card,
  StackLayout,
  RadioButton,
  RadioButtonGroup,
  FormField,
  FormFieldLabel,
  FormFieldHelperText,
} from '@salt-ds/core';
import { 
  ChevronLeftIcon,
  BankIcon,
  CreditCardIcon
} from '@salt-ds/icons';
import { useBrandingTheme } from '../theme';
import './AccountSelectionScreen.css';

interface AccountSelectionScreenProps {
  onBack: () => void;
  onAccountSelected: (account: BankAccount) => void;
  bankName?: string;
  accounts?: BankAccount[];
}

export interface BankAccount {
  id: string;
  accountNumber: string;
  accountType: 'checking' | 'savings' | 'credit' | 'investment';
  accountName: string;
  balance: number;
  currency: string;
  isAvailable: boolean;
  lastFourDigits: string;
}

export const AccountSelectionScreen: React.FC<AccountSelectionScreenProps> = ({
  onBack,
  onAccountSelected,
  bankName = "Your Bank",
  accounts = [],
}) => {
  const { currentTheme } = useBrandingTheme();
  
  // Use provided accounts or default mock accounts
  const defaultAccounts: BankAccount[] = [
    {
      id: 'checking_001',
      accountNumber: '****1234',
      accountType: 'checking',
      accountName: 'Personal Checking',
      balance: 2584.67,
      currency: 'USD',
      isAvailable: true,
      lastFourDigits: '1234'
    },
    {
      id: 'savings_001',
      accountNumber: '****5678',
      accountType: 'savings',
      accountName: 'Personal Savings',
      balance: 15420.89,
      currency: 'USD',
      isAvailable: true,
      lastFourDigits: '5678'
    },
    {
      id: 'checking_002',
      accountNumber: '****9012',
      accountType: 'checking',
      accountName: 'Business Checking',
      balance: 8967.23,
      currency: 'USD',
      isAvailable: true,
      lastFourDigits: '9012'
    },
    {
      id: 'savings_002',
      accountNumber: '****3456',
      accountType: 'savings',
      accountName: 'Emergency Fund',
      balance: 5000.00,
      currency: 'USD',
      isAvailable: false, // Example of unavailable account
      lastFourDigits: '3456'
    }
  ];

  const availableAccounts = accounts.length > 0 ? accounts : defaultAccounts;
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [isConnecting, setIsConnecting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleAccountSelection = (accountId: string) => {
    setSelectedAccountId(accountId);
    // Clear any previous errors
    if (errors.accountSelection) {
      const newErrors = { ...errors };
      delete newErrors.accountSelection;
      setErrors(newErrors);
    }
  };

  const validateSelection = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!selectedAccountId) {
      newErrors.accountSelection = 'Please select an account to continue';
    }
    
    const selectedAccount = availableAccounts.find(acc => acc.id === selectedAccountId);
    if (selectedAccount && !selectedAccount.isAvailable) {
      newErrors.accountSelection = 'Selected account is not available for linking';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleContinue = async () => {
    if (!validateSelection()) {
      return;
    }

    const selectedAccount = availableAccounts.find(acc => acc.id === selectedAccountId);
    if (!selectedAccount) {
      return;
    }

    setIsConnecting(true);
    
    try {
      // Simulate account linking process
      await new Promise(resolve => setTimeout(resolve, 1500));
      onAccountSelected(selectedAccount);
    } catch (error) {
      console.error('Account selection failed:', error);
      // Handle error appropriately
    } finally {
      setIsConnecting(false);
    }
  };

  const formatBalance = (balance: number, currency: string): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(balance);
  };

  const getAccountIcon = (accountType: string) => {
    switch (accountType) {
      case 'checking':
      case 'savings':
        return <BankIcon className="account-type-icon" />;
      case 'credit':
        return <CreditCardIcon className="account-type-icon" />;
      default:
        return <BankIcon className="account-type-icon" />;
    }
  };

  const getAccountTypeLabel = (accountType: string): string => {
    switch (accountType) {
      case 'checking':
        return 'Checking';
      case 'savings':
        return 'Savings';
      case 'credit':
        return 'Credit';
      case 'investment':
        return 'Investment';
      default:
        return accountType;
    }
  };

  return (
    <div className="account-selection-screen">
      {/* Header */}
      <div className="account-selection-header">
        <Button
          variant="secondary"
          onClick={onBack}
          className="back-button"
          disabled={isConnecting}
        >
          <ChevronLeftIcon /> Back
        </Button>
        
        <div className="header-content">
          <Text styleAs="h1" color="primary">
            Select Account
          </Text>
          <Text color="secondary">
            Choose the account you'd like to link from {bankName}
          </Text>
        </div>
      </div>

      {/* Account Selection Form */}
      <Card className="account-selection-card">
        <StackLayout gap={4}>
          <div className="form-header">
            <Text styleAs="h2" color="primary">
              Available Accounts
            </Text>
            <Text color="secondary">
              Select one account to link to your profile
            </Text>
          </div>

          <FormField className={errors.accountSelection ? 'error' : ''}>
            <FormFieldLabel>Choose Account *</FormFieldLabel>
            <RadioButtonGroup
              direction="vertical"
              value={selectedAccountId}
              onChange={(event) => handleAccountSelection(event.target.value)}
            >
              {availableAccounts.map((account) => (
                <div key={account.id} className={`account-option ${!account.isAvailable ? 'disabled' : ''}`}>
                  <RadioButton
                    value={account.id}
                    disabled={isConnecting || !account.isAvailable}
                    label={
                      <div className="account-details">
                        <div className="account-header">
                          {getAccountIcon(account.accountType)}
                          <div className="account-info">
                            <Text styleAs="h4" color="primary" className="account-name">
                              {account.accountName}
                            </Text>
                            <Text color="secondary" className="account-type">
                              {getAccountTypeLabel(account.accountType)} • {account.accountNumber}
                            </Text>
                          </div>
                        </div>
                        <div className="account-balance">
                          <Text color="primary" className="balance-amount">
                            {formatBalance(account.balance, account.currency)}
                          </Text>
                          {!account.isAvailable && (
                            <Text color="secondary" className="availability-status">
                              Not Available
                            </Text>
                          )}
                        </div>
                      </div>
                    }
                  />
                </div>
              ))}
            </RadioButtonGroup>
            {errors.accountSelection && (
              <FormFieldHelperText>
                {errors.accountSelection}
              </FormFieldHelperText>
            )}
          </FormField>

          {/* Continue Button */}
          <Button
            variant="cta"
            onClick={handleContinue}
            disabled={isConnecting || !selectedAccountId}
            className="continue-button"
            style={{
              backgroundColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
              borderColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
            }}
          >
            {isConnecting ? 'Connecting Account...' : 'Continue with Selected Account'}
          </Button>
        </StackLayout>
      </Card>
    </div>
  );
};
