import React from 'react';
import { Button, FlexLayout, Text } from '@salt-ds/core';
import { useBrandingTheme } from '../theme';
import './ThemeSelector.css';

interface ThemeSelectorProps {
  className?: string;
  showLabel?: boolean;
}

export const ThemeSelector: React.FC<ThemeSelectorProps> = ({ 
  className = '', 
  showLabel = true 
}) => {
  const { themeName, setTheme, availableThemes, isCustomThemeActive } = useBrandingTheme();

  const handleThemeChange = (newTheme: keyof typeof availableThemes | 'salt') => {
    setTheme(newTheme);
  };

  const getThemeDisplayName = (name: string) => {
    switch (name) {
      case 'salt':
        return 'Salt Design System';
      case 'jpmorgan':
        return 'JPMorgan Chase';
      case 'fintech':
        return 'Fintech Modern';
      case 'banking':
        return 'Traditional Banking';
      default:
        return name;
    }
  };

  const allThemes = ['salt', ...Object.keys(availableThemes)];

  return (
    <div className={`theme-selector ${className}`}>
      {showLabel && (
        <Text variant="secondary">
          Theme Demo - Current: {getThemeDisplayName(themeName)}
        </Text>
      )}
      <FlexLayout gap={2} wrap>
        {allThemes.map((theme) => (
          <Button
            key={theme}
            variant={themeName === theme ? 'cta' : 'secondary'}
            onClick={() => handleThemeChange(theme as keyof typeof availableThemes | 'salt')}
            className="theme-button"
          >
            {getThemeDisplayName(theme)}
          </Button>
        ))}
      </FlexLayout>
      <Text variant="secondary" style={{ fontSize: '0.75rem', marginTop: '8px' }}>
        URL: {window.location.href.split('?')[0]}?theme={themeName}
        {!isCustomThemeActive && ' (Using Salt Design System defaults)'}
      </Text>
    </div>
  );
};
