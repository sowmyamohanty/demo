import React, { useEffect, useCallback } from 'react';
import { FinancialInstitution } from '../data/mockBanks';

interface OAuthHandlerProps {
  selectedFI: FinancialInstitution;
  onSuccess: (authData: OAuthSuccessData) => void;
  onError: (error: OAuthError) => void;
  onCancel: () => void;
}

export interface OAuthSuccessData {
  authCode: string;
  state: string;
  institutionId: string;
  institutionName: string;
  userId?: string;
  accessToken?: string; // In real implementation, this would be handled securely on backend
  tokenType?: string;
  expiresIn?: number;
  scope?: string;
  timestamp: string;
}

export interface OAuthError {
  error: string;
  errorDescription?: string;
  errorUri?: string;
  state?: string;
  institutionId: string;
  institutionName: string;
  timestamp: string;
}

// OAuth configuration for different banks
const OAUTH_CONFIGS: Record<string, {
  authUrl: string;
  clientId: string;
  scope: string;
  redirectUri: string;
}> = {
  chase: {
    authUrl: 'https://api.chase.com/oauth/authorize',
    clientId: 'demo_chase_client_id',
    scope: 'accounts:read transactions:read',
    redirectUri: `${window.location.origin}/oauth/callback`
  },
  bank_of_america: {
    authUrl: 'https://api.bankofamerica.com/oauth/authorize',
    clientId: 'demo_boa_client_id',
    scope: 'account_info transaction_history',
    redirectUri: `${window.location.origin}/oauth/callback`
  },
  wells_fargo: {
    authUrl: 'https://api.wellsfargo.com/oauth/authorize',
    clientId: 'demo_wf_client_id',
    scope: 'accounts transactions',
    redirectUri: `${window.location.origin}/oauth/callback`
  },
  citi: {
    authUrl: 'https://sandbox.citibank.com/oauth/authorize',
    clientId: 'demo_citi_client_id',
    scope: 'accounts_details_transactions',
    redirectUri: `${window.location.origin}/oauth/callback`
  },
  // Default config for other banks (using mock OAuth server)
  default: {
    authUrl: 'https://mock-oauth-server.example.com/auth',
    clientId: 'demo_generic_client_id',
    scope: 'accounts:read',
    redirectUri: `${window.location.origin}/oauth/callback`
  }
};

export const OAuthHandler: React.FC<OAuthHandlerProps> = ({
  selectedFI,
  onSuccess,
  onError,
  onCancel
}) => {
  const generateState = useCallback((): string => {
    return `${selectedFI.id}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }, [selectedFI.id]);

  const openOAuthPopup = useCallback(() => {
    const config = OAUTH_CONFIGS[selectedFI.id] || OAUTH_CONFIGS.default;
    const state = generateState();
    
    // Store state for validation
    sessionStorage.setItem('oauth_state', state);
    sessionStorage.setItem('oauth_institution_id', selectedFI.id);
    sessionStorage.setItem('oauth_institution_name', selectedFI.name);
    
    // Build OAuth URL
    const params = new URLSearchParams({
      response_type: 'code',
      client_id: config.clientId,
      redirect_uri: config.redirectUri,
      scope: config.scope,
      state: state,
      // Additional parameters for better UX
      prompt: 'consent',
      access_type: 'offline'
    });

    const authUrl = `${config.authUrl}?${params.toString()}`;
    
    console.log('🔐 Starting OAuth flow for:', selectedFI.name);
    console.log('🌐 OAuth URL:', authUrl);
    console.log('📋 OAuth State:', state);
    
    // Open popup window
    const popup = window.open(
      authUrl,
      'oauth_popup',
      'width=500,height=700,scrollbars=yes,resizable=yes,status=yes'
    );

    if (!popup) {
      onError({
        error: 'popup_blocked',
        errorDescription: 'Popup window was blocked. Please allow popups for this site.',
        institutionId: selectedFI.id,
        institutionName: selectedFI.name,
        timestamp: new Date().toISOString()
      });
      return;
    }

    // Check if popup is closed manually
    const checkClosed = setInterval(() => {
      if (popup.closed) {
        clearInterval(checkClosed);
        console.log('🚪 OAuth popup was closed by user');
        
        // Check if we have received a success callback in the meantime
        const hasReceivedCallback = sessionStorage.getItem('oauth_callback_received');
        if (!hasReceivedCallback) {
          onCancel();
        }
        
        // Clean up
        sessionStorage.removeItem('oauth_state');
        sessionStorage.removeItem('oauth_institution_id');
        sessionStorage.removeItem('oauth_institution_name');
        sessionStorage.removeItem('oauth_callback_received');
      }
    }, 1000);

    // Simulate OAuth flow for demo purposes (since we don't have real OAuth servers)
    // In a real implementation, this would be handled by the OAuth callback
    setTimeout(() => {
      if (!popup.closed) {
        // Simulate different OAuth outcomes for demo purposes
        const random = Math.random();
        
        if (random < 0.15) {
          // 15% chance of simulating an error for demo purposes
          console.log('🎭 Simulating OAuth error for demo purposes...');
          
          // Mark callback as received
          sessionStorage.setItem('oauth_callback_received', 'true');
          
          // Close popup
          popup.close();
          clearInterval(checkClosed);
          
          // Simulate different error types
          const errorTypes = [
            {
              error: 'access_denied',
              errorDescription: 'User denied access to account information',
            },
            {
              error: 'server_error', 
              errorDescription: 'The authorization server encountered an unexpected condition',
            },
            {
              error: 'temporarily_unavailable',
              errorDescription: 'The service is temporarily overloaded or under maintenance',
            },
            {
              error: 'network_error',
              errorDescription: 'Unable to establish connection to authentication server',
            }
          ];
          
          const randomError = errorTypes[Math.floor(Math.random() * errorTypes.length)];
          
          const mockErrorData: OAuthError = {
            ...randomError,
            state: state,
            institutionId: selectedFI.id,
            institutionName: selectedFI.name,
            timestamp: new Date().toISOString()
          };
          
          console.log('❌ OAuth error simulated:', mockErrorData);
          
          onError(mockErrorData);
          
        } else {
          // 85% success rate
          console.log('🎭 Simulating OAuth success for demo purposes...');
          
          // Mark callback as received
          sessionStorage.setItem('oauth_callback_received', 'true');
          
          // Close popup
          popup.close();
          clearInterval(checkClosed);
          
          // Generate mock success data
          const mockAuthData: OAuthSuccessData = {
            authCode: `auth_code_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            state: state,
            institutionId: selectedFI.id,
            institutionName: selectedFI.name,
            userId: `user_${selectedFI.id}_${Date.now()}`,
            accessToken: `access_token_${Date.now()}`, // In real app, this comes from backend
            tokenType: 'Bearer',
            expiresIn: 3600,
            scope: config.scope,
            timestamp: new Date().toISOString()
          };
          
          console.log('✅ OAuth flow completed successfully');
          console.log('📋 Auth Data:', mockAuthData);
          
          onSuccess(mockAuthData);
        }
        
        // Clean up
        sessionStorage.removeItem('oauth_state');
        sessionStorage.removeItem('oauth_institution_id');
        sessionStorage.removeItem('oauth_institution_name');
        sessionStorage.removeItem('oauth_callback_received');
      }
    }, 3000); // Simulate 3 second OAuth flow

  }, [selectedFI, generateState, onSuccess, onError, onCancel]);

  // Handle messages from OAuth callback (for real OAuth implementation)
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      // In production, verify the origin
      // if (event.origin !== expectedOrigin) return;
      
      if (event.data.type === 'OAUTH_SUCCESS') {
        const { authCode, state: receivedState } = event.data;
        const expectedState = sessionStorage.getItem('oauth_state');
        
        if (receivedState !== expectedState) {
          onError({
            error: 'invalid_state',
            errorDescription: 'OAuth state mismatch. Possible CSRF attack.',
            institutionId: selectedFI.id,
            institutionName: selectedFI.name,
            timestamp: new Date().toISOString()
          });
          return;
        }
        
        const authData: OAuthSuccessData = {
          authCode,
          state: receivedState,
          institutionId: selectedFI.id,
          institutionName: selectedFI.name,
          timestamp: new Date().toISOString()
        };
        
        onSuccess(authData);
        
      } else if (event.data.type === 'OAUTH_ERROR') {
        const { error, errorDescription, state: receivedState } = event.data;
        
        onError({
          error,
          errorDescription,
          state: receivedState,
          institutionId: selectedFI.id,
          institutionName: selectedFI.name,
          timestamp: new Date().toISOString()
        });
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [selectedFI, onSuccess, onError]);

  // Automatically start OAuth flow when component mounts
  useEffect(() => {
    console.log(`🚀 Starting OAuth flow for ${selectedFI.name}...`);
    openOAuthPopup();
  }, [openOAuthPopup, selectedFI.name]);

  return null; // This component doesn't render anything
};
