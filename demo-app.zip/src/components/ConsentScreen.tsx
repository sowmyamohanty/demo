import React, { useState, type SyntheticEvent } from 'react';
import {
  FlexLayout,
  Button,
  Text,
  Card,
  Accordion,
  AccordionGroup,
  AccordionHeader,
  AccordionPanel,
  CheckboxGroup,
  Checkbox
} from '@salt-ds/core';
import { ChevronRightIcon } from '@salt-ds/icons';
import './ConsentScreen.css';

interface ConsentScreenProps {
  onContinue: () => void;
  onCancel: () => void;
}

export const ConsentScreen: React.FC<ConsentScreenProps> = ({ onContinue, onCancel }) => {
  const [consentGiven, setConsentGiven] = useState(false);
  const [expandedSection, setExpandedSection] = useState<string>('');

  const handleConsentChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setConsentGiven(event.target.checked);
  };

  const handleAccordionChange = (event: SyntheticEvent<HTMLButtonElement>) => {
    const value = event.currentTarget.value;
    setExpandedSection((old) => (old === value ? '' : value));
  };

  const handleContinue = () => {
    if (consentGiven) {
      onContinue();
    }
  };

  return (
    <div className="consent-screen">
      {/* Header */}
      <div className="consent-header">
        <Text styleAs="h1" variant="primary">
          Bank Account Linking
        </Text>
        <Text variant="secondary">
          Connect your bank account securely to enable payments
        </Text>
      </div>

      {/* Main Content Card */}
      <Card className="consent-card">
        <Text styleAs="h2" variant="primary">
          Before we connect your account
        </Text>
        
        <Text variant="secondary">
          Please review the following information about how your data will be used and protected.
        </Text>

        {/* Consent Accordion */}
        <AccordionGroup className="consent-accordion">
              <Accordion
                value="data-usage"
                expanded={expandedSection === 'data-usage'}
                onToggle={handleAccordionChange}
              >
                <AccordionHeader>How your data will be used</AccordionHeader>
                <AccordionPanel>
                  <div className="accordion-content">
                    <Text>
                      We will use your banking information to:
                    </Text>
                    <ul>
                      <li>Verify your account ownership</li>
                      <li>Enable secure payments and transfers</li>
                      <li>Provide account balance information when needed</li>
                      <li>Facilitate transaction history access</li>
                    </ul>
                    <Text>
                      Your data will only be used for the purposes you have authorized and will never be shared with unauthorized third parties.
                    </Text>
                  </div>
                </AccordionPanel>
              </Accordion>

              <Accordion
                value="data-protection"
                expanded={expandedSection === 'data-protection'}
                onToggle={handleAccordionChange}
              >
                <AccordionHeader>How your data is protected</AccordionHeader>
                <AccordionPanel>
                  <div className="accordion-content">
                    <Text>
                      Your security is our top priority. We protect your information through:
                    </Text>
                    <ul>
                      <li>Bank-level encryption for all data transmission</li>
                      <li>Secure token-based authentication</li>
                      <li>Regular security audits and monitoring</li>
                      <li>Compliance with financial industry standards</li>
                      <li>No storage of your login credentials</li>
                    </ul>
                  </div>
                </AccordionPanel>
              </Accordion>

              <Accordion
                value="permissions"
                expanded={expandedSection === 'permissions'}
                onToggle={handleAccordionChange}
              >
                <AccordionHeader>Permissions and access</AccordionHeader>
                <AccordionPanel>
                  <div className="accordion-content">
                    <Text>
                      By connecting your account, you grant permission to:
                    </Text>
                    <ul>
                      <li>Read your account information and balances</li>
                      <li>Access transaction history for verification purposes</li>
                      <li>Initiate authorized payments and transfers</li>
                    </ul>
                    <Text>
                      You can revoke these permissions at any time through your account settings.
                    </Text>
                  </div>
                </AccordionPanel>
              </Accordion>

              <Accordion
                value="terms"
                expanded={expandedSection === 'terms'}
                onToggle={handleAccordionChange}
              >
                <AccordionHeader>Terms and conditions</AccordionHeader>
                <AccordionPanel>
                  <div className="accordion-content">
                    <Text>
                      By proceeding, you acknowledge that:
                    </Text>
                    <ul>
                      <li>You are the authorized account holder</li>
                      <li>You consent to the collection and use of your banking data as described</li>
                      <li>You understand the risks associated with sharing financial information</li>
                      <li>You agree to our Terms of Service and Privacy Policy</li>
                    </ul>
                    <Text variant="secondary">
                      Last updated: August 27, 2025
                    </Text>
                  </div>
                </AccordionPanel>
              </Accordion>
            </AccordionGroup>

            {/* Consent Checkbox */}
            <div className="consent-checkbox-container">
              <CheckboxGroup>
                <Checkbox
                  checked={consentGiven}
                  onChange={handleConsentChange}
                  label="I have read and agree to the terms above, and I consent to sharing my banking information for the purposes described."
                />
              </CheckboxGroup>
            </div>

            {/* Action Buttons */}
            <div className="consent-actions">
              <Button
                variant="secondary"
                onClick={onCancel}
                className="cancel-button"
              >
                Cancel
              </Button>
              
              <Button
                variant="cta"
                onClick={handleContinue}
                disabled={!consentGiven}
                className="continue-button"
              >
                Continue <ChevronRightIcon />
              </Button>
            </div>
          </Card>
        </div>
      );
    };
