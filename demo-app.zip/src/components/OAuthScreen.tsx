import React, { useState, useEffect } from 'react';
import {
  Button,
  Text,
  Card,
  StackLayout,
  Spinner,
} from '@salt-ds/core';
import { 
  ChevronLeftIcon,
  BankIcon
} from '@salt-ds/icons';
import { useBrandingTheme } from '../theme';
import { FinancialInstitution } from '../data/mockBanks';
import { OAuthHandler, OAuthSuccessData, OAuthError } from './OAuthHandler';
import './OAuthScreen.css';

interface OAuthScreenProps {
  selectedFI: FinancialInstitution;
  onBack: () => void;
  onSuccess: (authData: OAuthSuccessData) => void;
  onError: (error: OAuthError) => void;
}

export const OAuthScreen: React.FC<OAuthScreenProps> = ({
  selectedFI,
  onBack,
  onSuccess,
  onError
}) => {
  const { currentTheme } = useBrandingTheme();
  const [status, setStatus] = useState<'connecting' | 'authenticating' | 'error' | 'cancelled'>('connecting');
  const [error, setError] = useState<OAuthError | null>(null);
  const [countdown, setCountdown] = useState(30); // 30 second timeout

  // Countdown timer
  useEffect(() => {
    if (status === 'connecting' || status === 'authenticating') {
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            setStatus('error');
            setError({
              error: 'timeout',
              errorDescription: 'OAuth authentication timed out. Please try again.',
              institutionId: selectedFI.id,
              institutionName: selectedFI.name,
              timestamp: new Date().toISOString()
            });
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [status, selectedFI]);

  const handleOAuthSuccess = (authData: OAuthSuccessData) => {
    console.log('✅ OAuth authentication successful');
    setStatus('authenticating');
    
    // Simulate brief processing time
    setTimeout(() => {
      onSuccess(authData);
    }, 1000);
  };

  const handleOAuthError = (oauthError: OAuthError) => {
    console.error('❌ OAuth authentication failed:', oauthError);
    setStatus('error');
    setError(oauthError);
    // Don't call onError immediately - let user see the error and choose action
  };

  const handleOAuthCancel = () => {
    console.log('🚪 OAuth authentication cancelled by user');
    setStatus('cancelled');
  };

  const handleRetry = () => {
    setStatus('connecting');
    setError(null);
    setCountdown(30);
    // The OAuthHandler will automatically restart when the status changes
  };

  // Development helper to test different error scenarios
  const simulateError = (errorType: string) => {
    if (process.env.NODE_ENV !== 'development') return;
    
    const mockError: OAuthError = {
      error: errorType,
      errorDescription: `Simulated ${errorType} error for testing purposes`,
      institutionId: selectedFI.id,
      institutionName: selectedFI.name,
      timestamp: new Date().toISOString()
    };
    
    setStatus('error');
    setError(mockError);
  };

  const getUserFriendlyErrorMessage = (error: OAuthError | null): { title: string; message: string; actionable: boolean } => {
    if (!error) {
      return { title: 'Unknown Error', message: 'An unknown error occurred during authentication.', actionable: true };
    }

    switch (error.error) {
      case 'access_denied':
        return {
          title: 'Access Denied',
          message: 'You denied permission to access your account. To link your account, please authorize the connection when prompted.',
          actionable: true
        };
      case 'popup_blocked':
        return {
          title: 'Popup Blocked',
          message: 'Your browser blocked the authentication popup. Please allow popups for this site and try again.',
          actionable: true
        };
      case 'timeout':
        return {
          title: 'Connection Timeout',
          message: 'The authentication process took too long and timed out. This might be due to a slow internet connection or server issues.',
          actionable: true
        };
      case 'invalid_state':
        return {
          title: 'Security Error',
          message: 'A security error occurred during authentication. This might be due to a potential security threat or browser issues.',
          actionable: true
        };
      case 'server_error':
        return {
          title: 'Server Error',
          message: `${error.institutionName} is currently experiencing technical difficulties. Please try again in a few minutes.`,
          actionable: true
        };
      case 'temporarily_unavailable':
        return {
          title: 'Service Unavailable',
          message: `${error.institutionName}'s authentication service is temporarily unavailable. Please try again later.`,
          actionable: true
        };
      case 'invalid_request':
        return {
          title: 'Invalid Request',
          message: 'There was an issue with the authentication request. This is usually a temporary problem.',
          actionable: true
        };
      case 'network_error':
        return {
          title: 'Network Error',
          message: 'Unable to connect to the authentication server. Please check your internet connection and try again.',
          actionable: true
        };
      case 'bank_maintenance':
        return {
          title: 'Bank Maintenance',
          message: `${error.institutionName} is currently undergoing maintenance. Online banking services may be temporarily unavailable.`,
          actionable: false
        };
      default:
        return {
          title: 'Authentication Failed',
          message: error.errorDescription || `Unable to authenticate with ${error.institutionName}. Please try again or contact support if the problem persists.`,
          actionable: true
        };
    }
  };

  const getStatusMessage = () => {
    switch (status) {
      case 'connecting':
        return 'Opening secure connection...';
      case 'authenticating':
        return 'Authenticating with your bank...';
      case 'error':
        const errorInfo = getUserFriendlyErrorMessage(error);
        return errorInfo.title;
      case 'cancelled':
        return 'Authentication was cancelled';
      default:
        return 'Connecting to your bank...';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'connecting':
      case 'authenticating':
        return <Spinner size="medium" />;
      case 'error':
        return <div className="error-icon">⚠️</div>;
      case 'cancelled':
        return <div className="cancelled-icon">🚫</div>;
      default:
        return <Spinner size="medium" />;
    }
  };

  return (
    <div className="oauth-screen">
      {/* OAuth Handler - only render when connecting */}
      {status === 'connecting' && (
        <OAuthHandler
          selectedFI={selectedFI}
          onSuccess={handleOAuthSuccess}
          onError={handleOAuthError}
          onCancel={handleOAuthCancel}
        />
      )}

      {/* Header */}
      <div className="oauth-header">
        <Button
          variant="secondary"
          onClick={onBack}
          className="back-button"
          disabled={status === 'authenticating'}
        >
          <ChevronLeftIcon /> Back
        </Button>
        
        <div className="header-content">
          <Text styleAs="h1" variant="primary">
            Connecting to {selectedFI.name}
          </Text>
          <Text variant="secondary">
            Please complete the authentication in the popup window
          </Text>
        </div>
      </div>

      {/* Main Content */}
      <Card className="oauth-status-card">
        <StackLayout gap={4}>
          {/* Bank Info */}
          <div className="bank-info-section">
            <div className="bank-logo-container">
              <div className="bank-logo-placeholder">
                {selectedFI.name.charAt(0).toUpperCase()}
              </div>
            </div>
            <div className="bank-details">
              <Text styleAs="h3" variant="primary">
                {selectedFI.name}
              </Text>
              <Text variant="secondary">
                {selectedFI.description || 'Secure OAuth Authentication'}
              </Text>
            </div>
          </div>

          {/* Status Section */}
          <div className="status-section">
            <div className="status-icon-container">
              {getStatusIcon()}
            </div>
            
            <Text styleAs="h4" variant="primary" className="status-message">
              {getStatusMessage()}
            </Text>
            
            {(status === 'connecting' || status === 'authenticating') && (
              <Text variant="secondary" className="countdown">
                Timeout in {countdown} seconds
              </Text>
            )}
          </div>

          {/* Error Details */}
          {status === 'error' && error && (
            <div className="error-details-section">
              <div className="error-message">
                <Text variant="secondary" className="error-description">
                  {getUserFriendlyErrorMessage(error).message}
                </Text>
              </div>
              
              <div className="error-technical-details">
                <details className="technical-details-toggle">
                  <summary>Technical Details</summary>
                  <div className="technical-details-content">
                    <Text variant="secondary" className="technical-detail-item">
                      <strong>Error Code:</strong> {error.error}
                    </Text>
                    <Text variant="secondary" className="technical-detail-item">
                      <strong>Institution:</strong> {error.institutionName}
                    </Text>
                    <Text variant="secondary" className="technical-detail-item">
                      <strong>Timestamp:</strong> {new Date(error.timestamp).toLocaleString()}
                    </Text>
                    {error.errorDescription && (
                      <Text variant="secondary" className="technical-detail-item">
                        <strong>Description:</strong> {error.errorDescription}
                      </Text>
                    )}
                    {error.errorUri && (
                      <Text variant="secondary" className="technical-detail-item">
                        <strong>Help URL:</strong> <a href={error.errorUri} target="_blank" rel="noopener noreferrer">{error.errorUri}</a>
                      </Text>
                    )}
                  </div>
                </details>
              </div>
            </div>
          )}

          {/* Instructions */}
          {status === 'connecting' && (
            <div className="instructions-section">
              <Text styleAs="h4" variant="primary">
                What happens next?
              </Text>
              <ol className="instructions-list">
                <li>A popup window will open with your bank's login page</li>
                <li>Sign in with your online banking credentials</li>
                <li>Review and approve the account access permissions</li>
                <li>You'll be redirected back to complete the connection</li>
              </ol>
            </div>
          )}

          {/* Error Actions */}
          {status === 'error' && (
            <div className="error-actions">
              {getUserFriendlyErrorMessage(error).actionable && (
                <Button
                  variant="cta"
                  onClick={handleRetry}
                  className="retry-button"
                  style={{
                    backgroundColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
                    borderColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
                  }}
                >
                  Try Again
                </Button>
              )}
              
              <Button
                variant="secondary"
                onClick={onBack}
                className="back-to-selection-button"
              >
                Choose Different Bank
              </Button>
              
              <Button
                variant="secondary"
                onClick={() => {
                  // Log error report for analytics/debugging
                  console.log('📋 Error Report Generated:', {
                    error: error,
                    userAgent: navigator.userAgent,
                    timestamp: new Date().toISOString(),
                    sessionId: `error_${Date.now()}`
                  });
                  alert('Error report has been logged. Our team will investigate this issue.');
                }}
                className="report-issue-button"
              >
                Report Issue
              </Button>
            </div>
          )}

          {/* Cancelled Actions */}
          {status === 'cancelled' && (
            <div className="cancelled-actions">
              <Button
                variant="cta"
                onClick={handleRetry}
                className="retry-button"
                style={{
                  backgroundColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
                  borderColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
                }}
              >
                Try Again
              </Button>
              <Button
                variant="secondary"
                onClick={onBack}
                className="back-to-selection-button"
              >
                Choose Different Bank
              </Button>
            </div>
          )}
        </StackLayout>
      </Card>

      {/* Security Note */}
      <Card className="security-note-card">
        <StackLayout direction="row" gap={2}>
          <div className="security-icon">🔒</div>
          <div className="security-content">
            <Text styleAs="h4" variant="primary">
              Your security is our priority
            </Text>
            <Text variant="secondary">
              We use bank-level security and never store your login credentials. 
              Your connection is encrypted and your data is protected.
            </Text>
          </div>
        </StackLayout>
      </Card>
      
      {/* Development Testing Panel - Only shown in development mode */}
      {process.env.NODE_ENV === 'development' && (
        <Card className="dev-testing-panel">
          <StackLayout gap={2}>
            <Text styleAs="h4" variant="primary">
              🧪 Development Testing Panel
            </Text>
            <Text variant="secondary">
              Test different OAuth error scenarios:
            </Text>
            <div className="dev-error-buttons">
              <Button onClick={() => simulateError('access_denied')}>
                Access Denied
              </Button>
              <Button onClick={() => simulateError('popup_blocked')}>
                Popup Blocked
              </Button>
              <Button onClick={() => simulateError('server_error')}>
                Server Error
              </Button>
              <Button onClick={() => simulateError('timeout')}>
                Timeout
              </Button>
              <Button onClick={() => simulateError('network_error')}>
                Network Error
              </Button>
              <Button onClick={() => simulateError('bank_maintenance')}>
                Maintenance
              </Button>
            </div>
          </StackLayout>
        </Card>
      )}
    </div>
  );
};
