import React, { useState, useEffect, useMemo } from 'react';
import {
  FlexLayout,
  Button,
  Text,
  Card,
  Input,
  Spinner,
  Banner
} from '@salt-ds/core';
import { SearchIcon, ChevronLeftIcon, ChevronRightIcon } from '@salt-ds/icons';
import { List, AutoSizer, ListRowProps } from 'react-virtualized';
import 'react-virtualized/styles.css';
import { useBrandingTheme } from '../theme';
import { mockBanks, getPopularBanks, searchBanks, FinancialInstitution } from '../data/mockBanks';
import './FISelectorScreen.css';

interface FISelectorScreenProps {
  onFISelected: (fi: FinancialInstitution) => void;
  onBack: () => void;
  onManualConnection: () => void;
}

export const FISelectorScreen: React.FC<FISelectorScreenProps> = ({
  onFISelected,
  onBack,
  onManualConnection,
}) => {
  const { currentTheme } = useBrandingTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const POPULAR_BANKS_COUNT = 6;

  // Filter FIs based on search query
  const displayedFIs = useMemo(() => {
    return searchBanks(searchQuery);
  }, [searchQuery]);

  // Handle search input change
  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const query = event.target.value;
    setSearchQuery(query);
    setShowSearchResults(query.length > 0);
    setError(null);
    
    // Simulate API loading for search
    if (query.length > 0) {
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        const searchResults = searchBanks(query);
        if (searchResults.length === 0) {
          setError('No financial institutions found matching your search.');
        }
      }, 500);
    }
  };

  // Handle FI selection
  const handleFISelect = (fi: FinancialInstitution) => {
    onFISelected(fi);
  };

  return (
    <div className="fi-selector-screen">
      {/* Header */}
      <div className="fi-selector-header">
        <Button
          variant="secondary"
          onClick={onBack}
          className="back-button"
        >
          <ChevronLeftIcon /> Back
        </Button>
        <div className="header-content">
          <Text styleAs="h1" variant="primary">
            Select Your Bank
          </Text>
          <Text variant="secondary">
            Choose your financial institution to connect your account
          </Text>
        </div>
      </div>

      {/* Search and Results Section */}
      <Card className="search-results-card">
        {/* Search Input */}
        <div className="search-container">
          <div className="search-input-container">
            <SearchIcon className="search-icon" />
            <Input
              placeholder="Search for your bank or credit union..."
              value={searchQuery}
              onChange={handleSearchChange}
              className="search-input"
            />
          </div>
        </div>

        {/* Error Banner */}
        {error && (
          <div className="error-banner">
            <Text variant="secondary" style={{ color: 'var(--brand-color-error, #DC3545)' }}>
              {error}
            </Text>
          </div>
        )}

        {/* Loading State */}
        {isLoading && (
          <div className="loading-container">
            <Spinner />
            <Text variant="secondary">Searching financial institutions...</Text>
          </div>
        )}

        {/* Results */}
        {!isLoading && (
          <>
            <div className="results-header">
              <Text styleAs="h2" variant="primary">
                {showSearchResults ? 'Search Results' : 'Popular Banks'}
              </Text>
              {showSearchResults && (
                <Text variant="secondary">
                  {displayedFIs.length} result{displayedFIs.length !== 1 ? 's' : ''} found
                </Text>
              )}
              {!showSearchResults && (
                <Text variant="secondary">
                  Choose from our most popular banks or search for your institution
                </Text>
              )}
            </div>

            {/* FI List - Using React Virtualized */}
            <div className="fi-list-container" style={{ height: '400px', width: '100%' }}>
              {displayedFIs.length > 0 ? (
                <AutoSizer>
                  {({ height, width }) => (
                    <List
                      height={height}
                      width={width}
                      rowCount={displayedFIs.length}
                      rowHeight={80}
                      rowRenderer={({ index, key, style }: ListRowProps) => {
                        const fi = displayedFIs[index];
                        return (
                          <div key={key} style={style}>
                            <div
                              className="fi-item"
                              onClick={() => handleFISelect(fi)}
                              style={{
                                borderColor: currentTheme?.colors?.accent || 'var(--salt-accent-borderColor)',
                                height: '76px',
                                margin: '2px 0',
                              }}
                            >
                              <div className="fi-item-content">
                                <div className="fi-logo-placeholder">
                                  {fi.name.charAt(0).toUpperCase()}
                                </div>
                                <div className="fi-info">
                                  <Text className="fi-name">{fi.name}</Text>
                                  {fi.description && (
                                    <Text variant="secondary" className="fi-description">
                                      {fi.description}
                                    </Text>
                                  )}
                                  <div className="fi-type-badge">
                                    <span className={`type-badge ${fi.type}`}>
                                      {fi.type === 'fintech' ? 'Fintech' : 
                                       fi.type === 'credit_union' ? 'Credit Union' : 
                                       fi.type === 'investment' ? 'Investment' : 'Bank'}
                                    </span>
                                  </div>
                                </div>
                                <ChevronRightIcon className="fi-arrow" />
                              </div>
                            </div>
                          </div>
                        );
                      }}
                    />
                  )}
                </AutoSizer>
              ) : !isLoading && showSearchResults ? (
                <div className="no-results">
                  <Text variant="secondary">
                    No financial institutions found. Try a different search term or use manual connection.
                  </Text>
                </div>
              ) : null}
            </div>
          </>
        )}
      </Card>

      {/* Manual Connection Section */}
      <Card className="manual-connection-card">
        <FlexLayout direction="column" gap={2} align="center">
          <Text styleAs="h3" variant="primary">
            Don't see your bank?
          </Text>
          <Text variant="secondary" style={{ textAlign: 'center' }}>
            You can still connect your account manually by providing your banking details.
          </Text>
          <Button
            variant="secondary"
            onClick={onManualConnection}
            className="manual-connection-button"
          >
            Connect Manually
          </Button>
        </FlexLayout>
      </Card>
    </div>
  );
};
