import React, { useState } from 'react';
import { Button, FlexLayout, Text, Card } from '@salt-ds/core';
import { ThemeName, getDemoUrls } from '../theme';

export const ClientDemo: React.FC = () => {
  const [selectedDemo, setSelectedDemo] = useState<ThemeName>('jpmorgan');
  
  const demos = [
    {
      id: 'jpmorgan' as ThemeName,
      name: 'JPMorgan Chase',
      description: 'Traditional banking theme with corporate blue colors',
      primaryColor: '#005CB9'
    },
    {
      id: 'fintech' as ThemeName,
      name: 'Modern Fintech',
      description: 'Contemporary fintech theme with purple accent colors',
      primaryColor: '#6366F1'
    },
    {
      id: 'banking' as ThemeName,
      name: 'Traditional Banking',
      description: 'Conservative banking theme with navy blue colors',
      primaryColor: '#1E3A8A'
    }
  ];

  const openDemo = (theme: ThemeName) => {
    const baseUrl = window.location.origin + window.location.pathname;
    const demoUrl = `${baseUrl}?theme=${theme}`;
    window.open(demoUrl, '_blank');
  };

  return (
    <div style={{ padding: '40px', maxWidth: '1200px', margin: '0 auto' }}>
      <Text styleAs="h1" style={{ marginBottom: '20px', textAlign: 'center' }}>
        Bank Account Linking - Client Theme Demo
      </Text>
      
      <Text variant="secondary" style={{ marginBottom: '40px', textAlign: 'center' }}>
        See how the Bank Account Linking experience can be customized for different clients
      </Text>

      <FlexLayout direction="row" gap={4} wrap>
        {demos.map((demo) => (
          <Card key={demo.id} style={{ flex: '1', minWidth: '300px', padding: '24px' }}>
            <FlexLayout direction="column" gap={3}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div
                  style={{
                    width: '20px',
                    height: '20px',
                    borderRadius: '50%',
                    backgroundColor: demo.primaryColor,
                  }}
                />
                <Text styleAs="h3">{demo.name}</Text>
              </div>
              
              <Text variant="secondary">
                {demo.description}
              </Text>
              
              <Button
                variant="cta"
                onClick={() => openDemo(demo.id)}
                style={{ marginTop: '16px' }}
              >
                View Demo
              </Button>
              
              <Text variant="secondary" style={{ fontSize: '0.75rem' }}>
                URL: {window.location.origin + window.location.pathname}?theme={demo.id}
              </Text>
            </FlexLayout>
          </Card>
        ))}
      </FlexLayout>
      
      <Card style={{ marginTop: '40px', padding: '24px' }}>
        <Text styleAs="h3" style={{ marginBottom: '16px' }}>
          Integration Guide
        </Text>
        <Text variant="secondary">
          To integrate this component with client-specific branding:
        </Text>
        <ol style={{ marginTop: '16px' }}>
          <li>Import the BrandingThemeProvider and desired theme configuration</li>
          <li>Wrap your app with the BrandingThemeProvider</li>
          <li>Pass the client's theme as initialTheme prop</li>
          <li>Set showThemeSelector to false for production embeds</li>
          <li>Customize theme colors, fonts, and spacing in themeConfig.ts</li>
        </ol>
        
        <div style={{ marginTop: '20px', padding: '16px', backgroundColor: 'var(--salt-container-secondary-background)', borderRadius: '4px' }}>
          <Text styleAs="code" style={{ fontSize: '0.875rem' }}>
            {`<BrandingThemeProvider initialTheme="jpmorgan">`}<br/>
            {`  <App showThemeSelector={false} />`}<br/>
            {`</BrandingThemeProvider>`}
          </Text>
        </div>
      </Card>
    </div>
  );
};
