import React, { useState } from 'react';
import {
  FlexLayout,
  Button,
  Text,
  Card,
  Input,
  FormField,
  FormFieldLabel,
  FormFieldHelperText,
  Checkbox,
  StackLayout,
} from '@salt-ds/core';
import { 
  ChevronLeftIcon, 
  VisibleIcon, 
  InfoSolidIcon
} from '@salt-ds/icons';
import { useBrandingTheme } from '../theme';
import './LegacyLoginScreen.css';

interface LegacyLoginScreenProps {
  onBack: () => void;
  onLogin: (credentials: LegacyLoginCredentials) => void;
  bankName?: string;
}

export interface LegacyLoginCredentials {
  username: string;
  password: string;
  acceptedTerms: boolean;
}

export const LegacyLoginScreen: React.FC<LegacyLoginScreenProps> = ({
  onBack,
  onLogin,
  bankName = "Your Bank",
}) => {
  const { currentTheme } = useBrandingTheme();
  
  // Form state
  const [credentials, setCredentials] = useState<LegacyLoginCredentials>({
    username: '',
    password: '',
    acceptedTerms: false,
  });
  
  // UI state
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Handle input changes
  const handleInputChange = (field: keyof LegacyLoginCredentials, value: string | boolean) => {
    setCredentials(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error for this field when user starts typing
    if (errors[field]) {
      const newErrors = { ...errors };
      delete newErrors[field];
      setErrors(newErrors);
    }
  };

  // Validate form
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!credentials.username.trim()) {
      newErrors.username = 'Username is required';
    }
    
    if (!credentials.password.trim()) {
      newErrors.password = 'Password is required';
    } else if (credentials.password.length < 3) {
      newErrors.password = 'Password must be at least 3 characters';
    }
    
    if (!credentials.acceptedTerms) {
      newErrors.acceptedTerms = 'You must accept the terms to continue';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleLogin = async () => {
    if (!validateForm()) {
      return;
    }

    setIsLoggingIn(true);
    
    try {
      // Simulate login process
      await new Promise(resolve => setTimeout(resolve, 2000));
      onLogin(credentials);
    } catch (error) {
      console.error('Login failed:', error);
      // Handle error appropriately
    } finally {
      setIsLoggingIn(false);
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="legacy-login-screen">
      {/* Header */}
      <div className="legacy-login-header">
        <Button
          variant="secondary"
          onClick={onBack}
          className="back-button"
          disabled={isLoggingIn}
        >
          <ChevronLeftIcon /> Back
        </Button>
        
        <div className="header-content">
          <Text styleAs="h1" color="primary">
            Login to {bankName}
          </Text>
          <Text color="secondary">
            Enter your online banking credentials to securely access your account
          </Text>
        </div>
      </div>

      {/* Login Form */}
      <Card className="login-form-card">
        <StackLayout gap={4}>
          <div className="form-header">
            <Text styleAs="h2" variant="primary">
              Bank Login
            </Text>
            <Text variant="secondary">
              Use your online banking username and password
            </Text>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleLogin(); }}>
            <StackLayout gap={3}>
              {/* Username */}
              <FormField className={errors.username ? 'error' : ''}>
                <FormFieldLabel>Username *</FormFieldLabel>
                <Input
                  value={credentials.username}
                  onChange={(e) => handleInputChange('username', (e.target as HTMLInputElement).value)}
                  placeholder="Enter your online banking username"
                  disabled={isLoggingIn}
                />
                {errors.username && (
                  <FormFieldHelperText>
                    {errors.username}
                  </FormFieldHelperText>
                )}
              </FormField>

              {/* Password */}
              <FormField className={errors.password ? 'error' : ''}>
                <FormFieldLabel>Password *</FormFieldLabel>
                <div className="password-input-container">
                  <Input
                    value={credentials.password}
                    onChange={(e) => handleInputChange('password', (e.target as HTMLInputElement).value)}
                    placeholder="Enter your online banking password"
                    disabled={isLoggingIn}
                    className="password-input"
                  />
                  <Button
                    variant="secondary"
                    onClick={togglePasswordVisibility}
                    className="password-toggle"
                    disabled={isLoggingIn}
                    type="button"
                  >
                    <VisibleIcon />
                  </Button>
                </div>
                {errors.password && (
                  <FormFieldHelperText>
                    {errors.password}
                  </FormFieldHelperText>
                )}
              </FormField>

              {/* Terms Agreement */}
              <div className="terms-section">
                <Checkbox
                  checked={credentials.acceptedTerms}
                  onChange={(e) => handleInputChange('acceptedTerms', e.target.checked)}
                  disabled={isLoggingIn}
                  label={
                    <Text variant="secondary">
                      I agree to the{' '}
                      <a href="#" className="terms-link">Terms of Service</a>
                      {' '}and{' '}
                      <a href="#" className="terms-link">Privacy Policy</a>
                      {' '}and authorize the secure connection to my bank account.
                    </Text>
                  }
                />
                {errors.acceptedTerms && (
                  <FormFieldHelperText style={{ marginTop: '8px' }}>
                    {errors.acceptedTerms}
                  </FormFieldHelperText>
                )}
              </div>

              {/* Submit Button */}
              <Button
                variant="cta"
                onClick={handleLogin}
                disabled={isLoggingIn}
                className="login-button"
                type="submit"
                style={{
                  backgroundColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
                  borderColor: currentTheme?.colors?.primary || 'var(--salt-actionable-cta-background)',
                }}
              >
                {isLoggingIn ? 'Logging in...' : 'Login'}
              </Button>
            </StackLayout>
          </form>
        </StackLayout>
      </Card>
    </div>
  );
};
