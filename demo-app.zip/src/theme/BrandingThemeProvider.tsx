import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { ClientTheme, ThemeName, availableThemes, jpMorganTheme } from './themeConfig';

interface ThemeContextType {
  currentTheme: ClientTheme | null;
  themeName: ThemeName | 'salt';
  setTheme: (themeName: ThemeName | 'salt') => void;
  availableThemes: typeof availableThemes;
  isCustomThemeActive: boolean;
}

const BrandingThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useBrandingTheme = (): ThemeContextType => {
  const context = useContext(BrandingThemeContext);
  if (!context) {
    throw new Error('useBrandingTheme must be used within a BrandingThemeProvider');
  }
  return context;
};

interface BrandingThemeProviderProps {
  children: ReactNode;
  initialTheme?: ThemeName | 'salt';
}

export const BrandingThemeProvider: React.FC<BrandingThemeProviderProps> = ({
  children,
  initialTheme = 'salt',
}) => {
  const [themeName, setThemeName] = useState<ThemeName | 'salt'>(initialTheme);
  const [currentTheme, setCurrentTheme] = useState<ClientTheme | null>(
    initialTheme === 'salt' ? null : availableThemes[initialTheme as ThemeName]
  );

  // Apply CSS custom properties to the document root
  const applyCSSVariables = (theme: ClientTheme | null) => {
    const root = document.documentElement;
    
    if (!theme) {
      // Reset to Salt defaults by removing custom properties
      const customProperties = [
        '--brand-color-primary',
        '--brand-color-secondary',
        '--brand-color-accent',
        '--brand-color-background',
        '--brand-color-surface',
        '--brand-color-text-primary',
        '--brand-color-text-secondary',
        '--brand-color-text-inverse',
        '--brand-color-success',
        '--brand-color-warning',
        '--brand-color-error',
        '--brand-color-info',
        '--brand-font-family',
        '--brand-font-size-small',
        '--brand-font-size-base',
        '--brand-font-size-large',
        '--brand-font-size-xlarge',
        '--brand-font-weight-normal',
        '--brand-font-weight-medium',
        '--brand-font-weight-semibold',
        '--brand-font-weight-bold',
        '--brand-spacing-xs',
        '--brand-spacing-sm',
        '--brand-spacing-md',
        '--brand-spacing-lg',
        '--brand-spacing-xl',
        '--brand-spacing-xxl',
        '--brand-border-radius-sm',
        '--brand-border-radius-md',
        '--brand-border-radius-lg',
        '--brand-shadow-sm',
        '--brand-shadow-md',
        '--brand-shadow-lg',
        '--brand-theme-name'
      ];
      
      customProperties.forEach(property => {
        root.style.removeProperty(property);
      });
      
      root.style.setProperty('--brand-theme-name', 'salt');
      return;
    }
    
    // Apply custom theme variables
    root.style.setProperty('--brand-color-primary', theme.colors.primary);
    root.style.setProperty('--brand-color-secondary', theme.colors.secondary);
    root.style.setProperty('--brand-color-accent', theme.colors.accent);
    root.style.setProperty('--brand-color-background', theme.colors.background);
    root.style.setProperty('--brand-color-surface', theme.colors.surface);
    root.style.setProperty('--brand-color-text-primary', theme.colors.text.primary);
    root.style.setProperty('--brand-color-text-secondary', theme.colors.text.secondary);
    root.style.setProperty('--brand-color-text-inverse', theme.colors.text.inverse);
    root.style.setProperty('--brand-color-success', theme.colors.status.success);
    root.style.setProperty('--brand-color-warning', theme.colors.status.warning);
    root.style.setProperty('--brand-color-error', theme.colors.status.error);
    root.style.setProperty('--brand-color-info', theme.colors.status.info);

    // Apply typography variables
    root.style.setProperty('--brand-font-family', theme.typography.fontFamily);
    root.style.setProperty('--brand-font-size-small', theme.typography.fontSize.small);
    root.style.setProperty('--brand-font-size-base', theme.typography.fontSize.base);
    root.style.setProperty('--brand-font-size-large', theme.typography.fontSize.large);
    root.style.setProperty('--brand-font-size-xlarge', theme.typography.fontSize.xlarge);
    root.style.setProperty('--brand-font-weight-normal', theme.typography.fontWeight.normal);
    root.style.setProperty('--brand-font-weight-medium', theme.typography.fontWeight.medium);
    root.style.setProperty('--brand-font-weight-semibold', theme.typography.fontWeight.semibold);
    root.style.setProperty('--brand-font-weight-bold', theme.typography.fontWeight.bold);

    // Apply spacing variables
    root.style.setProperty('--brand-spacing-xs', theme.spacing.xs);
    root.style.setProperty('--brand-spacing-sm', theme.spacing.sm);
    root.style.setProperty('--brand-spacing-md', theme.spacing.md);
    root.style.setProperty('--brand-spacing-lg', theme.spacing.lg);
    root.style.setProperty('--brand-spacing-xl', theme.spacing.xl);
    root.style.setProperty('--brand-spacing-xxl', theme.spacing.xxl);

    // Apply border radius variables
    root.style.setProperty('--brand-border-radius-sm', theme.borderRadius.sm);
    root.style.setProperty('--brand-border-radius-md', theme.borderRadius.md);
    root.style.setProperty('--brand-border-radius-lg', theme.borderRadius.lg);

    // Apply shadow variables
    root.style.setProperty('--brand-shadow-sm', theme.shadows.sm);
    root.style.setProperty('--brand-shadow-md', theme.shadows.md);
    root.style.setProperty('--brand-shadow-lg', theme.shadows.lg);

    // Set theme name as a CSS custom property for potential conditional styling
    root.style.setProperty('--brand-theme-name', theme.name);
  };

  const setTheme = (newThemeName: ThemeName | 'salt') => {
    if (newThemeName === 'salt') {
      setThemeName('salt');
      setCurrentTheme(null);
      applyCSSVariables(null);
    } else {
      setThemeName(newThemeName);
      const newTheme = availableThemes[newThemeName];
      setCurrentTheme(newTheme);
      applyCSSVariables(newTheme);
    }
    
    // Store theme preference in localStorage for persistence
    localStorage.setItem('selectedTheme', newThemeName);
  };

  // Initialize theme from localStorage or use default
  useEffect(() => {
    const savedTheme = localStorage.getItem('selectedTheme') as (ThemeName | 'salt');
    if (savedTheme === 'salt') {
      setTheme('salt');
    } else if (savedTheme && availableThemes[savedTheme as ThemeName]) {
      setTheme(savedTheme as ThemeName);
    } else {
      // Default to salt theme
      applyCSSVariables(null);
    }
  }, []);

  const contextValue: ThemeContextType = {
    currentTheme,
    themeName,
    setTheme,
    availableThemes,
    isCustomThemeActive: currentTheme !== null,
  };

  return (
    <BrandingThemeContext.Provider value={contextValue}>
      {children}
    </BrandingThemeContext.Provider>
  );
};
