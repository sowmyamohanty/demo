import { ThemeName } from './themeConfig';

export interface EmbedConfig {
  theme?: ThemeName;
  showThemeSelector?: boolean;
  clientId?: string;
  containerElement?: HTMLElement;
  onComplete?: (data: any) => void;
  onCancel?: () => void;
  onError?: (error: Error) => void;
}

/**
 * Utility function for embedding the Bank Account Linking experience
 * This can be used by clients to easily integrate the component with their branding
 */
export const embedBankAccountLinking = (config: EmbedConfig = {}) => {
  const {
    theme = 'jpmorgan',
    showThemeSelector = false, // Default to false for production embeds
    clientId,
    containerElement,
    onComplete,
    onCancel,
    onError
  } = config;

  // Example of how this could be used:
  // 1. Client includes this as a script tag
  // 2. Client calls embedBankAccountLinking with their config
  // 3. The component renders with their branding

  console.log('Embedding Bank Account Linking with config:', {
    theme,
    showThemeSelector,
    clientId
  });

  // In a real implementation, this would:
  // - Create a React root in the container element
  // - Render the App component with the specified config
  // - Set up event listeners for communication with parent
  
  return {
    theme,
    showThemeSelector,
    clientId,
    destroy: () => {
      // Cleanup function to remove the embedded component
      console.log('Cleaning up embedded component');
    }
  };
};

/**
 * Message types for iframe communication
 */
export interface IFrameMessage {
  type: 'SET_THEME' | 'ACCOUNT_LINKED' | 'CANCELLED' | 'ERROR';
  theme?: ThemeName;
  data?: any;
  error?: string;
}

/**
 * Helper for sending messages to parent window (when embedded in iframe)
 */
export const sendMessageToParent = (message: IFrameMessage, targetOrigin = '*') => {
  if (window.parent && window.parent !== window) {
    window.parent.postMessage(message, targetOrigin);
  }
};

/**
 * Helper for clients to send theme changes to the embedded iframe
 */
export const sendThemeToIframe = (iframe: HTMLIFrameElement, theme: ThemeName) => {
  const message: IFrameMessage = {
    type: 'SET_THEME',
    theme
  };
  
  if (iframe.contentWindow) {
    iframe.contentWindow.postMessage(message, '*');
  }
};

/**
 * Demo URLs for testing different themes
 */
export const getDemoUrls = (baseUrl: string) => ({
  jpmorgan: `${baseUrl}?theme=jpmorgan`,
  fintech: `${baseUrl}?theme=fintech`,
  banking: `${baseUrl}?theme=banking`,
});
