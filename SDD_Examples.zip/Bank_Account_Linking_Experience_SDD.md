# Solution Design Document (SDD)

## Bank Account Linking Experience

**Document Version:** 1.0  
**Date:** August 27, 2025  
**Author:** UI Solution Architecture Team  
**Status:** Draft

---

## Table of Contents

1. [Introduction](#1-introduction)
   1. [Purpose](#11-purpose)
   2. [Scope](#12-scope)
   3. [Definitions, Acronyms, and Abbreviations](#13-definitions-acronyms-and-abbreviations)
   4. [References](#14-references)

2. [System Overview](#2-system-overview)
   1. [System Context](#21-system-context)
   2. [System Architecture](#22-system-architecture)
   3. [User Characteristics](#23-user-characteristics)

3. [Design Considerations](#3-design-considerations)
   1. [Assumptions and Dependencies](#31-assumptions-and-dependencies)
   2. [Constraints](#32-constraints)
   3. [Design Principles](#33-design-principles)

4. [Architectural Design](#4-architectural-design)
   1. [Component Architecture](#41-component-architecture)
   2. [Data Architecture](#42-data-architecture)
   3. [Interface Design](#43-interface-design)
   4. [Security Architecture](#44-security-architecture)
   5. [Performance Considerations](#45-performance-considerations)

5. [User Interface Design](#5-user-interface-design)
   1. [User Flow](#51-user-flow)
   2. [UI Components](#52-ui-components)
   3. [Responsive Design Strategy](#53-responsive-design-strategy)
   4. [Accessibility Features](#54-accessibility-features)

6. [Technical Implementation](#6-technical-implementation)
   1. [Technology Stack](#61-technology-stack)
   2. [API Integration](#62-api-integration)
   3. [State Management](#63-state-management)
   4. [Error Handling](#64-error-handling)
   5. [Logging and Analytics](#65-logging-and-analytics)

7. [Testing Strategy](#7-testing-strategy)
   1. [Unit Testing](#71-unit-testing)
   2. [Integration Testing](#72-integration-testing)
   3. [UI/UX Testing](#73-uiux-testing)
   4. [Security Testing](#74-security-testing)
   5. [Performance Testing](#75-performance-testing)

8. [Deployment Strategy](#8-deployment-strategy)
   1. [Deployment Pipeline](#81-deployment-pipeline)
   2. [Environment Configuration](#82-environment-configuration)
   3. [Versioning Strategy](#83-versioning-strategy)

9. [Maintenance and Support](#9-maintenance-and-support)
   1. [Monitoring](#91-monitoring)
   2. [Issue Resolution](#92-issue-resolution)
   3. [Update Strategy](#93-update-strategy)

10. [Appendices](#10-appendices)
    1. [API Documentation](#101-api-documentation)
    2. [Wireframes](#102-wireframes)
    3. [Technical Diagrams](#103-technical-diagrams)

---

## 1. Introduction

### 1.1 Purpose

This Solution Design Document (SDD) describes the architectural design and technical implementation details for the Bank Account Linking Experience. It serves as a comprehensive guide for development, testing, deployment, and maintenance of the solution, ensuring alignment with business objectives and technical requirements.

### 1.2 Scope

The Bank Account Linking Experience is a responsive UI solution that allows merchants to launch a secure bank account linking flow for their users. The solution is embeddable within an iframe or popup and adaptable across multiple devices and platforms. This document covers all aspects of the solution design, from user interface flow to technical implementation details.

### 1.3 Definitions, Acronyms, and Abbreviations

- **FI**: Financial Institution
- **UI**: User Interface
- **SDD**: Solution Design Document
- **API**: Application Programming Interface
- **CSP**: Content Security Policy
- **WCAG**: Web Content Accessibility Guidelines
- **OAuth**: Open Authorization standard
- **DOM**: Document Object Model

### 1.4 References

- WCAG 2.1 AA Standards
- JPMorgan Chase Salt Design System Documentation
- React and TypeScript Documentation
- OAuth 2.0 Framework Specifications

---

## 2. System Overview

### 2.1 System Context

The Bank Account Linking Experience is a component within a larger merchant payment ecosystem. It serves as a bridge between the merchant's platform and the user's financial institutions, facilitating secure bank account linking for payment processing.

![System Context Diagram]

#### Integration Points:
1. **Merchant Platform**: Embeds the Bank Account Linking UI via iframe or popup
2. **Financial Institutions**: Provide authentication services via legacy login or OAuth
3. **Mastercard Connect API**: Powers the FI data retrieval and authentication flows

### 2.2 System Architecture

The Bank Account Linking Experience follows a modular, component-based architecture adhering to industry best practices for front-end development.

![System Architecture Diagram]

#### Key Architectural Components:
1. **Presentation Layer**: React components using Salt Design System
2. **Application Layer**: Business logic, state management, API integration
3. **Communication Layer**: Security protocols, postMessage communication
4. **API Integration Layer**: Interface with Mastercard Connect API

### 2.3 User Characteristics

The system is designed for end-users of merchant applications who need to link their bank accounts for payment processing. Users may have varying levels of technical expertise and will access the application across different devices and platforms.

---

## 3. Design Considerations

### 3.1 Assumptions and Dependencies

#### Assumptions:
- Merchants have implemented the necessary backend infrastructure to support the UI integration
- Users have active accounts with their financial institutions
- Financial institutions provide the necessary APIs for authentication and account access

#### Dependencies:
- Mastercard Connect Components API for rendering legacy FI login
- Mastercard API for OAuth details
- JPMorgan Chase Salt Design System
- Backend API services for FI data and authentication flows

### 3.2 Constraints

- The UI must be embeddable within an iframe or popup
- All communications must occur through secure channels
- The solution must maintain compatibility across multiple browsers and devices
- The system must comply with financial industry security standards and regulations

### 3.3 Design Principles

1. **Security First**: All design decisions prioritize the security of user data and session management
2. **User-Centric Design**: Interface is intuitive and accessible across different user capabilities
3. **Responsive Design**: UI adapts seamlessly to different device form factors
4. **Performance Optimization**: Efficient resource usage, especially for large data sets
5. **Modularity**: Components are designed for reusability and maintainability

---

## 4. Architectural Design

### 4.1 Component Architecture

The solution follows a modular component architecture based on React. Components are organized in a hierarchical structure, promoting reusability and maintainability.

#### Core Components:
1. **SessionManager**: Handles session creation, persistence, and security
2. **ConsentModule**: Manages user consent collection and validation
3. **FISelector**: Handles FI search, selection, and display logic
4. **AuthenticationHandler**: Manages legacy and OAuth authentication flows
5. **AccountSelector**: Presents and captures account type selection
6. **SuccessHandler**: Manages success state and redirect logic

![Component Architecture Diagram]

#### Component Interactions:
```
SessionManager
├── ConsentModule
├── FISelector
│   └── VirtualizedList
├── AuthenticationHandler
│   ├── LegacyAuthComponent
│   └── OAuthRedirectComponent
├── AccountSelector
└── SuccessHandler
```

### 4.2 Data Architecture

The application maintains a hierarchical state structure that represents the current state of the user's progress through the account linking flow.

#### Key Data Objects:
1. **Session**: Contains session identifiers and security tokens
2. **User**: User identification and consent status
3. **SelectedFI**: Information about the selected financial institution
4. **AuthState**: Authentication status and tokens
5. **SelectedAccounts**: User-selected accounts for linking

#### State Transitions:
```
Initial State
└── Consent Given
    └── FI Selected
        └── Authentication Complete
            └── Accounts Selected
                └── Linking Complete
```

### 4.3 Interface Design

#### External Interfaces:
1. **Merchant Interface**: 
   - Embedding mechanism via iframe or popup
   - PostMessage communication protocol for secure data exchange
   - Session initialization and completion events

2. **Mastercard API Interface**:
   - FI data retrieval with pagination support
   - Authentication flow initiation (legacy and OAuth)
   - Account information retrieval

#### Internal Interfaces:
1. **Component Interfaces**: Clearly defined props and event handlers for component communication
2. **Service Interfaces**: Abstracted API calls and business logic functions

### 4.4 Security Architecture

Security is paramount in the design of the Bank Account Linking Experience. The solution implements multiple layers of security to protect user data and ensure secure communication.

#### Key Security Features:
1. **Session Security**:
   - Unique session identifiers
   - Token-based authentication
   - Session timeout mechanisms
   - Anti-CSRF measures

2. **Communication Security**:
   - Secure postMessage() implementation with origin validation
   - Content Security Policy (CSP) implementation
   - HTTPS-only communication
   - Data encryption for sensitive information

3. **Authentication Security**:
   - OAuth 2.0 implementation for supported FIs
   - Secure credential handling for legacy authentication
   - Token management and rotation

4. **Data Protection**:
   - Minimized data collection principle
   - Data transit encryption
   - No persistent storage of sensitive information on client-side

### 4.5 Performance Considerations

The solution is designed to maintain high performance across various devices and network conditions.

#### Performance Optimizations:
1. **Virtualized Lists**: Implementation of virtualized rendering for FI selection to optimize DOM performance
2. **Lazy Loading**: Components and resources loaded only when needed
3. **Code Splitting**: Application bundle split by route to reduce initial load time
4. **Resource Optimization**: Image optimization, minification, and compression of static assets
5. **Caching Strategy**: Strategic caching of API responses and static resources

---

## 5. User Interface Design

### 5.1 User Flow

The user flow is designed to be intuitive and efficient, guiding users through the account linking process with minimal friction.

![User Flow Diagram]

#### Flow Sequence:
1. **Launch**: Merchant initiates the flow, opening the UI in an iframe or popup
2. **Consent**: User reviews and accepts the consent agreement
3. **FI Selection**: User searches for and selects their financial institution
4. **Authentication**: User logs in to their FI via legacy or OAuth flow
5. **Account Selection**: User selects which accounts to link
6. **Success & Redirect**: User sees confirmation and returns to merchant application

### 5.2 UI Components

#### Screen 1: User Consent
- **Components**:
  - Header with branding
  - Accordion-based consent text
  - Primary "Continue" button
  - Secondary "Cancel" button

#### Screen 2: FI Selection
- **Components**:
  - Search input with autocomplete
  - Virtualized list of popular FIs
  - Search results with pagination
  - Manual connection option
  - Loading states and feedback

#### Screen 3A: Legacy FI Login
- **Components**:
  - Mastercard Connect Components integration
  - Secure form fields for credentials
  - Authentication feedback indicators
  - Back button and cancel options

#### Screen 3B: OAuth FI Login
- **Components**:
  - Redirect information
  - Security assurance messaging
  - Progress indicators

#### Screen 4: Account Type Selection
- **Components**:
  - List of available accounts
  - Selection checkboxes
  - Account details display
  - Continue and back buttons

#### Screen 5: Success & Redirect
- **Components**:
  - Success confirmation message
  - Animation/visual feedback
  - Auto-redirect countdown
  - Manual return option

### 5.3 Responsive Design Strategy

The UI is designed following a mobile-first approach, ensuring optimal user experience across all device types.

#### Responsive Breakpoints:
- **Small** (< 600px): Mobile devices, single-column layout
- **Medium** (600px - 960px): Tablets, two-column layout where appropriate
- **Large** (> 960px): Desktops, optimized multi-column layout

#### Responsive Techniques:
1. **Fluid Grids**: Proportional sizing using relative units (%, rem)
2. **Flexible Images**: Images scale proportionally to container size
3. **Media Queries**: Targeted style adjustments for different viewport sizes
4. **Touch-Friendly UI**: Larger hit areas and appropriate spacing on touch devices
5. **Orientation Support**: Handling of both portrait and landscape orientations

### 5.4 Accessibility Features

The solution adheres to WCAG 2.1 AA standards, ensuring accessibility for users with diverse needs.

#### Accessibility Implementation:
1. **Keyboard Navigation**: Full functionality available through keyboard
2. **Screen Reader Support**: ARIA attributes and semantic HTML
3. **Color Contrast**: Meeting WCAG AA contrast ratio requirements
4. **Text Scaling**: Support for browser text scaling without loss of functionality
5. **Focus Management**: Visible focus indicators and logical tab order
6. **Error Identification**: Clear error messages with suggestions for resolution

---

## 6. Technical Implementation

### 6.1 Technology Stack

#### Core Technologies:
- **Frontend Framework**: React with TypeScript
- **Design System**: JPMorgan Chase Salt Design System
- **State Management**: React Context API with custom hooks
- **UI Testing**: Jest and React Testing Library
- **Build Tools**: Webpack, Babel, ESLint

#### Supporting Libraries:
- **React Virtual**: For virtualized list implementation
- **Axios**: For API communications
- **React Router**: For internal navigation
- **date-fns**: For date manipulation
- **Zod**: For runtime type validation

### 6.2 API Integration

The solution integrates with multiple APIs to provide the necessary functionality.

#### API Endpoints:
1. **Session Management API**:
   - `POST /api/sessions`: Create new session
   - `GET /api/sessions/{sessionId}`: Retrieve session status
   - `PUT /api/sessions/{sessionId}`: Update session state

2. **FI Data API**:
   - `GET /api/fi/popular`: Retrieve list of popular FIs
   - `GET /api/fi/search?q={query}&page={page}&limit={limit}`: Search FIs with pagination

3. **Authentication API**:
   - `POST /api/auth/legacy/{fiId}`: Initiate legacy authentication
   - `GET /api/auth/oauth/{fiId}`: Get OAuth details for redirect
   - `GET /api/auth/callback`: Handle OAuth callback

4. **Account API**:
   - `GET /api/accounts/{fiId}`: Retrieve available accounts
   - `POST /api/accounts/link`: Link selected accounts

#### API Integration Strategy:
1. **Abstraction Layer**: Service classes that encapsulate API logic
2. **Request/Response Handling**: Standardized error handling and response parsing
3. **Retry Logic**: Intelligent retry for transient failures
4. **Caching**: Strategic caching of responses where appropriate
5. **Authentication**: Automatic token handling and renewal

### 6.3 State Management

The application uses a combination of React Context API and custom hooks for state management, providing a clean and maintainable approach to handling application state.

#### State Structure:
```typescript
interface AppState {
  session: {
    id: string;
    status: 'initializing' | 'active' | 'expired' | 'completed';
    token: string;
  };
  user: {
    consentGiven: boolean;
    timestamp: string;
  };
  fi: {
    selected: FI | null;
    searchResults: FI[];
    popularFIs: FI[];
    searchQuery: string;
    pagination: {
      currentPage: number;
      totalPages: number;
      limit: number;
    };
  };
  authentication: {
    method: 'legacy' | 'oauth' | null;
    status: 'idle' | 'pending' | 'success' | 'error';
    errorMessage: string | null;
    oauthRedirectUrl: string | null;
  };
  accounts: {
    available: Account[];
    selected: string[];
    loading: boolean;
  };
  ui: {
    currentStep: 'consent' | 'fiSelection' | 'authentication' | 'accountSelection' | 'success';
    errors: Record<string, string>;
    isLoading: boolean;
  };
}
```

#### State Management Implementation:
1. **Context Providers**: Hierarchical contexts for different state domains
2. **Custom Hooks**: Encapsulated state logic for reuse across components
3. **Reducers**: Action-based state updates for predictable state transitions
4. **Selectors**: Memoized state selection to prevent unnecessary renders
5. **Persistence**: Session storage for state persistence across page refreshes

### 6.4 Error Handling

The solution implements a comprehensive error handling strategy to ensure robustness and provide clear feedback to users.

#### Error Types:
1. **Network Errors**: Failed API requests, timeouts
2. **Authentication Errors**: Invalid credentials, expired sessions
3. **Validation Errors**: Invalid input, missing required fields
4. **System Errors**: Unexpected application errors
5. **Business Logic Errors**: Process-specific failures

#### Error Handling Strategy:
1. **Global Error Boundary**: React error boundaries to catch rendering errors
2. **API Error Interceptors**: Centralized handling of API errors
3. **User-Friendly Messages**: Clear, actionable error messages for users
4. **Logging**: Detailed error logging for troubleshooting
5. **Recovery Options**: Clear paths for users to recover from errors
6. **Fallback UI**: Graceful degradation when components fail

### 6.5 Logging and Analytics

The solution includes comprehensive logging and analytics to track user behavior, monitor performance, and identify issues.

#### Logging Implementation:
1. **Application Logs**: System events, errors, and performance metrics
2. **User Action Logs**: User interactions and flow progression
3. **API Logs**: Request/response details and timing
4. **Error Logs**: Detailed error information with context

#### Analytics Events:
1. **Session Events**: Start, complete, abandon, timeout
2. **Step Completion**: Tracking progress through the flow
3. **Search Behavior**: FI search patterns and selection
4. **Error Encounters**: Types and frequency of errors
5. **Performance Metrics**: Load times, interaction delays

#### Implementation Strategy:
1. **Event Bus**: Centralized event emission system
2. **Batched Reporting**: Efficient event collection and transmission
3. **Sampling**: Performance monitoring for a subset of sessions
4. **Privacy Compliance**: Anonymization of sensitive data
5. **Real-time Alerts**: Notifications for critical issues

---

## 7. Testing Strategy

### 7.1 Unit Testing

Unit tests verify the functionality of individual components and functions in isolation.

#### Unit Testing Approach:
1. **Component Tests**: Verify rendering and behavior of UI components
2. **Service Tests**: Validate API service functions
3. **Utility Tests**: Ensure helper functions work correctly
4. **State Tests**: Verify state management logic

#### Testing Tools:
- Jest as the test runner
- React Testing Library for component testing
- Mock Service Worker for API mocking

### 7.2 Integration Testing

Integration tests verify that components work together correctly and that the application integrates properly with external systems.

#### Integration Testing Scope:
1. **Component Integration**: Testing interactions between related components
2. **API Integration**: Verifying correct API communication
3. **State Integration**: Testing state propagation across components
4. **Flow Integration**: Validating multi-step processes

#### Testing Approach:
- Custom test harnesses for component integration
- API mocking with realistic scenarios
- End-to-end tests for critical flows

### 7.3 UI/UX Testing

UI/UX testing ensures that the application provides a good user experience and meets design requirements.

#### UI/UX Testing Areas:
1. **Responsive Design**: Verification across device sizes
2. **Accessibility**: WCAG compliance testing
3. **Usability**: Task completion efficiency
4. **Visual Regression**: Ensuring UI consistency

#### Testing Tools:
- Storybook for component visualization and testing
- Cypress for end-to-end testing
- Axe for accessibility testing
- Percy for visual regression testing

### 7.4 Security Testing

Security testing identifies vulnerabilities and ensures that security measures are effective.

#### Security Testing Areas:
1. **Authentication**: Testing authentication flows
2. **Session Management**: Verifying session security
3. **Communication**: Testing secure communication
4. **Input Validation**: Preventing injection attacks
5. **CSP Compliance**: Verifying Content Security Policy effectiveness

#### Testing Approach:
- Automated scanning for common vulnerabilities
- Manual penetration testing
- Security code reviews
- Third-party security audits

### 7.5 Performance Testing

Performance testing ensures that the application meets performance requirements under various conditions.

#### Performance Testing Areas:
1. **Load Times**: Initial load and subsequent navigation
2. **Rendering Performance**: Smooth UI updates and animations
3. **API Response Handling**: Efficient processing of API responses
4. **Resource Usage**: Memory and CPU utilization

#### Testing Approach:
- Lighthouse for overall performance metrics
- Custom performance profiling for critical operations
- Simulated slow network conditions
- Device testing across performance tiers

---

## 8. Deployment Strategy

### 8.1 Deployment Pipeline

The solution uses a CI/CD pipeline for automated testing, building, and deployment.

#### Pipeline Stages:
1. **Build**: Compiling TypeScript, bundling assets
2. **Test**: Running unit, integration, and E2E tests
3. **Security Scan**: Static analysis and dependency scanning
4. **Performance Testing**: Automated performance benchmarking
5. **Staging Deployment**: Deployment to staging environment
6. **Production Deployment**: Controlled rollout to production

#### CI/CD Tools:
- GitHub Actions for workflow automation
- Docker for containerization
- AWS/Azure for hosting infrastructure

### 8.2 Environment Configuration

The solution supports multiple environments with appropriate configuration for each.

#### Environment Types:
1. **Development**: Local development environment
2. **Testing**: Automated test environment
3. **Staging**: Pre-production validation
4. **Production**: Live environment

#### Configuration Management:
1. **Environment Variables**: Runtime configuration
2. **Feature Flags**: Controlled feature rollout
3. **API Endpoints**: Environment-specific API configuration
4. **Logging Levels**: Adjusted per environment

### 8.3 Versioning Strategy

The solution follows semantic versioning (SemVer) to communicate the nature of changes.

#### Version Components:
1. **Major Version**: Incompatible API changes
2. **Minor Version**: New features, backward-compatible
3. **Patch Version**: Bug fixes, backward-compatible

#### Versioning Implementation:
1. **API Versioning**: Explicit API version in URLs
2. **Client Versioning**: Client-side version checking
3. **Deployment Tagging**: Git tags for releases
4. **Changelog**: Detailed change documentation

---

## 9. Maintenance and Support

### 9.1 Monitoring

The solution includes comprehensive monitoring to ensure reliability and performance.

#### Monitoring Areas:
1. **Application Health**: Overall system status
2. **Performance Metrics**: Response times, load times
3. **Error Rates**: Frequency and types of errors
4. **User Behavior**: Flow completion rates
5. **Resource Utilization**: Server and client resource usage

#### Monitoring Tools:
- Application Performance Monitoring (APM) solution
- Real User Monitoring (RUM)
- Custom dashboards for key metrics
- Alerting for critical issues

### 9.2 Issue Resolution

The solution includes a structured approach to identifying and resolving issues.

#### Issue Resolution Process:
1. **Detection**: Monitoring alerts or user reports
2. **Triage**: Severity assessment and prioritization
3. **Diagnosis**: Root cause analysis
4. **Resolution**: Implementation of fixes
5. **Verification**: Testing of resolved issues
6. **Communication**: Updates to stakeholders

#### Support Tools:
- Issue tracking system
- Diagnostic logging
- Support knowledge base
- Incident response playbooks

### 9.3 Update Strategy

The solution follows a structured approach to implementing updates and improvements.

#### Update Types:
1. **Security Updates**: Critical security patches
2. **Bug Fixes**: Corrections for identified issues
3. **Feature Enhancements**: New or improved functionality
4. **Performance Improvements**: Optimizations and efficiency gains

#### Update Process:
1. **Planning**: Scope definition and impact assessment
2. **Development**: Implementation and internal testing
3. **User Validation**: Beta testing or previews where appropriate
4. **Rollout**: Phased deployment with monitoring
5. **Feedback Collection**: User response to changes

---

## 10. Appendices

### 10.1 API Documentation

Detailed documentation of all API endpoints, including:
- Request and response formats
- Authentication requirements
- Error codes and handling
- Rate limits and performance characteristics

### 10.2 Wireframes

High-fidelity wireframes for all screens in the application:
- User Consent screen
- FI Selection screen
- Legacy Authentication screen
- OAuth Authentication screen
- Account Selection screen
- Success screen

### 10.3 Technical Diagrams

Supporting diagrams for technical implementation:
- Component hierarchy diagram
- State transition diagram
- Data flow diagram
- Sequence diagrams for key processes
- Architecture diagram
