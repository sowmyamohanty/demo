# Bank Account Linking Experience - Comprehensive Solution Design Document V4.0

**Document Version:** 4.0  
**Date:** August 27, 2025  
**Focus:** Complete Implementation Plan with Three Integration Flows  
**Status:** Draft

## Table of Contents
1. [Executive Summary](#1-executive-summary)
2. [System Architecture](#2-system-architecture)
3. [Flow Diagrams](#3-flow-diagrams)
4. [Implementation Steps](#4-implementation-steps)
5. [API Specifications](#5-api-specifications)
6. [UI Component Design](#6-ui-component-design)
7. [Integration Patterns](#7-integration-patterns)
8. [Testing Strategy](#8-testing-strategy)
9. [Deployment and Monitoring](#9-deployment-and-monitoring)

## 1. Executive Summary

The Bank Account Linking Experience provides three distinct integration flows to accommodate different Financial Institution (FI) capabilities:
- **Legacy Bank Integration** via Mastercard Connect Components
- **OAuth Bank Integration** via Mastercard Connect OAuth
- **Manual Account Linking** with micro-deposit verification

### 1.1 Key Objectives
- Seamless iframe integration for merchants
- Support for multiple authentication methods
- Performance-optimized UI with virtualized components
- Comprehensive error handling and recovery

## 2. System Architecture

### 2.1 High-Level Architecture Diagram

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Merchant      │    │  Account Linking │    │   Backend       │
│   Website       │    │  UI (iframe)     │    │   Services      │
│                 │    │                  │    │                 │
│  ┌───────────┐  │    │  ┌─────────────┐ │    │  ┌───────────┐  │
│  │   Link    │──┼────┼─▶│  Session    │ │    │  │  Session  │  │
│  │  Account  │  │    │  │  Manager    │ │    │  │    API    │  │
│  │  Button   │  │    │  └─────────────┘ │    │  └───────────┘  │
│  └───────────┘  │    │                  │    │                 │
│                 │    │  ┌─────────────┐ │    │  ┌───────────┐  │
│                 │    │  │   UI Flow   │ │    │  │    FI     │  │
│                 │    │  │  Components │ │    │  │ Search API│  │
│                 │    │  └─────────────┘ │    │  └───────────┘  │
│                 │    │                  │    │                 │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                                │
                                │
                ┌───────────────┼───────────────┐
                │               │               │
      ┌─────────▼────┐  ┌──────▼──────┐  ┌────▼─────────┐
      │ Mastercard   │  │ Mastercard  │  │ Micro-deposit│
      │ Connect      │  │ Connect     │  │ Verification │
      │ (Legacy)     │  │ (OAuth)     │  │ Service      │
      └──────────────┘  └─────────────┘  └──────────────┘
```

### 2.2 Component Architecture

```typescript
interface SystemComponents {
  merchant: {
    website: MerchantWebsite;
    integration: IframeIntegration;
  };
  ui: {
    sessionManager: SessionManager;
    flowController: FlowController;
    screens: UIScreens;
  };
  backend: {
    sessionAPI: SessionAPI;
    fiSearchAPI: FISearchAPI;
    accountAPI: AccountAPI;
  };
  external: {
    mastercardConnect: MastercardConnectAPI;
    microDeposits: MicroDepositService;
  };
}
```

## 3. Flow Diagrams

### 3.1 Complete User Journey Flow

```mermaid
graph TD
    A[Merchant Site] --> B[API Call with Session ID]
    B --> C[Get UI URL]
    C --> D[Launch iframe with UI URL]
    D --> E[User Consent Screen]
    E --> F[FI Selection Screen]
    
    F --> G{User Choice}
    G -->|Search FI| H[Search & Select FI]
    G -->|Popular FI| I[Select Popular FI]
    G -->|Manual Link| J[Manual Account Linking]
    
    H --> K{FI Type?}
    I --> K
    
    K -->|Legacy| L[Mastercard Connect Login]
    K -->|OAuth| M[OAuth Redirect Flow]
    
    L --> N[Account Type Selection]
    M --> N
    
    J --> O[Enter Account/Routing Numbers]
    O --> P[Micro-deposit Check]
    P --> Q{Micro-deposits?}
    Q -->|Yes| R[Deposit Amount Challenge]
    Q -->|No| S[Direct Account Fetch]
    R --> S
    S --> N
    
    N --> T[Success Screen]
    T --> U[Return to Merchant]
```

### 3.2 Session Management Flow

```mermaid
sequenceDiagram
    participant M as Merchant
    participant B as Backend
    participant UI as UI Component
    participant S as Session Store
    
    M->>B: POST /api/sessions {merchantId, userId}
    B->>S: Create Session
    S-->>B: sessionId, token
    B-->>M: {sessionId, uiUrl}
    
    M->>UI: Launch iframe with uiUrl
    UI->>B: Validate session
    B->>S: Check session validity
    S-->>B: session details
    B-->>UI: session confirmed
    
    Note over UI,S: Session heartbeat every 30s
    UI->>B: POST /heartbeat {sessionId}
    B->>S: Update last activity
```

### 3.3 Legacy Bank Integration Flow

```mermaid
sequenceDiagram
    participant U as User
    participant UI as UI Component
    participant MC as Mastercard Connect
    participant FI as Financial Institution
    participant B as Backend
    
    U->>UI: Select Legacy Bank
    UI->>B: GET /api/fi/{fiId}/auth-method
    B-->>UI: {type: 'legacy'}
    
    UI->>MC: Initialize Connect Components
    MC->>FI: Load FI Login Form
    FI-->>MC: Render Login Form
    MC-->>UI: Display Login Form
    
    U->>MC: Enter Credentials
    MC->>FI: Authenticate User
    FI-->>MC: Authentication Success
    MC-->>UI: Success Callback
    
    UI->>B: GET /api/accounts/{fiId}
    B-->>UI: Available Accounts
    UI->>U: Display Account Selection
```

### 3.4 OAuth Integration Flow

```mermaid
sequenceDiagram
    participant U as User
    participant UI as UI Component
    participant P as OAuth Popup
    participant FI as Financial Institution
    participant B as Backend
    
    U->>UI: Select OAuth Bank
    UI->>B: GET /api/oauth/{fiId}/initiate
    B-->>UI: {oauthUrl, state, codeChallenge}
    
    UI->>P: Open popup with oauthUrl
    P->>FI: OAuth Authorization
    U->>FI: Login & Authorize
    FI-->>P: Redirect with auth code
    P->>UI: PostMessage success
    
    UI->>B: POST /api/oauth/callback {code, state}
    B->>FI: Exchange code for tokens
    FI-->>B: Access tokens
    B-->>UI: Authentication complete
    
    UI->>B: GET /api/accounts/{fiId}
    B-->>UI: Available Accounts
```

### 3.5 Manual Account Linking Flow

```mermaid
sequenceDiagram
    participant U as User
    participant UI as UI Component
    participant B as Backend
    participant MD as Micro-deposit Service
    
    U->>UI: Select Manual Linking
    UI->>U: Show Account Input Form
    U->>UI: Enter Account/Routing Numbers
    UI->>B: POST /api/accounts/validate {accountNum, routingNum}
    
    B->>MD: Check micro-deposit requirement
    MD-->>B: {required: true/false}
    
    alt Micro-deposits required
        B-->>UI: {microDepositsRequired: true}
        UI->>U: Show deposit challenge
        U->>UI: Enter deposit amounts
        UI->>B: POST /api/micro-deposits/verify
        B->>MD: Verify amounts
        MD-->>B: Verification result
    end
    
    B->>MD: Fetch account details
    MD-->>B: Account information
    B-->>UI: Available accounts
    UI->>U: Display account selection
```

## 4. Implementation Steps

### 4.1 Step 1: Session Management Implementation

```typescript
// Backend API Implementation
interface SessionCreateRequest {
  merchantId: string;
  userId?: string;
  metadata?: Record<string, unknown>;
}

interface SessionResponse {
  sessionId: string;
  uiUrl: string;
  expiresAt: string;
  token: string;
}

@Controller('/api/sessions')
export class SessionController {
  @Post()
  async createSession(@Body() request: SessionCreateRequest): Promise<SessionResponse> {
    const session = await this.sessionService.create(request);
    const uiUrl = `${process.env.UI_BASE_URL}/?sessionId=${session.id}&token=${session.token}`;
    
    return {
      sessionId: session.id,
      uiUrl,
      expiresAt: session.expiresAt.toISOString(),
      token: session.token
    };
  }

  @Post(':sessionId/heartbeat')
  async heartbeat(@Param('sessionId') sessionId: string): Promise<void> {
    await this.sessionService.updateLastActivity(sessionId);
  }
}
```

### 4.2 Step 2: iframe Integration

```typescript
// Merchant Integration Code
class AccountLinkingIntegration {
  private iframe: HTMLIFrameElement | null = null;

  async initializeAccountLinking(merchantId: string, userId?: string): Promise<void> {
    // Step 1: Create session
    const sessionResponse = await fetch('/api/sessions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ merchantId, userId })
    });
    
    const { uiUrl } = await sessionResponse.json();
    
    // Step 2: Create and configure iframe
    this.iframe = document.createElement('iframe');
    this.iframe.src = uiUrl;
    this.iframe.style.width = '100%';
    this.iframe.style.height = '600px';
    this.iframe.style.border = 'none';
    
    // Step 3: Set up message listener
    window.addEventListener('message', this.handleIframeMessage);
    
    // Step 4: Append to container
    const container = document.getElementById('account-linking-container');
    container?.appendChild(this.iframe);
  }

  private handleIframeMessage = (event: MessageEvent) => {
    if (event.data.type === 'ACCOUNT_LINKING_COMPLETE') {
      this.handleSuccess(event.data.payload);
      this.cleanup();
    } else if (event.data.type === 'ACCOUNT_LINKING_ERROR') {
      this.handleError(event.data.payload);
    }
  }
}
```

### 4.3 Step 3: User Consent Screen

```typescript
// UI Component Implementation
export const ConsentScreen: React.FC = () => {
  const { dispatch } = useAccountLinking();
  const [isAccordionExpanded, setIsAccordionExpanded] = useState(false);
  const [hasReadTerms, setHasReadTerms] = useState(false);

  const handleContinue = () => {
    // Analytics tracking
    Analytics.track({
      category: 'Session',
      action: 'consent_given',
      timestamp: Date.now()
    });

    dispatch({ type: 'SET_CONSENT', payload: true });
    dispatch({ type: 'SET_STEP', payload: 'fiSelection' });
  };

  return (
    <Card className="consent-screen">
      <Text variant="h1">Link Your Bank Account</Text>
      
      <Text variant="body" className="description">
        Securely connect your bank account to enable payments and transfers.
      </Text>

      <Accordion
        expanded={isAccordionExpanded}
        onChange={(_, expanded) => {
          setIsAccordionExpanded(expanded);
          if (expanded) setHasReadTerms(true);
        }}
      >
        <AccordionPanel title="Terms and Conditions">
          <div className="terms-content">
            <Text variant="body">
              By proceeding, you authorize us to:
            </Text>
            <ul>
              <li>Access your bank account information</li>
              <li>Verify your account ownership</li>
              <li>Maintain secure access for payment processing</li>
              <li>Store account details securely</li>
            </ul>
          </div>
        </AccordionPanel>
      </Accordion>

      <Button
        variant="cta"
        disabled={!hasReadTerms}
        onClick={handleContinue}
        className="continue-button"
      >
        I Agree & Continue
      </Button>
    </Card>
  );
};
```

### 4.4 Step 4: FI Selection Screen

```typescript
export const FISelectionScreen: React.FC = () => {
  const { dispatch } = useAccountLinking();
  const [searchQuery, setSearchQuery] = useState('');
  const [popularFIs, setPopularFIs] = useState<FinancialInstitution[]>([]);
  const [searchResults, setSearchResults] = useState<FinancialInstitution[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    loadPopularFIs();
  }, []);

  const loadPopularFIs = async () => {
    const response = await FIService.getPopularFIs();
    setPopularFIs(response.data);
  };

  const handleSearch = useMemo(
    () => debounce(async (query: string) => {
      if (query.length < 2) {
        setSearchResults([]);
        return;
      }

      setIsSearching(true);
      try {
        const response = await FIService.searchFIs(query);
        setSearchResults(response.data);
      } catch (error) {
        console.error('Search failed:', error);
      } finally {
        setIsSearching(false);
      }
    }, 300),
    []
  );

  const handleFISelect = (fi: FinancialInstitution) => {
    Analytics.track({
      category: 'FI',
      action: 'fi_selected',
      label: fi.name,
      metadata: { fiId: fi.id, searchQuery }
    });

    dispatch({ type: 'SET_SELECTED_FI', payload: fi });
    dispatch({ type: 'SET_STEP', payload: 'authentication' });
  };

  const handleManualLinking = () => {
    Analytics.track({
      category: 'FI',
      action: 'manual_linking_selected'
    });

    dispatch({ type: 'SET_STEP', payload: 'manualLinking' });
  };

  return (
    <div className="fi-selection-screen">
      <Text variant="h2">Select Your Bank</Text>
      
      <Input
        icon={<Search />}
        placeholder="Search for your bank..."
        value={searchQuery}
        onChange={(e) => {
          setSearchQuery(e.target.value);
          handleSearch(e.target.value);
        }}
        className="search-input"
      />

      {searchQuery ? (
        <SearchResults
          results={searchResults}
          isLoading={isSearching}
          onSelect={handleFISelect}
        />
      ) : (
        <PopularFIGrid
          fis={popularFIs}
          onSelect={handleFISelect}
        />
      )}

      <Button
        variant="secondary"
        onClick={handleManualLinking}
        className="manual-link-button"
      >
        Can't find your bank? Link manually
      </Button>
    </div>
  );
};

const PopularFIGrid: React.FC<{
  fis: FinancialInstitution[];
  onSelect: (fi: FinancialInstitution) => void;
}> = ({ fis, onSelect }) => {
  return (
    <div className="popular-fi-grid">
      <Text variant="h4">Popular Banks</Text>
      <div className="fi-grid">
        {fis.map(fi => (
          <Card
            key={fi.id}
            variant="clickable"
            onClick={() => onSelect(fi)}
            className="fi-card"
          >
            <div className="fi-logo">
              <img src={fi.logoUrl} alt={fi.name} />
            </div>
            <Text variant="body">{fi.name}</Text>
          </Card>
        ))}
      </div>
    </div>
  );
};
```

### 4.5 Step 5: Manual Account Linking Flow

```typescript
export const ManualLinkingScreen: React.FC = () => {
  const { dispatch } = useAccountLinking();
  const [formData, setFormData] = useState({
    accountNumber: '',
    routingNumber: ''
  });
  const [isValidating, setIsValidating] = useState(false);
  const [showMicroDepositChallenge, setShowMicroDepositChallenge] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsValidating(true);

    try {
      const response = await AccountService.validateAccount(formData);
      
      if (response.microDepositsRequired) {
        setShowMicroDepositChallenge(true);
      } else {
        // Direct to account selection
        const accounts = await AccountService.getAccountsByDetails(formData);
        dispatch({ type: 'SET_AVAILABLE_ACCOUNTS', payload: accounts });
        dispatch({ type: 'SET_STEP', payload: 'accountSelection' });
      }
    } catch (error) {
      // Handle validation errors
    } finally {
      setIsValidating(false);
    }
  };

  if (showMicroDepositChallenge) {
    return <MicroDepositChallenge accountDetails={formData} />;
  }

  return (
    <form onSubmit={handleSubmit} className="manual-linking-form">
      <Text variant="h2">Enter Account Details</Text>
      
      <Input
        label="Account Number"
        value={formData.accountNumber}
        onChange={(e) => setFormData(prev => ({
          ...prev,
          accountNumber: e.target.value
        }))}
        required
        type="text"
        inputMode="numeric"
        pattern="[0-9]*"
      />

      <Input
        label="Routing Number"
        value={formData.routingNumber}
        onChange={(e) => setFormData(prev => ({
          ...prev,
          routingNumber: e.target.value
        }))}
        required
        type="text"
        inputMode="numeric"
        pattern="[0-9]{9}"
        maxLength={9}
      />

      <Button
        type="submit"
        variant="cta"
        disabled={isValidating || !formData.accountNumber || !formData.routingNumber}
      >
        {isValidating ? 'Validating...' : 'Authorize'}
      </Button>
    </form>
  );
};

const MicroDepositChallenge: React.FC<{
  accountDetails: { accountNumber: string; routingNumber: string };
}> = ({ accountDetails }) => {
  const { dispatch } = useAccountLinking();
  const [deposits, setDeposits] = useState(['', '']);
  const [isVerifying, setIsVerifying] = useState(false);

  const handleVerification = async () => {
    setIsVerifying(true);
    try {
      await MicroDepositService.verify(accountDetails, deposits);
      const accounts = await AccountService.getAccountsByDetails(accountDetails);
      dispatch({ type: 'SET_AVAILABLE_ACCOUNTS', payload: accounts });
      dispatch({ type: 'SET_STEP', payload: 'accountSelection' });
    } catch (error) {
      // Handle verification error
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="micro-deposit-challenge">
      <Text variant="h2">Verify Micro-Deposits</Text>
      <Text variant="body">
        We've made two small deposits to your account. Please enter the amounts below.
      </Text>

      {deposits.map((amount, index) => (
        <Input
          key={index}
          label={`Deposit ${index + 1}`}
          value={amount}
          onChange={(e) => {
            const newDeposits = [...deposits];
            newDeposits[index] = e.target.value;
            setDeposits(newDeposits);
          }}
          placeholder="0.00"
          type="number"
          step="0.01"
          min="0"
          max="1"
        />
      ))}

      <Button
        onClick={handleVerification}
        disabled={isVerifying || deposits.some(d => !d)}
        variant="cta"
      >
        {isVerifying ? 'Verifying...' : 'Verify Deposits'}
      </Button>
    </div>
  );
};
```

### 4.6 Step 6: Legacy Bank Integration

```typescript
export const LegacyAuthenticationScreen: React.FC = () => {
  const { state, dispatch } = useAccountLinking();
  const [isInitialized, setIsInitialized] = useState(false);
  const connectContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (state.selectedFI && connectContainerRef.current) {
      initializeMastercardConnect();
    }
  }, [state.selectedFI]);

  const initializeMastercardConnect = async () => {
    try {
      const connectConfig = await AuthService.getLegacyAuthConfig(state.selectedFI!.id);
      
      // Initialize Mastercard Connect Components
      const connect = new MastercardConnect({
        containerId: 'mc-connect-container',
        fiId: state.selectedFI!.id,
        sessionToken: connectConfig.sessionToken,
        onSuccess: handleAuthSuccess,
        onError: handleAuthError
      });

      await connect.render();
      setIsInitialized(true);
    } catch (error) {
      console.error('Failed to initialize Mastercard Connect:', error);
    }
  };

  const handleAuthSuccess = async (authData: AuthSuccessData) => {
    Analytics.track({
      category: 'Authentication',
      action: 'legacy_auth_success',
      label: state.selectedFI!.name
    });

    try {
      const accounts = await AccountService.getAccountsFromAuth(authData);
      dispatch({ type: 'SET_AVAILABLE_ACCOUNTS', payload: accounts });
      dispatch({ type: 'SET_STEP', payload: 'accountSelection' });
    } catch (error) {
      handleAuthError(error);
    }
  };

  const handleAuthError = (error: AuthError) => {
    Analytics.track({
      category: 'Authentication',
      action: 'legacy_auth_error',
      label: error.code,
      metadata: { fiId: state.selectedFI!.id }
    });

    dispatch({
      type: 'SET_ERROR',
      payload: new Error(`Authentication failed: ${error.message}`)
    });
  };

  return (
    <div className="legacy-auth-screen">
      <Text variant="h2">Log in to {state.selectedFI?.name}</Text>
      
      <Card className="auth-container">
        {!isInitialized && (
          <div className="loading-state">
            <Spinner size="medium" />
            <Text>Loading secure login...</Text>
          </div>
        )}
        
        <div
          ref={connectContainerRef}
          id="mc-connect-container"
          className="connect-container"
        />
      </Card>
    </div>
  );
};
```

### 4.7 Step 7: OAuth Bank Integration

```typescript
export const OAuthAuthenticationScreen: React.FC = () => {
  const { state, dispatch } = useAccountLinking();
  const [authUrl, setAuthUrl] = useState<string>('');
  const [isRedirecting, setIsRedirecting] = useState(false);

  useEffect(() => {
    if (state.selectedFI) {
      initiateOAuthFlow();
    }
  }, [state.selectedFI]);

  const initiateOAuthFlow = async () => {
    try {
      const oauthConfig = await AuthService.getOAuthConfig(state.selectedFI!.id);
      setAuthUrl(oauthConfig.authUrl);
      
      // Set up message listener for OAuth callback
      window.addEventListener('message', handleOAuthCallback);
      
      // Open OAuth popup
      setTimeout(() => {
        openOAuthPopup(oauthConfig.authUrl);
      }, 1000);
    } catch (error) {
      console.error('Failed to initiate OAuth flow:', error);
    }
  };

  const openOAuthPopup = (url: string) => {
    setIsRedirecting(true);
    
    const popup = window.open(
      url,
      'oauth-popup',
      'width=600,height=700,scrollbars=yes,resizable=yes'
    );

    // Poll for popup closure
    const checkClosed = setInterval(() => {
      if (popup?.closed) {
        clearInterval(checkClosed);
        setIsRedirecting(false);
        // Handle popup closed without completion
      }
    }, 1000);
  };

  const handleOAuthCallback = async (event: MessageEvent) => {
    if (event.data.type === 'OAUTH_SUCCESS') {
      window.removeEventListener('message', handleOAuthCallback);
      
      Analytics.track({
        category: 'Authentication',
        action: 'oauth_success',
        label: state.selectedFI!.name
      });

      try {
        const accounts = await AccountService.getAccountsFromOAuth(event.data.authCode);
        dispatch({ type: 'SET_AVAILABLE_ACCOUNTS', payload: accounts });
        dispatch({ type: 'SET_STEP', payload: 'accountSelection' });
      } catch (error) {
        handleOAuthError(error);
      }
    } else if (event.data.type === 'OAUTH_ERROR') {
      handleOAuthError(event.data.error);
    }
  };

  const handleOAuthError = (error: any) => {
    Analytics.track({
      category: 'Authentication',
      action: 'oauth_error',
      metadata: { fiId: state.selectedFI!.id, error: error.message }
    });

    dispatch({
      type: 'SET_ERROR',
      payload: new Error(`OAuth authentication failed: ${error.message}`)
    });
  };

  return (
    <div className="oauth-auth-screen">
      <Text variant="h2">Connecting to {state.selectedFI?.name}</Text>
      
      <Card className="redirect-info">
        <div className="redirect-content">
          <Spinner size="large" />
          <Text variant="h4">Secure Login</Text>
          <Text variant="body">
            You will be redirected to your bank's secure login page.
            Please complete the authentication process and return here.
          </Text>
          
          {isRedirecting && (
            <Text variant="caption" className="redirect-status">
              Opening secure login window...
            </Text>
          )}
        </div>
      </Card>
    </div>
  );
};
```

## 5. API Specifications

### 5.1 Session Management APIs

```typescript
// POST /api/sessions
interface CreateSessionRequest {
  merchantId: string;
  userId?: string;
  metadata?: Record<string, unknown>;
}

interface CreateSessionResponse {
  sessionId: string;
  uiUrl: string;
  expiresAt: string;
  token: string;
}

// POST /api/sessions/{sessionId}/heartbeat
interface HeartbeatRequest {
  sessionId: string;
  timestamp: number;
}

// GET /api/sessions/{sessionId}
interface SessionDetailsResponse {
  sessionId: string;
  status: 'active' | 'expired' | 'completed';
  progress: {
    currentStep: string;
    completedSteps: string[];
  };
  linkedAccounts?: LinkedAccount[];
}
```

### 5.2 FI Search APIs

```typescript
// GET /api/fi/popular
interface PopularFIsResponse {
  data: FinancialInstitution[];
  metadata: {
    lastUpdated: string;
    region: string;
  };
}

// GET /api/fi/search?q={query}&page={page}&limit={limit}
interface FISearchResponse {
  data: FinancialInstitution[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    hasMore: boolean;
  };
}

interface FinancialInstitution {
  id: string;
  name: string;
  logoUrl: string;
  authType: 'legacy' | 'oauth';
  capabilities: {
    instantAuth: boolean;
    accountTypes: string[];
  };
}
```

### 5.3 Authentication APIs

```typescript
// GET /api/auth/legacy/{fiId}/config
interface LegacyAuthConfigResponse {
  sessionToken: string;
  connectConfig: {
    containerId: string;
    theme: object;
  };
}

// GET /api/auth/oauth/{fiId}/initiate
interface OAuthInitiateResponse {
  authUrl: string;
  state: string;
  codeChallenge: string;
  expiresIn: number;
}

// POST /api/auth/oauth/callback
interface OAuthCallbackRequest {
  code: string;
  state: string;
  sessionId: string;
}

interface OAuthCallbackResponse {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}
```

### 5.4 Account Management APIs

```typescript
// POST /api/accounts/validate
interface AccountValidationRequest {
  accountNumber: string;
  routingNumber: string;
  sessionId: string;
}

interface AccountValidationResponse {
  isValid: boolean;
  microDepositsRequired: boolean;
  estimatedDepositTime?: string;
}

// GET /api/accounts/{fiId}
interface AccountListResponse {
  accounts: BankAccount[];
  allowMultipleSelection: boolean;
}

interface BankAccount {
  id: string;
  type: 'checking' | 'savings' | 'money_market' | 'cd';
  name: string;
  maskedNumber: string;
  balance?: number;
  isEligible: boolean;
}

// POST /api/accounts/link
interface LinkAccountsRequest {
  sessionId: string;
  selectedAccountIds: string[];
  fiId?: string;
  manualDetails?: {
    accountNumber: string;
    routingNumber: string;
  };
}

interface LinkAccountsResponse {
  linkedAccounts: LinkedAccount[];
  status: 'completed' | 'pending_verification';
}
```

## 6. UI Component Design

### 6.1 Responsive Design System

```scss
// Responsive breakpoints
$breakpoints: (
  xs: 0,
  sm: 600px,
  md: 960px,
  lg: 1280px,
  xl: 1920px
);

// Container sizing
.account-linking-container {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: var(--salt-spacing-400);

  @media (max-width: 600px) {
    padding: var(--salt-spacing-200);
    max-width: 100%;
  }
}

// FI Grid responsive layout
.fi-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: var(--salt-spacing-300);

  @media (max-width: 600px) {
    grid-template-columns: repeat(2, 1fr);
    gap: var(--salt-spacing-200);
  }
}
```

### 6.2 Component Composition Pattern

```typescript
// Higher-order component for screen transitions
export const withScreenTransition = <P extends object>(
  Component: React.ComponentType<P>
) => {
  return (props: P) => {
    return (
      <div className="screen-transition">
        <Component {...props} />
      </div>
    );
  };
};

// Screen wrapper with common functionality
export const ScreenWrapper: React.FC<{
  title: string;
  children: React.ReactNode;
  onBack?: () => void;
  showProgress?: boolean;
}> = ({ title, children, onBack, showProgress = true }) => {
  return (
    <div className="screen-wrapper">
      <header className="screen-header">
        {onBack && (
          <Button variant="secondary" onClick={onBack}>
            <ArrowBack /> Back
          </Button>
        )}
        <Text variant="h1">{title}</Text>
        {showProgress && <StepIndicator />}
      </header>
      <main className="screen-content">
        {children}
      </main>
    </div>
  );
};
```

## 7. Integration Patterns

### 7.1 Mastercard Connect Integration

```typescript
interface MastercardConnectConfig {
  apiKey: string;
  environment: 'sandbox' | 'production';
  version: string;
}

class MastercardConnectService {
  private config: MastercardConnectConfig;
  private sdk: any;

  constructor(config: MastercardConnectConfig) {
    this.config = config;
    this.initializeSDK();
  }

  private async initializeSDK() {
    // Load Mastercard Connect SDK
    this.sdk = await this.loadMastercardSDK();
  }

  public async renderLegacyLogin(containerId: string, fiId: string): Promise<void> {
    const component = this.sdk.createLegacyAuthComponent({
      containerId,
      fiId,
      onSuccess: this.handleAuthSuccess,
      onError: this.handleAuthError,
      theme: {
        primaryColor: '#0073e6',
        fontFamily: 'var(--salt-typography-fontFamily)'
      }
    });

    await component.render();
  }

  public async initiateOAuthFlow(fiId: string): Promise<OAuthConfig> {
    return this.sdk.oauth.initiate({
      fiId,
      redirectUri: `${window.location.origin}/oauth-callback`,
      scopes: ['accounts:read', 'account_details:read']
    });
  }

  private handleAuthSuccess = (data: AuthSuccessData) => {
    window.dispatchEvent(new CustomEvent('mc-auth-success', { detail: data }));
  };

  private handleAuthError = (error: AuthError) => {
    window.dispatchEvent(new CustomEvent('mc-auth-error', { detail: error }));
  };
}
```

### 7.2 Error Handling Pattern

```typescript
interface ErrorHandlingStrategy {
  retry: boolean;
  maxRetries: number;
  fallback?: () => void;
  userMessage: string;
  technicalDetails: string;
}

const ERROR_STRATEGIES: Record<string, ErrorHandlingStrategy> = {
  'NETWORK_ERROR': {
    retry: true,
    maxRetries: 3,
    userMessage: 'Connection issue. Please try again.',
    technicalDetails: 'Network request failed'
  },
  'SESSION_EXPIRED': {
    retry: false,
    maxRetries: 0,
    fallback: () => window.location.reload(),
    userMessage: 'Your session has expired. Please start over.',
    technicalDetails: 'Session token invalid or expired'
  },
  'FI_UNAVAILABLE': {
    retry: true,
    maxRetries: 1,
    userMessage: 'This bank is temporarily unavailable. Please try another option.',
    technicalDetails: 'Financial institution service unavailable'
  }
};

export class ErrorHandler {
  public static handle(error: AppError, context: ErrorContext): void {
    const strategy = ERROR_STRATEGIES[error.code] || this.getDefaultStrategy();
    
    this.logError(error, context);
    this.trackErrorAnalytics(error, context);
    
    if (strategy.retry && context.retryCount < strategy.maxRetries) {
      this.scheduleRetry(error, context, strategy);
    } else {
      this.showUserError(strategy.userMessage);
      if (strategy.fallback) {
        strategy.fallback();
      }
    }
  }
}
```

## 8. Testing Strategy

### 8.1 Unit Testing Framework

```typescript
// Mock implementations for testing
export const mockServices = {
  sessionService: {
    create: jest.fn(),
    validate: jest.fn(),
    heartbeat: jest.fn()
  },
  fiService: {
    searchFIs: jest.fn(),
    getPopularFIs: jest.fn()
  },
  authService: {
    getLegacyConfig: jest.fn(),
    initiateOAuth: jest.fn()
  }
};

// Test utilities
export const createTestWrapper = (initialState?: Partial<AccountLinkingState>) => {
  return ({ children }: { children: React.ReactNode }) => (
    <TestProviders initialState={initialState}>
      {children}
    </TestProviders>
  );
};

// Example test suite
describe('FI Selection Flow', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should display popular FIs on load', async () => {
    const mockFIs = [{ id: '1', name: 'Test Bank', authType: 'oauth' }];
    mockServices.fiService.getPopularFIs.mockResolvedValue({ data: mockFIs });

    const { getByText } = render(<FISelectionScreen />, {
      wrapper: createTestWrapper()
    });

    await waitFor(() => {
      expect(getByText('Test Bank')).toBeInTheDocument();
    });
  });

  it('should perform search when user types', async () => {
    const { getByPlaceholderText } = render(<FISelectionScreen />, {
      wrapper: createTestWrapper()
    });

    const searchInput = getByPlaceholderText('Search for your bank...');
    fireEvent.change(searchInput, { target: { value: 'Chase' } });

    await waitFor(() => {
      expect(mockServices.fiService.searchFIs).toHaveBeenCalledWith('Chase');
    });
  });
});
```

### 8.2 Integration Testing

```typescript
// E2E test scenarios
describe('Account Linking E2E Flow', () => {
  it('should complete OAuth flow successfully', () => {
    cy.visit('/account-linking?sessionId=test-session');
    
    // Consent screen
    cy.get('[data-testid="consent-accordion"]').click();
    cy.get('[data-testid="continue-button"]').should('be.enabled').click();
    
    // FI selection
    cy.get('[data-testid="fi-search"]').type('Chase');
    cy.get('[data-testid="fi-item-chase"]').click();
    
    // OAuth authentication (mock)
    cy.window().then((win) => {
      win.postMessage({ type: 'OAUTH_SUCCESS', authCode: 'test-code' }, '*');
    });
    
    // Account selection
    cy.get('[data-testid="account-checkbox"]').first().check();
    cy.get('[data-testid="continue-button"]').click();
    
    // Success
    cy.get('[data-testid="success-message"]').should('be.visible');
  });

  it('should handle manual linking with micro-deposits', () => {
    cy.visit('/account-linking?sessionId=test-session');
    
    // Navigate to manual linking
    cy.get('[data-testid="continue-button"]').click();
    cy.get('[data-testid="manual-link-button"]').click();
    
    // Enter account details
    cy.get('[data-testid="account-number"]').type('123456789');
    cy.get('[data-testid="routing-number"]').type('021000021');
    cy.get('[data-testid="authorize-button"]').click();
    
    // Micro-deposit challenge
    cy.get('[data-testid="deposit-1"]').type('0.32');
    cy.get('[data-testid="deposit-2"]').type('0.68');
    cy.get('[data-testid="verify-button"]').click();
    
    // Account selection
    cy.get('[data-testid="account-checkbox"]').check();
    cy.get('[data-testid="continue-button"]').click();
    
    // Success
    cy.get('[data-testid="success-message"]').should('be.visible');
  });
});
```

## 9. Deployment and Monitoring

### 9.1 Deployment Architecture

```yaml
# docker-compose.yml
version: '3.8'
services:
  account-linking-ui:
    build: 
      context: .
      dockerfile: Dockerfile.ui
    ports:
      - "3000:80"
    environment:
      - API_BASE_URL=${API_BASE_URL}
      - MASTERCARD_API_KEY=${MASTERCARD_API_KEY}
    depends_on:
      - backend-api

  backend-api:
    build:
      context: .
      dockerfile: Dockerfile.api
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - REDIS_URL=${REDIS_URL}
      - MASTERCARD_CLIENT_SECRET=${MASTERCARD_CLIENT_SECRET}
    depends_on:
      - redis
      - postgres

  redis:
    image: redis:alpine
    ports:
      - "6379:6379"

  postgres:
    image: postgres:13
    environment:
      - POSTGRES_DB=account_linking
      - POSTGRES_USER=${DB_USER}
      - POSTGRES_PASSWORD=${DB_PASSWORD}
    ports:
      - "5432:5432"
```

### 9.2 Monitoring and Analytics

```typescript
interface MonitoringConfig {
  analyticsProvider: 'datadog' | 'newrelic' | 'custom';
  errorTracking: 'sentry' | 'bugsnag';
  performanceMonitoring: boolean;
  userSessionRecording: boolean;
}

class MonitoringService {
  private config: MonitoringConfig;
  
  constructor(config: MonitoringConfig) {
    this.config = config;
    this.initializeProviders();
  }

  public trackUserFlow(step: string, metadata?: Record<string, unknown>): void {
    this.trackEvent('user_flow_step', {
      step,
      timestamp: Date.now(),
      sessionId: SessionManager.getCurrentSessionId(),
      ...metadata
    });
  }

  public trackPerformance(metric: string, value: number, unit: string): void {
    this.trackMetric(`performance.${metric}`, value, {
      unit,
      timestamp: Date.now()
    });
  }

  public trackError(error: Error, context: ErrorContext): void {
    this.errorProvider.captureException(error, {
      tags: {
        component: context.component,
        flow_step: context.step,
        fi_id: context.fiId
      },
      extra: context.metadata
    });
  }
}

// Usage in components
export const useAnalytics = () => {
  const monitoring = MonitoringService.getInstance();
  
  return {
    trackStep: (step: string) => monitoring.trackUserFlow(step),
    trackError: (error: Error, context: ErrorContext) => monitoring.trackError(error, context),
    trackPerformance: (metric: string, value: number) => monitoring.trackPerformance(metric, value, 'ms')
  };
};
```

This comprehensive V4 SDD provides detailed implementation guidance with diagrams, code examples, and complete integration patterns for all three account linking flows: Legacy Banking, OAuth Authentication, and Manual Account Linking with micro-deposit verification.
