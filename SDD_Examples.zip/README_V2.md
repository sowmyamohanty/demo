# Objective: Create a detailed, step-by-step implementation plan for an account linking process. This plan will serve as a guide for developing an improved Software Design Document (SDD).

## Scope: The process involves a merchant, a user, and a Financial Institution (FI), with a focus on both standard and manual account linking flows.

## Required Steps (Chronological Order):

## Session & API Call: A merchant initiates the process by making an API call to a backend service. This call must include a unique session ID to retrieve a UI URL for account linking.

## iFrame Integration: The merchant launches the retrieved UI URL within an iframe on their website, providing a seamless user experience.

## User Consent Screen: The user is presented with a consent screen. This screen must include a clear, user-friendly design with an accordion for details and a prominent "Continue" button.

## FI Selection Screen: The user sees a screen for selecting their FI. This screen should display popular FIs as clickable tiles, with a search input field at the top. A link for "Manual Account Linking" should be prominently displayed below the popular tiles.

## Manual Account Linking Flow:

If the user selects the "Manual Account Linking" option, they are directed to a new screen.

The user must enter their account number and routing number.

Upon clicking "Authorize," the system checks for micro-deposits.

If micro-deposits are enabled, a challenge screen appears for the user to confirm the deposit amounts.

After successful confirmation (or if micro-deposits are not enabled), the system fetches all available account types for the entered account number.

The user is prompted to select their desired account type(s).

Upon continuing, a success screen is displayed.

## Search & API Flow:

If the user uses the search input, an API call is made to a backend service.

The results (bank names) are displayed in a virtualized list for performance.

The user selects a bank from this list.

## Legacy Bank Integration (Mastercard Connect):

If the selected bank is a legacy institution, an API call is made to Mastercard Connect Components to render the FI's login page within the UI.

The system must listen for a successful callback from Mastercard Connect.

Upon a successful callback, the user is shown their available account types.

The user selects their account type(s).

A success message is displayed, and a success event is passed back to the merchant.

The merchant's application then closes the account linking window.

## OAuth Bank Integration (Mastercard Connect):

If the selected bank uses OAuth, an API call is made to Mastercard Connect Components to retrieve the OAuth details.

A pop-up window is opened to redirect the user to the FI's login page for OAuth authentication.

After a successful login, the user can select their account type(s).

The system listens for the Mastercard Connect success event.

A success message is displayed, and a callback is passed to the merchant to confirm successful linking.

The merchant's application then closes the account linking window.