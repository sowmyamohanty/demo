# Bank Account Linking Experience - UI Component Design V3.0

**Document Version:** 3.0  
**Date:** August 27, 2025  
**Focus:** React UI Component Architecture with Salt Design System  
**Status:** Draft

## 1. UI Context and State Management

### 1.1 Global Context Definition
```typescript
// src/contexts/AccountLinkingContext.tsx
interface AccountLinkingState {
  currentStep: 'consent' | 'fiSelection' | 'authentication' | 'accountSelection' | 'success';
  selectedFI: FinancialInstitution | null;
  consentGiven: boolean;
  selectedAccounts: string[];
  isLoading: boolean;
  error: Error | null;
}

interface AccountLinkingContextType {
  state: AccountLinkingState;
  dispatch: React.Dispatch<AccountLinkingAction>;
}

const AccountLinkingContext = createContext<AccountLinkingContextType | undefined>(undefined);

export const AccountLinkingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(accountLinkingReducer, initialState);

  return (
    <AccountLinkingContext.Provider value={{ state, dispatch }}>
      {children}
    </AccountLinkingContext.Provider>
  );
};
```

### 1.2 Custom Hooks
```typescript
// src/hooks/useAccountLinking.ts
export const useAccountLinking = () => {
  const context = useContext(AccountLinkingContext);
  if (!context) {
    throw new Error('useAccountLinking must be used within AccountLinkingProvider');
  }
  return context;
};

// src/hooks/useFISearch.ts
export const useFISearch = () => {
  const [searchResults, setSearchResults] = useState<FinancialInstitution[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const searchFIs = useCallback(async (query: string) => {
    setIsSearching(true);
    try {
      const results = await FIService.search(query);
      setSearchResults(results);
    } catch (error) {
      // Handle error
    } finally {
      setIsSearching(false);
    }
  }, []);

  return { searchResults, isSearching, searchFIs };
};
```

## 2. Screen Components

### 2.1 Main Container
```typescript
// src/components/AccountLinking/AccountLinkingContainer.tsx
import { Layout, LayoutItem } from '@salt-ds/core';

export const AccountLinkingContainer: React.FC = () => {
  const { state } = useAccountLinking();

  const renderStep = () => {
    switch (state.currentStep) {
      case 'consent':
        return <ConsentScreen />;
      case 'fiSelection':
        return <FISelectionScreen />;
      case 'authentication':
        return <AuthenticationScreen />;
      case 'accountSelection':
        return <AccountSelectionScreen />;
      case 'success':
        return <SuccessScreen />;
      default:
        return null;
    }
  };

  return (
    <Layout>
      <LayoutItem>
        <StepIndicator currentStep={state.currentStep} />
        <Card>
          {renderStep()}
        </Card>
      </LayoutItem>
    </Layout>
  );
};
```

### 2.2 Consent Screen
```typescript
// src/components/AccountLinking/ConsentScreen.tsx
import { Button, Text, Accordion, AccordionPanel } from '@salt-ds/core';

export const ConsentScreen: React.FC = () => {
  const { dispatch } = useAccountLinking();
  const [isExpanded, setIsExpanded] = useState(false);

  const handleConsent = () => {
    dispatch({ type: 'SET_CONSENT', payload: true });
    dispatch({ type: 'SET_STEP', payload: 'fiSelection' });
  };

  return (
    <div className="consent-container">
      <Text variant="h2">Link Your Bank Account</Text>
      
      <Accordion
        expanded={isExpanded}
        onChange={(_, expanded) => setIsExpanded(expanded)}
      >
        <AccordionPanel 
          title="Terms and Conditions"
          aria-label="Bank account linking terms"
        >
          <Text variant="body">
            By proceeding, you authorize us to:
            1. Access your bank account information
            2. Verify your account ownership
            3. Maintain secure access to your account
          </Text>
        </AccordionPanel>
      </Accordion>

      <Button
        variant="cta"
        onClick={handleConsent}
        disabled={!isExpanded}
      >
        I Agree & Continue
      </Button>
    </div>
  );
};
```

### 2.3 FI Selection Screen
```typescript
// src/components/AccountLinking/FISelection/FISelectionScreen.tsx
import { Input, List, Text, Spinner } from '@salt-ds/core';
import { Search } from '@salt-ds/icons';

export const FISelectionScreen: React.FC = () => {
  const { dispatch } = useAccountLinking();
  const { searchResults, isSearching, searchFIs } = useFISearch();
  const debouncedSearch = useDebounce(searchFIs, 300);

  const handleFISelect = (fi: FinancialInstitution) => {
    dispatch({ type: 'SET_SELECTED_FI', payload: fi });
    dispatch({ type: 'SET_STEP', payload: 'authentication' });
  };

  return (
    <div className="fi-selection-container">
      <Text variant="h2">Select Your Bank</Text>
      
      <Input
        icon={<Search />}
        placeholder="Search for your bank..."
        onChange={(e) => debouncedSearch(e.target.value)}
      />

      {isSearching ? (
        <Spinner size="medium" />
      ) : (
        <VirtualizedFIList
          items={searchResults}
          onSelect={handleFISelect}
        />
      )}
    </div>
  );
};

// src/components/AccountLinking/FISelection/VirtualizedFIList.tsx
import { useVirtual } from 'react-virtual';
import { List, ListItem } from '@salt-ds/core';

export const VirtualizedFIList: React.FC<{
  items: FinancialInstitution[];
  onSelect: (fi: FinancialInstitution) => void;
}> = ({ items, onSelect }) => {
  const parentRef = useRef<HTMLDivElement>(null);
  
  const rowVirtualizer = useVirtual({
    size: items.length,
    parentRef,
    estimateSize: useCallback(() => 60, []),
    overscan: 5
  });

  return (
    <List ref={parentRef} style={{ height: '400px', overflow: 'auto' }}>
      <div
        style={{
          height: `${rowVirtualizer.totalSize}px`,
          position: 'relative'
        }}
      >
        {rowVirtualizer.virtualItems.map((virtualRow) => (
          <ListItem
            key={virtualRow.index}
            style={{
              position: 'absolute',
              top: 0,
              transform: `translateY(${virtualRow.start}px)`,
              width: '100%'
            }}
            onClick={() => onSelect(items[virtualRow.index])}
          >
            <FIListItemContent fi={items[virtualRow.index]} />
          </ListItem>
        ))}
      </div>
    </List>
  );
};
```

### 2.4 Authentication Screen
```typescript
// src/components/AccountLinking/Authentication/AuthenticationScreen.tsx
import { Card, Text, Spinner } from '@salt-ds/core';

export const AuthenticationScreen: React.FC = () => {
  const { state } = useAccountLinking();
  const { selectedFI } = state;

  if (!selectedFI) {
    return null;
  }

  return (
    <div className="authentication-container">
      {selectedFI.authType === 'oauth' ? (
        <OAuthAuthenticationView fi={selectedFI} />
      ) : (
        <LegacyAuthenticationView fi={selectedFI} />
      )}
    </div>
  );
};

// OAuth View Component
const OAuthAuthenticationView: React.FC<{ fi: FinancialInstitution }> = ({ fi }) => {
  useEffect(() => {
    // Initiate OAuth flow
    const initiateOAuth = async () => {
      const authUrl = await AuthService.getOAuthUrl(fi.id);
      window.location.href = authUrl;
    };
    
    initiateOAuth();
  }, [fi]);

  return (
    <Card>
      <Text variant="h3">Redirecting to {fi.name}</Text>
      <Spinner size="large" />
      <Text variant="body">
        You will be redirected to your bank's secure login page.
      </Text>
    </Card>
  );
};

// Legacy Authentication View
const LegacyAuthenticationView: React.FC<{ fi: FinancialInstitution }> = ({ fi }) => {
  return (
    <Card>
      <Text variant="h3">Log in to {fi.name}</Text>
      <div id="mc-connect-container" />
    </Card>
  );
};
```

### 2.5 Account Selection Screen
```typescript
// src/components/AccountLinking/AccountSelection/AccountSelectionScreen.tsx
import { 
  List, 
  ListItem, 
  Checkbox, 
  Button, 
  Text 
} from '@salt-ds/core';

export const AccountSelectionScreen: React.FC = () => {
  const { state, dispatch } = useAccountLinking();
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [selectedAccounts, setSelectedAccounts] = useState<string[]>([]);

  useEffect(() => {
    const fetchAccounts = async () => {
      const bankAccounts = await AccountService.getAccounts(state.selectedFI!.id);
      setAccounts(bankAccounts);
    };
    
    fetchAccounts();
  }, [state.selectedFI]);

  const handleAccountToggle = (accountId: string) => {
    setSelectedAccounts(prev => 
      prev.includes(accountId)
        ? prev.filter(id => id !== accountId)
        : [...prev, accountId]
    );
  };

  const handleContinue = () => {
    dispatch({ type: 'SET_SELECTED_ACCOUNTS', payload: selectedAccounts });
    dispatch({ type: 'SET_STEP', payload: 'success' });
  };

  return (
    <div className="account-selection-container">
      <Text variant="h2">Select Accounts to Link</Text>
      
      <List>
        {accounts.map(account => (
          <ListItem key={account.id}>
            <Checkbox
              checked={selectedAccounts.includes(account.id)}
              onChange={() => handleAccountToggle(account.id)}
              label={
                <AccountDetails 
                  type={account.type}
                  number={account.maskedNumber}
                  balance={account.balance}
                />
              }
            />
          </ListItem>
        ))}
      </List>

      <Button
        variant="cta"
        disabled={selectedAccounts.length === 0}
        onClick={handleContinue}
      >
        Continue
      </Button>
    </div>
  );
};
```

### 2.6 Success Screen
```typescript
// src/components/AccountLinking/SuccessScreen.tsx
import { Text, Button, Icon } from '@salt-ds/core';
import { CheckCircle } from '@salt-ds/icons';

export const SuccessScreen: React.FC = () => {
  const { state } = useAccountLinking();
  
  useEffect(() => {
    const timer = setTimeout(() => {
      window.parent.postMessage({
        type: 'ACCOUNT_LINKING_COMPLETE',
        payload: {
          fi: state.selectedFI,
          accounts: state.selectedAccounts
        }
      }, '*');
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="success-container">
      <Icon>
        <CheckCircle />
      </Icon>
      
      <Text variant="h2">
        Account Successfully Linked!
      </Text>
      
      <Text variant="body">
        You will be redirected back to the merchant's page...
      </Text>
    </div>
  );
};
```

## 3. Shared Components

### 3.1 Step Indicator
```typescript
// src/components/AccountLinking/shared/StepIndicator.tsx
import { ProgressTracker, ProgressStep } from '@salt-ds/core';

const steps = [
  { id: 'consent', label: 'Consent' },
  { id: 'fiSelection', label: 'Select Bank' },
  { id: 'authentication', label: 'Login' },
  { id: 'accountSelection', label: 'Select Accounts' },
  { id: 'success', label: 'Complete' }
];

export const StepIndicator: React.FC<{
  currentStep: string;
}> = ({ currentStep }) => {
  return (
    <ProgressTracker>
      {steps.map((step) => (
        <ProgressStep
          key={step.id}
          label={step.label}
          status={
            step.id === currentStep
              ? 'current'
              : steps.findIndex(s => s.id === currentStep) >
                steps.findIndex(s => s.id === step.id)
              ? 'completed'
              : 'not-started'
          }
        />
      ))}
    </ProgressTracker>
  );
};
```

### 3.2 Error Boundary
```typescript
// src/components/AccountLinking/shared/ErrorBoundary.tsx
import { Card, Text, Button } from '@salt-ds/core';

export class AccountLinkingErrorBoundary extends React.Component {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <Card variant="error">
          <Text variant="h3">Something went wrong</Text>
          <Text variant="body">
            We encountered an error while processing your request.
          </Text>
          <Button
            variant="secondary"
            onClick={() => window.location.reload()}
          >
            Try Again
          </Button>
        </Card>
      );
    }

    return this.props.children;
  }
}
```

## 4. Styling

### 4.1 Theme Configuration
```typescript
// src/theme/index.ts
import { createTheme } from '@salt-ds/core';

export const theme = createTheme({
  density: 'medium',
  mode: 'light'
});

// Apply theme in App.tsx
import { ThemeProvider } from '@salt-ds/core';

export const App: React.FC = () => {
  return (
    <ThemeProvider theme={theme}>
      <AccountLinkingProvider>
        <AccountLinkingContainer />
      </AccountLinkingProvider>
    </ThemeProvider>
  );
};
```

### 4.2 Responsive Design
```typescript
// src/styles/responsive.ts
import { css } from '@emotion/react';

export const responsiveStyles = {
  container: css`
    width: 100%;
    max-width: 600px;
    margin: 0 auto;
    padding: var(--salt-spacing-300);
    
    @media (max-width: 600px) {
      padding: var(--salt-spacing-200);
    }
  `,
  
  fiList: css`
    height: 400px;
    
    @media (max-width: 600px) {
      height: 300px;
    }
  `
};
```

## 5. Accessibility

### 5.1 Accessibility Enhancements
```typescript
// src/components/AccountLinking/shared/AccessibilityProvider.tsx
export const AccessibilityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  useEffect(() => {
    // Ensure proper focus management
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        // Handle escape key for modals/popups
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div 
      role="main"
      aria-live="polite"
    >
      {children}
    </div>
  );
};
```

This V3 version provides a detailed look at the UI component architecture using React, TypeScript, and the Salt Design System. Each component is designed with:

1. Proper TypeScript typing
2. Salt Design System components integration
3. React Context for state management
4. Responsive design considerations
5. Accessibility features
6. Error boundaries and error handling
7. Clean component composition

Would you like me to explain any specific component or aspect in more detail?
