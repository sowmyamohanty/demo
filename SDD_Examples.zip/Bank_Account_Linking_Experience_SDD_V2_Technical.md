# Bank Account Linking Experience - Technical Implementation Specification V2.0

**Document Version:** 2.0  
**Date:** August 27, 2025  
**Focus:** Technical Implementation Details  
**Status:** Draft

## 1. Technical Stack

### 1.1 Frontend Core
- **Framework:** React 18.x with TypeScript 5.x
- **Design System:** JPMorgan Chase Salt Design System
- **State Management:** React Context API + Custom Hooks
- **Build System:** Webpack 5.x
- **Package Manager:** npm/yarn

### 1.2 Key Dependencies
```json
{
  "dependencies": {
    "@salt-ds/core": "^1.x",
    "@salt-ds/theme": "^1.x",
    "react": "^18.x",
    "react-dom": "^18.x",
    "react-virtual": "^3.x",
    "axios": "^1.x",
    "zod": "^3.x",
    "date-fns": "^2.x"
  },
  "devDependencies": {
    "typescript": "^5.x",
    "jest": "^29.x",
    "@testing-library/react": "^14.x",
    "cypress": "^13.x"
  }
}
```

## 2. Core Technical Components

### 2.1 Session Management
```typescript
interface Session {
  id: string;
  token: string;
  merchantId: string;
  expiresAt: number;
  status: 'active' | 'expired' | 'completed';
}

class SessionManager {
  private static instance: SessionManager;
  private session: Session | null;
  
  private constructor() {
    this.session = null;
    window.addEventListener('message', this.handlePostMessage);
  }

  public static getInstance(): SessionManager {
    if (!SessionManager.instance) {
      SessionManager.instance = new SessionManager();
    }
    return SessionManager.instance;
  }

  public async initialize(merchantId: string): Promise<void> {
    const response = await axios.post('/api/sessions', { merchantId });
    this.session = response.data;
    this.startHeartbeat();
  }

  private startHeartbeat(): void {
    setInterval(() => {
      if (this.session && this.session.status === 'active') {
        this.ping();
      }
    }, 30000);
  }
}
```

### 2.2 Security Implementation

#### 2.2.1 Content Security Policy
```typescript
// CSP Configuration
const cspConfig = {
  'default-src': ["'self'"],
  'script-src': ["'self'", "'unsafe-inline'"],
  'style-src': ["'self'", "'unsafe-inline'"],
  'frame-ancestors': ["https://*.merchant-domain.com"],
  'connect-src': [
    "'self'",
    "https://api.mastercard.com",
    "https://*.fi-domain.com"
  ]
};
```

#### 2.2.2 PostMessage Communication
```typescript
interface PostMessagePayload {
  type: 'SESSION_UPDATE' | 'ACCOUNT_LINKED' | 'ERROR' | 'CLOSE';
  data: any;
  timestamp: number;
  signature: string;
}

class PostMessageHandler {
  private readonly allowedOrigins: string[];
  
  constructor(allowedOrigins: string[]) {
    this.allowedOrigins = allowedOrigins;
    window.addEventListener('message', this.handleMessage);
  }

  private handleMessage = (event: MessageEvent): void => {
    if (!this.allowedOrigins.includes(event.origin)) {
      console.error('Unauthorized origin:', event.origin);
      return;
    }

    if (!this.verifySignature(event.data)) {
      console.error('Invalid message signature');
      return;
    }

    this.processMessage(event.data);
  }

  private verifySignature(payload: PostMessagePayload): boolean {
    // Implement HMAC verification
    return true;
  }
}
```

## 3. API Integration

### 3.1 API Service Structure
```typescript
abstract class BaseApiService {
  protected readonly client: AxiosInstance;
  
  constructor() {
    this.client = axios.create({
      baseURL: process.env.API_BASE_URL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    this.setupInterceptors();
  }

  private setupInterceptors(): void {
    this.client.interceptors.request.use(
      this.addAuthToken,
      this.handleRequestError
    );
    
    this.client.interceptors.response.use(
      this.handleResponse,
      this.handleResponseError
    );
  }
}

class FIService extends BaseApiService {
  public async searchFIs(query: string, page: number): Promise<FISearchResponse> {
    return this.client.get('/fi/search', {
      params: {
        q: query,
        page,
        limit: 20
      }
    });
  }
}
```

### 3.2 API Endpoints
```typescript
const API_ENDPOINTS = {
  session: {
    create: '/api/v1/sessions',
    verify: '/api/v1/sessions/:sessionId/verify',
    heartbeat: '/api/v1/sessions/:sessionId/heartbeat'
  },
  fi: {
    search: '/api/v1/fi/search',
    popular: '/api/v1/fi/popular',
    details: '/api/v1/fi/:fiId'
  },
  auth: {
    legacy: '/api/v1/auth/legacy/:fiId',
    oauth: {
      initiate: '/api/v1/auth/oauth/:fiId/initiate',
      callback: '/api/v1/auth/oauth/callback'
    }
  },
  accounts: {
    list: '/api/v1/accounts/:fiId',
    link: '/api/v1/accounts/link'
  }
};
```

## 4. Performance Optimizations

### 4.1 Virtualized FI List Implementation
```typescript
interface FIListProps {
  items: FinancialInstitution[];
  onSelect: (fi: FinancialInstitution) => void;
}

const FIList: React.FC<FIListProps> = ({ items, onSelect }) => {
  const parentRef = useRef<HTMLDivElement>(null);
  
  const rowVirtualizer = useVirtual({
    size: items.length,
    parentRef,
    estimateSize: useCallback(() => 60, []),
    overscan: 5
  });

  return (
    <div ref={parentRef} style={{ height: '400px', overflow: 'auto' }}>
      <div
        style={{
          height: `${rowVirtualizer.totalSize}px`,
          width: '100%',
          position: 'relative'
        }}
      >
        {rowVirtualizer.virtualItems.map((virtualRow) => (
          <div
            key={virtualRow.index}
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: `${virtualRow.size}px`,
              transform: `translateY(${virtualRow.start}px)`
            }}
          >
            <FIListItem
              fi={items[virtualRow.index]}
              onSelect={onSelect}
            />
          </div>
        ))}
      </div>
    </div>
  );
};
```

## 5. Error Handling

### 5.1 Error Types
```typescript
enum ErrorType {
  NETWORK = 'NETWORK',
  SESSION = 'SESSION',
  AUTHENTICATION = 'AUTHENTICATION',
  VALIDATION = 'VALIDATION',
  SYSTEM = 'SYSTEM'
}

interface AppError extends Error {
  type: ErrorType;
  code: string;
  context?: Record<string, unknown>;
}

class ErrorHandler {
  private static readonly ERROR_CODES = {
    SESSION_EXPIRED: 'E001',
    INVALID_FI: 'E002',
    AUTH_FAILED: 'E003',
    NETWORK_ERROR: 'E004'
  };

  public static handle(error: AppError): void {
    this.logError(error);
    this.notifyUser(error);
    this.reportToAnalytics(error);

    if (this.isRecoverable(error)) {
      this.attemptRecovery(error);
    } else {
      this.terminateFlow(error);
    }
  }
}
```

## 6. Testing Strategy

### 6.1 Unit Test Structure
```typescript
describe('SessionManager', () => {
  let sessionManager: SessionManager;
  
  beforeEach(() => {
    sessionManager = SessionManager.getInstance();
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.clearAllTimers();
  });

  it('should initialize session correctly', async () => {
    const mockSession = {
      id: 'test-session',
      token: 'test-token',
      status: 'active'
    };
    
    axios.post.mockResolvedValueOnce({ data: mockSession });
    
    await sessionManager.initialize('merchant-1');
    expect(sessionManager.getSession()).toEqual(mockSession);
  });
});
```

### 6.2 Integration Test Example
```typescript
describe('FI Selection Flow', () => {
  it('should handle FI selection and authentication flow', () => {
    cy.visit('/');
    cy.get('[data-testid="fi-search"]').type('Chase');
    cy.get('[data-testid="fi-list"]').should('be.visible');
    cy.get('[data-testid="fi-item-chase"]').click();
    cy.url().should('include', '/auth');
  });
});
```

## 7. Monitoring and Analytics

### 7.1 Analytics Implementation
```typescript
interface AnalyticsEvent {
  category: 'Session' | 'FI' | 'Authentication' | 'Account' | 'Error';
  action: string;
  label?: string;
  value?: number;
  metadata?: Record<string, unknown>;
}

class Analytics {
  private static readonly EVENTS = {
    SESSION_START: 'session_start',
    FI_SEARCH: 'fi_search',
    FI_SELECT: 'fi_select',
    AUTH_START: 'auth_start',
    AUTH_COMPLETE: 'auth_complete',
    ACCOUNT_LINKED: 'account_linked'
  };

  public static track(event: AnalyticsEvent): void {
    // Implementation for tracking events
    this.validateEvent(event);
    this.enrichEvent(event);
    this.send(event);
  }
}
```

## 8. Security Measures

### 8.1 Token Management
```typescript
class TokenManager {
  private static readonly TOKEN_KEY = 'session_token';
  private static readonly TOKEN_EXPIRY_KEY = 'token_expiry';

  public static setToken(token: string, expiresIn: number): void {
    const expiryTime = Date.now() + expiresIn * 1000;
    sessionStorage.setItem(this.TOKEN_KEY, token);
    sessionStorage.setItem(this.TOKEN_EXPIRY_KEY, expiryTime.toString());
  }

  public static getToken(): string | null {
    const token = sessionStorage.getItem(this.TOKEN_KEY);
    const expiry = sessionStorage.getItem(this.TOKEN_EXPIRY_KEY);

    if (!token || !expiry) {
      return null;
    }

    if (Date.now() > parseInt(expiry, 10)) {
      this.clearToken();
      return null;
    }

    return token;
  }
}
```

### 8.2 XSS Prevention
```typescript
const sanitizeInput = (input: string): string => {
  return input.replace(/[<>]/g, '');
};

const validateOrigin = (origin: string): boolean => {
  const allowedOrigins = [
    'https://merchant1.com',
    'https://merchant2.com'
  ];
  return allowedOrigins.includes(origin);
};
```

## 9. Build and Deployment

### 9.1 Webpack Configuration
```javascript
module.exports = {
  entry: './src/index.tsx',
  output: {
    filename: '[name].[contenthash].js',
    path: path.resolve(__dirname, 'dist')
  },
  optimization: {
    splitChunks: {
      chunks: 'all',
      cacheGroups: {
        vendor: {
          test: /[\\/]node_modules[\\/]/,
          name: 'vendors',
          chunks: 'all'
        }
      }
    }
  },
  module: {
    rules: [
      {
        test: /\.(ts|tsx)$/,
        use: 'ts-loader',
        exclude: /node_modules/
      }
    ]
  }
};
```

### 9.2 Environment Configuration
```typescript
interface EnvironmentConfig {
  apiBaseUrl: string;
  environment: 'development' | 'staging' | 'production';
  logLevel: 'debug' | 'info' | 'warn' | 'error';
  features: {
    oauth: boolean;
    analytics: boolean;
  };
}

const config: Record<string, EnvironmentConfig> = {
  development: {
    apiBaseUrl: 'https://dev-api.example.com',
    environment: 'development',
    logLevel: 'debug',
    features: {
      oauth: true,
      analytics: false
    }
  },
  production: {
    apiBaseUrl: 'https://api.example.com',
    environment: 'production',
    logLevel: 'error',
    features: {
      oauth: true,
      analytics: true
    }
  }
};
```

This technical specification provides a detailed implementation guide for developers, focusing on the actual code structure, patterns, and technical considerations for the Bank Account Linking Experience.
