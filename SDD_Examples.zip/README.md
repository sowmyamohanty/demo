# Role: You are a senior UI Solution Architect, responsible for designing scalable, maintainable, and user-centric interfaces that align with business objectives.
## Project Name: Bank Account Linking Experience
## Project Details:
Design and implement a responsive UI for merchants to launch a secure Bank Account Linking Experience. The UI must support embedding within an iframe or popup, and adapt seamlessly across mobile webviews, native browsers, desktop, and tablet devices.In other words Design a responsive, embeddable UI that allows merchants to launch a secure bank account linking flow for their users.
## Key Requirements:
- **Embeddable UI**: Merchant receives a unique URL to launch the experience in an iframe or popup, maintaining session integrity.
- **Responsive Design**: UI must be fully responsive for mobile, tablet, and desktop environments.
- **Security**: All flows must ensure secure handling of user data and session management.
## App Flow & UI Screens
1. **Launch & Session Management**: Merchant provides a "Link Bank Account" button on their checkout page. Clicking this opens the Bank Account Linking UI (iframe or popup) using the unique session URL.The UI must handle session persistence and communication securely.
2. **User Consent**: The first screen presents a consent form and a "Continue" button. On acceptance, the user proceeds to FI (Financial Institution) selection. The purpose is to Obtain explicit user consent to proceed with the linking process.
Components:
- A clear, concise consent message in an accordian.
- A "Continue" button to advance to the next step.
3. **FI Selection**:Purpose: Allow the user to select their bank.
    - Display a list of popular FIs and a search input at the top.
    - Support search with API-driven pagination; results rendered using a virtualized list for performance.
    - Option to manually connect an FI via a dedicated link.
    - Two FI login types supported:
        - **Legacy**: Traditional credential-based login.
        - **OAuth**: Redirect-based authentication using OAuth.
**Components**:

* Search Input: A search bar at the top to find FIs.

* Popular FIs: A section displaying a list of popular FIs.

* Manual Connect: A link to manually connect an FI.

** Functionality:

*Searching for an FI triggers an API call with pagination.
The results are rendered using a virtualized list to efficiently display a large number of FIs without performance degradation.
Users can select an FI from the popular list or the search results.        
4. **FI Login**:
    - **Purpose**: Facilitate the user's login to their bank.
    - **Method A (Legacy FI)**: If a legacy bank is selected, the UI will use Mastercard Connect Components API to render the bank's legacy login page within the UI.

    -**Method B (OAuth FI)**: If an OAuth-enabled bank is selected, the UI will call a Mastercard API to get the necessary OAuth details and then redirect the user to the FI's secure login URL. 
   
5. **Account Type Selection**: After successful FI authentication, present options for account type (e.g., savings, checking).
   -**Purpose**:Allow the user to choose which specific bank accounts (e.g., checking, savings) to link.
   -**Componnets**:List of availavilble account types and check box to seelct accounts.
6. **Success & Redirect**: Confirm successful linking and return the user to the merchant's application.Show a success message, then redirect the user back to the merchant with linked bank account details.

## Technical Considerations
- **API Integration**: All FI data and authentication flows are powered by backend APIs (with pagination and search for FIs).
- **Virtualized Lists**: Use virtualized rendering for large FI lists to optimize DOM performance.
- **Session Management**: Ensure session is maintained securely throughout the flow.
- **Accessibility**: UI must meet accessibility standards (WCAG 2.1 AA or higher).
- **Error Handling**: Provide clear error messages and recovery options at each step.Define how the UI will gracefully handle API failures, network issues, and user-initiated cancellations.
-**Responsiveness**: The UI must be fully responsive and support mobile web views, native web browsers, desktops, and tablets.

-**API Calls**: Specify the API endpoints for FI search, OAuth details, and any other necessary data retrieval.

-**State Management**: Outline the state management strategy to handle the user's progress through the flow.

-**UI Framework**: React, typescript and jpmorganchase salt design system for efficient development.

-**Security**: Detail the implementation of a secure communication protocol between the UI and the merchant's page and other security handling like CSP etc.communication must be through postMessage()

## Industry Best Practices
- Modular, component-based UI architecture 
- Secure API communication 
- Comprehensive logging and analytics for user actions and errors.
- Automated and manual testing for all UI flows. 