# Bank Account Linking Experience - Solution Design Document

**Document Version:** 1.0  
**Date:** August 28, 2025  
**Author:** GitHub Copilot  
**Status:** Draft  

## Document Control

| Version | Date | Author | Description of Changes |
|---------|------|--------|------------------------|
| 1.0 | August 28, 2025 | GitHub Copilot | Initial document creation |

## Table of Contents
1. [Executive Summary](#executive-summary)
2. [Introduction](#introduction)
   - [Purpose](#purpose)
   - [Scope](#scope)
   - [Definitions, Acronyms, and Abbreviations](#definitions-acronyms-and-abbreviations)
   - [References](#references)
3. [Solution Overview](#solution-overview)
   - [Context and Background](#context-and-background)
   - [Business Requirements](#business-requirements)
   - [Design Philosophy](#design-philosophy)
   - [Solution Architecture](#solution-architecture)
4. [Detailed Design](#detailed-design)
   - [Component Architecture](#component-architecture)
   - [User Interface Design](#user-interface-design)
   - [Responsive Design Strategy](#responsive-design-strategy)
   - [Cross-Platform Compatibility](#cross-platform-compatibility)
   - [Accessibility Considerations](#accessibility-considerations)
5. [Technical Implementation](#technical-implementation)
   - [Technologies and Frameworks](#technologies-and-frameworks)
   - [Performance Optimization](#performance-optimization)
   - [State Management](#state-management)
   - [CSS Strategy](#css-strategy)
   - [Error Handling](#error-handling)
6. [Security Considerations](#security-considerations)
   - [Data Protection](#data-protection)
   - [Authentication and Authorization](#authentication-and-authorization)
7. [Testing Strategy](#testing-strategy)
8. [Deployment and Infrastructure](#deployment-and-infrastructure)
9. [Monitoring and Analytics](#monitoring-and-analytics)
10. [Appendices](#appendices)

## Executive Summary

The Bank Account Linking Experience provides a secure, user-friendly interface for connecting financial institution accounts. This Solution Design Document outlines the technical architecture, design patterns, and implementation details for a React-based application that prioritizes security, performance, accessibility, and cross-platform compatibility.

The solution adopts a mobile-first, progressive enhancement approach with sophisticated component design that addresses the unique challenges of financial services interfaces, including trust building, efficient financial institution selection, OAuth handling, account selection, and success confirmation.

Key technical features include optimized performance through React-Virtualized, a comprehensive responsive design strategy, cross-platform compatibility optimizations, WCAG 2.1 AA compliance, and a flexible theming system for white-label customization.

## Introduction

### Purpose

This Solution Design Document (SDD) provides a comprehensive technical specification for the Bank Account Linking Experience application. It serves as a reference for developers, designers, and stakeholders to understand the architectural decisions, component structure, and implementation details.

### Scope

This document covers the following aspects of the Bank Account Linking Experience:
- Component design and architecture
- UI/UX implementation details
- Performance optimization strategies
- Cross-platform compatibility considerations
- Accessibility implementation
- Technical implementation patterns

The document focuses on the front-end implementation and does not cover back-end services except where they interface with the front-end components.

### Definitions, Acronyms, and Abbreviations

- **FI**: Financial Institution
- **OAuth**: Open Authorization - a standard protocol for secure authentication
- **WCAG**: Web Content Accessibility Guidelines
- **CLS**: Cumulative Layout Shift
- **FOIT**: Flash of Invisible Text
- **SDD**: Solution Design Document

### References

- APP_DOCUMENTATION_V2.md - Primary reference for this SDD

## Solution Overview

### Context and Background

The Bank Account Linking Experience is designed to facilitate secure connection of users' financial accounts through a streamlined, trustworthy interface. It serves as a critical component in financial technology applications that require access to banking data for services like personal financial management, payment processing, or financial insights.

### Business Requirements

Based on the reference documentation, the application must:
1. Provide a secure and trustworthy experience for users connecting their financial accounts
2. Support a wide range of financial institutions
3. Work seamlessly across multiple platforms (mobile, tablet, desktop)
4. Support both OAuth and traditional login methods
5. Maintain high performance even with large lists of financial institutions
6. Be accessible to users with disabilities
7. Support white-labeling through theming capabilities

### Design Philosophy

As detailed in the reference documentation, the application's design philosophy centers on three core principles:

#### 1. Mobile-First Approach
- Base styles target mobile devices (320px+)
- Progressive enhancement for larger screens
- Touch-friendly interaction targets (min 44px)
- Optimized for thumb navigation patterns

#### 2. Security-Conscious Design
- Clear visual hierarchy emphasizing security elements
- Prominent security indicators and messaging
- Transparent data usage communication
- Error handling that doesn't expose sensitive information

#### 3. Financial Service Aesthetics
- Professional, trustworthy visual language
- Conservative color palettes with accessibility compliance
- Clear typography hierarchy for scannable content
- Consistent spacing and layout patterns

### Solution Architecture

The Bank Account Linking Experience is implemented as a React application with the following high-level architecture:

1. **Core Components**:
   - FISelectorScreen - For searching and selecting financial institutions
   - ConsentScreen - For obtaining user consent for data sharing
   - OAuthScreen - For handling OAuth authentication flows
   - LegacyLoginScreen - For handling traditional username/password authentication
   - AccountSelectionScreen - For selecting specific accounts to link
   - SuccessScreen - For confirming successful account linking

2. **Support Systems**:
   - BrandingThemeProvider - For customizing the visual appearance
   - Error handling and recovery mechanisms
   - Performance optimization systems

3. **Integration Points**:
   - Multi-channel communication for successful linking callbacks
   - Iframe integration capabilities
   - Analytics and monitoring hooks

## Detailed Design

### Component Architecture

The application follows a component-based architecture with clear separation of concerns:

#### 1. ConsentScreen - Trust Building Foundation

**Design Rationale**: Serves as the critical trust-building foundation of the entire flow, emphasizing transparency, comprehension, and informed consent.

**Key Design Decisions**:
- Accordion pattern to reduce cognitive load and implement progressive disclosure
- Clear visual hierarchy with primary/secondary text elements
- Responsive behavior that optimizes for mobile displays

#### 2. FISelectorScreen - Search & Discovery Excellence

**Implementation Highlights**:
- React-Virtualized for efficient rendering of long FI lists
- Progressive search design with immediate feedback
- Cross-platform optimizations for WebView environments

#### 3. OAuthScreen - Security & Trust Communication

**Design Features**:
- Multi-state error handling with user-friendly messaging
- Responsive loading states for different device sizes
- Clear security communication

#### 4. AccountSelectionScreen - Financial Data Presentation

**Information Architecture**:
- Hierarchical presentation of account information (name, type, balance)
- Enhanced radio button pattern for selection clarity
- Disabled state handling for unavailable accounts

#### 5. SuccessScreen - Completion & Confirmation

**Callback Architecture**:
- Multi-channel communication (console, callback props, PostMessage, webhooks)
- Visual completion hierarchy with animations

### User Interface Design

The UI design implements several key patterns to enhance usability:

#### Progressive Disclosure
Information is layered with essential details visible immediately and supporting details available on interaction, as implemented in the ConsentScreen's accordion pattern.

#### Contextual Help
Just-in-time information is provided when users need it most, such as step-by-step guidance during the OAuth process.

#### Error Recovery Patterns
Graceful degradation with user-friendly error messages and recovery actions based on error type.

#### Loading State Patterns
Skeleton loading animations that match content structure to indicate progress without disrupting the layout.

### Responsive Design Strategy

The application implements a comprehensive responsive design approach:

#### Breakpoint System
```css
/* Mobile First - Base styles */
@media (min-width: 320px) { /* All styles start here */ }

/* Tablet Portrait */
@media (min-width: 768px) { /* Layout adjustments */ }

/* Tablet Landscape / Small Desktop */
@media (min-width: 1024px) { /* Multi-column layouts */ }

/* Desktop */
@media (min-width: 1440px) { /* Optimal desktop experience */ }
```

#### Fluid Typography & Spacing
CSS `clamp()` is used for fluid, viewport-responsive sizing:

```css
padding: clamp(16px, 4vw, 24px);  /* 16px on mobile, 24px on desktop */
font-size: clamp(20px, 4vw, 28px); /* Fluid font sizing */
gap: clamp(12px, 2vh, 16px);       /* Vertical rhythm adaptation */
```

#### Screen Size Adaptation Matrix

| Device Category | Viewport Range | Layout Strategy | Key Adaptations |
|----------------|---------------|-----------------|-----------------|
| **Mobile Portrait** | 320px - 479px | Single column, stacked | Touch targets 44px+, full-width cards |
| **Mobile Landscape** | 480px - 767px | Single column, condensed | Reduced vertical spacing, compact headers |
| **Tablet Portrait** | 768px - 1023px | Single column, spacious | Larger typography, more whitespace |
| **Tablet Landscape** | 1024px - 1439px | Multi-column option | Side-by-side forms, dual-pane layouts |
| **Desktop** | 1440px+ | Centered, max-width | Optimal reading widths, hover states |

### Cross-Platform Compatibility

The application is optimized for various platforms:

#### iOS Safari & WebView
```css
/* Prevent zoom on form focus - iOS Safari quirk */
input, select, textarea {
  font-size: 16px; /* Minimum to prevent zoom */
}

/* Handle iOS safe areas */
.app-container {
  padding-top: env(safe-area-inset-top);
  padding-bottom: env(safe-area-inset-bottom);
}

/* iOS momentum scrolling */
.scrollable-content {
  -webkit-overflow-scrolling: touch;
  overflow-scrolling: touch;
}
```

#### Android WebView
```css
/* Handle Android WebView font scaling */
body {
  -webkit-text-size-adjust: 100%;
  text-size-adjust: 100%;
}

/* Android WebView specific performance */
.performance-sensitive {
  /* Force hardware acceleration */
  transform: translateZ(0);
  
  /* Reduce paint complexity */
  isolation: isolate;
}
```

#### Desktop Browsers
Cross-browser consistency is maintained through modern CSS with appropriate fallbacks.

### Accessibility Considerations

The application meets WCAG 2.1 AA compliance through:

#### Color Contrast Requirements
All color combinations meet the 4.5:1 contrast ratio required by WCAG 2.1 AA.

#### Focus Management
```css
/* Visible focus indicators */
.salt-input:focus,
.salt-button:focus {
  outline: 2px solid var(--brand-color-primary);
  outline-offset: 2px;
}

/* Skip to content link */
.skip-to-main {
  position: absolute;
  top: -40px;
  left: 6px;
  background: var(--brand-color-primary);
  color: white;
  padding: 8px;
  text-decoration: none;
  transition: top 0.3s;
}

.skip-to-main:focus {
  top: 6px;
}
```

#### Screen Reader Optimization
Semantic HTML structure with appropriate ARIA roles and attributes is used throughout the application.

#### Keyboard Navigation
Complete keyboard support is implemented for all interactive elements.

## Technical Implementation

### Technologies and Frameworks

Based on the project structure and documentation:

- **Core Framework**: React with TypeScript
- **UI Components**: Custom components with possible integration of Salt Design System
- **Virtual List**: React-Virtualized for efficient rendering
- **Styling**: CSS with custom properties for theming

### Performance Optimization

#### React-Virtualized Benefits

The application uses React-Virtualized for efficient rendering of the financial institution list:

- **Memory Reduction**: 90% reduction in DOM memory usage
- **Scroll Performance**: Consistent 60fps across device ranges
- **Battery Impact**: 40% less CPU usage during scrolling on mobile

#### CSS Performance Patterns

```css
.fi-item {
  /* Trigger hardware acceleration for smooth animations */
  transform: translateZ(0);
  will-change: transform; /* Hint to browser for optimization */
}

.fi-item:hover {
  /* Use transform instead of changing properties */
  transform: translateY(-2px) translateZ(0);
}
```

#### Layout Stability

```css
.oauth-status-card {
  /* Prevent layout shifts during loading states */
  min-height: 400px;
  
  /* Contain layout calculations */
  contain: layout style;
}
```

### State Management

The application uses a combination of local component state and React context:

#### Local State with Context

```tsx
// Theme state managed in context
const BrandingThemeContext = createContext<ThemeContextType | undefined>(undefined);

// Form state managed locally with validation
const [formData, setFormData] = useState<FormData>({});
const [errors, setErrors] = useState<ValidationErrors>({});
const [isSubmitting, setIsSubmitting] = useState(false);
```

#### Async State Handling

```tsx
// Consistent async state pattern
const handleAsyncAction = async () => {
  setIsLoading(true);
  setError(null);
  
  try {
    const result = await performAction();
    onSuccess(result);
  } catch (error) {
    setError(error);
    logError(error); // Analytics/debugging
  } finally {
    setIsLoading(false);
  }
};
```

### CSS Strategy

The application implements a robust CSS strategy using custom properties for theming:

#### Theme Integration

```css
/* Component styles use CSS custom properties with fallbacks */
.fi-item {
  background-color: var(--brand-color-background, var(--salt-container-primary-background));
  border-color: var(--brand-color-accent, var(--salt-separable-primary-separable));
  color: var(--brand-color-text-primary, var(--salt-content-primary-foreground));
}
```

#### Runtime Theme Switching

```tsx
// BrandingThemeProvider.tsx
const applyCSSVariables = (theme: ClientTheme | null) => {
  const root = document.documentElement;
  
  if (theme) {
    // Apply all theme values as CSS custom properties
    root.style.setProperty('--brand-color-primary', theme.colors.primary);
    root.style.setProperty('--brand-font-family', theme.typography.fontFamily);
    // ... 40+ properties
  } else {
    // Reset to Salt Design System defaults
    customProperties.forEach(property => {
      root.style.removeProperty(property);
    });
  }
};
```

### Error Handling

The application implements sophisticated error handling with user-friendly messaging:

```tsx
const getUserFriendlyErrorMessage = (error: OAuthError | null): { 
  title: string; 
  message: string; 
  actionable: boolean 
} => {
  switch (error.error) {
    case 'popup_blocked':
      return {
        title: 'Popup Blocked',
        message: 'Your browser blocked the authentication popup...',
        actionable: true
      };
    case 'bank_maintenance':
      return {
        title: 'Bank Maintenance',
        message: `${error.institutionName} is currently undergoing maintenance...`,
        actionable: false // User can't retry during maintenance
      };
  }
};
```

Error tracking is implemented for analytics and debugging:

```tsx
// Comprehensive error logging
const logError = (error: Error, context: Record<string, any>) => {
  console.group('🐛 Error Report');
  console.log('Error:', error.message);
  console.log('Stack:', error.stack);
  console.log('Context:', context);
  console.log('User Agent:', navigator.userAgent);
  console.log('Timestamp:', new Date().toISOString());
  console.groupEnd();
  
  // In production: send to analytics service
  if (process.env.NODE_ENV === 'production') {
    analyticsService.trackError(error, context);
  }
};
```

## Security Considerations

### Data Protection

Based on the design philosophy of "Security-Conscious Design," the application:

- Implements clear visual hierarchy emphasizing security elements
- Provides prominent security indicators and messaging
- Uses transparent data usage communication
- Implements error handling that doesn't expose sensitive information

### Authentication and Authorization

The application handles OAuth flows securely, with appropriate error handling and user guidance. While specific security implementation details are not explicitly covered in the reference documentation, the application appears to follow security best practices for handling financial data.

## Testing Strategy

While the reference documentation does not explicitly cover testing, a comprehensive testing strategy for this application should include:

- Unit testing of individual components
- Integration testing of component interactions
- End-to-end testing of the complete flow
- Cross-browser and cross-device testing
- Accessibility testing
- Performance testing

## Deployment and Infrastructure

The reference documentation does not provide specific details about deployment and infrastructure. However, as a React application, standard deployment options would include:

- Static site hosting (AWS S3, Netlify, Vercel)
- Container-based deployments
- Server-side rendering options if applicable

## Monitoring and Analytics

The application includes performance metrics collection:

```tsx
// SuccessScreen.tsx - Completion time tracking
const prepareLinkingDetails = useCallback((): AccountLinkingDetails => {
  const completionTime = performance.now(); // Track from flow start
  
  return {
    // ... other details
    metadata: {
      completionTime: completionTime,
      userAgent: navigator.userAgent,
      // ... performance metrics
    }
  };
}, []);
```

## Appendices

### Component Composition Patterns

The application uses several component composition patterns:

#### Higher-Order Component Pattern

```tsx
// Consistent screen wrapper
const ScreenLayout: React.FC<{ children: ReactNode; title: string }> = ({ 
  children, 
  title 
}) => (
  <main className="screen-layout" role="main" aria-labelledby="screen-title">
    <h1 id="screen-title" className="screen-title">{title}</h1>
    {children}
  </main>
);
```

#### Render Props for Complex Logic

```tsx
// Virtualized list with render props
<AutoSizer>
  {({ height, width }) => (
    <List
      height={height}
      width={width}
      rowRenderer={({ index, key, style }) => (
        <FIListItem 
          key={key}
          style={style}
          fi={displayedFIs[index]}
          onClick={handleFISelect}
        />
      )}
    />
  )}
</AutoSizer>
```

---

**Document End**
