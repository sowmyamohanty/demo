# Bank Account Linking Experience - Technical Implementation Guide V5.0

**Document Version:** 5.0  
**Date:** August 27, 2025  
**Focus:** Technical Design Patterns and Implementation Guidance  
**Status:** Draft

## Table of Contents
1. [Technical Architecture Overview](#1-technical-architecture-overview)
2. [Design Patterns and Principles](#2-design-patterns-and-principles)
3. [Component Architecture Strategy](#3-component-architecture-strategy)
4. [State Management Approach](#4-state-management-approach)
5. [API Integration Design](#5-api-integration-design)
6. [Security Implementation Strategy](#6-security-implementation-strategy)
7. [Performance Optimization Techniques](#7-performance-optimization-techniques)
8. [Error Handling Architecture](#8-error-handling-architecture)
9. [Testing Implementation Strategy](#9-testing-implementation-strategy)
10. [Deployment and Infrastructure Design](#10-deployment-and-infrastructure-design)

## 1. Technical Architecture Overview

### 1.1 System Design Philosophy
The Bank Account Linking Experience follows a **micro-frontend architecture** embedded within merchant applications through secure iframe integration. The system emphasizes:

- **Separation of Concerns**: Each component handles a specific responsibility
- **Loose Coupling**: Components communicate through well-defined interfaces
- **High Cohesion**: Related functionality is grouped together
- **Extensibility**: New FI types and authentication methods can be added without major refactoring

### 1.2 Architectural Layers

#### Presentation Layer
- **React Components**: Modular UI components using Salt Design System
- **State Containers**: Context-based state management with custom hooks
- **Event Handlers**: User interaction processing and validation
- **Responsive Layouts**: Mobile-first responsive design implementation

#### Business Logic Layer
- **Flow Controllers**: Step-by-step process orchestration
- **Validation Services**: Input validation and business rule enforcement
- **Analytics Services**: User behavior tracking and performance monitoring
- **Error Management**: Centralized error handling and recovery

#### Data Access Layer
- **API Clients**: RESTful API communication with retry logic
- **Session Management**: Secure session handling and persistence
- **Cache Management**: Strategic caching for performance optimization
- **State Persistence**: Local storage management for session continuity

#### External Integration Layer
- **Mastercard Connect**: Legacy and OAuth authentication integration
- **Micro-deposit Services**: Manual account verification handling
- **Merchant Communication**: PostMessage API for secure iframe communication

### 1.3 Technology Stack Decision Matrix

| Component | Technology | Rationale |
|-----------|------------|-----------|
| Frontend Framework | React 18+ | Component reusability, strong ecosystem, concurrent features |
| Type System | TypeScript | Type safety, better IDE support, reduced runtime errors |
| Design System | Salt DS | Consistent UI, accessibility built-in, JPMorgan standard |
| State Management | Context + Hooks | Lightweight, no external dependencies, React-native |
| Build Tool | Webpack 5 | Module federation support, advanced optimization |
| Testing | Jest + RTL | Industry standard, good React integration |

## 2. Design Patterns and Principles

### 2.1 Component Design Patterns

#### Container-Presenter Pattern
**Implementation Strategy:**
- **Container Components**: Handle business logic, API calls, and state management
- **Presenter Components**: Focus solely on rendering and user interactions
- **Benefits**: Clear separation of concerns, easier testing, better reusability

#### Higher-Order Components (HOCs)
**Use Cases:**
- **withErrorBoundary**: Wrap components with error handling
- **withAnalytics**: Add automatic event tracking
- **withLoading**: Provide consistent loading states
- **withAuth**: Handle authentication state checking

#### Render Props Pattern
**Implementation Areas:**
- **VirtualizedList**: Flexible list rendering with performance optimization
- **FormValidation**: Reusable form validation logic
- **ApiData**: Generic data fetching and caching

#### Custom Hooks Pattern
**Hook Categories:**
- **Data Hooks**: API interaction and caching logic
- **State Hooks**: Complex state management logic
- **Effect Hooks**: Side effect management (timers, event listeners)
- **Utility Hooks**: Common utility functions (debouncing, local storage)

### 2.2 State Management Patterns

#### Flux-like Unidirectional Data Flow
**Implementation Approach:**
- **Actions**: Define all possible state changes as discrete actions
- **Reducers**: Pure functions handling state transitions
- **Context Providers**: Distribute state and dispatch functions
- **Selectors**: Derived state calculation and memoization

#### State Normalization
**Data Structure Design:**
- **Entities**: Normalize complex objects (FIs, accounts, sessions)
- **IDs Arrays**: Reference entities by ID for efficient updates
- **Derived State**: Calculate UI state from normalized data
- **State Slicing**: Separate concerns into domain-specific state slices

### 2.3 API Communication Patterns

#### Repository Pattern
**Design Structure:**
- **Abstract Interfaces**: Define contracts for data operations
- **Concrete Implementations**: Specific API clients for different services
- **Data Mapping**: Transform API responses to domain models
- **Caching Layer**: Implement intelligent caching strategies

#### Command Pattern
**Use Cases:**
- **API Operations**: Encapsulate API calls as executable commands
- **Retry Logic**: Implement sophisticated retry mechanisms
- **Undo/Redo**: Support for reversible operations
- **Queue Management**: Handle offline scenarios and request queuing

## 3. Component Architecture Strategy

### 3.1 Screen Component Structure

#### Hierarchical Component Design
```
AccountLinkingContainer
├── SessionManager (HOC)
├── ErrorBoundary (HOC)
├── StepIndicator
└── ScreenRouter
    ├── ConsentScreen
    │   ├── ConsentForm
    │   └── TermsAccordion
    ├── FISelectionScreen
    │   ├── SearchInput
    │   ├── PopularFIGrid
    │   ├── VirtualizedFIList
    │   └── ManualLinkOption
    ├── AuthenticationScreen
    │   ├── LegacyAuthView
    │   ├── OAuthAuthView
    │   └── AuthStatusIndicator
    ├── ManualLinkingScreen
    │   ├── AccountDetailsForm
    │   ├── MicroDepositChallenge
    │   └── ValidationFeedback
    ├── AccountSelectionScreen
    │   ├── AccountList
    │   ├── AccountCard
    │   └── SelectionSummary
    └── SuccessScreen
        ├── SuccessAnimation
        └── RedirectCountdown
```

#### Component Responsibility Matrix

| Component Type | Responsibilities | Dependencies |
|----------------|------------------|-------------|
| Screen Components | Flow orchestration, step transitions | Context, navigation hooks |
| Form Components | Input handling, validation, submission | Validation hooks, API clients |
| Display Components | Data presentation, user feedback | Formatting utilities |
| Container Components | Data fetching, business logic | API services, state management |
| Layout Components | Responsive design, accessibility | Design system, media queries |

### 3.2 Component Communication Strategies

#### Props Drilling Mitigation
**Techniques:**
- **Context Providers**: Share common data across component trees
- **Compound Components**: Group related components with shared state
- **Render Props**: Pass dynamic content and behavior
- **Custom Hooks**: Share stateful logic without component nesting

#### Event-Driven Communication
**Implementation Patterns:**
- **Custom Events**: Cross-component communication via DOM events
- **Event Emitters**: Pub-sub pattern for loose coupling
- **Callback Props**: Direct parent-child communication
- **Context Actions**: Centralized action dispatching

### 3.3 Performance Optimization Strategies

#### Rendering Optimization
**Techniques:**
- **React.memo**: Prevent unnecessary re-renders of pure components
- **useMemo/useCallback**: Memoize expensive calculations and functions
- **Lazy Loading**: Code-split components loaded on demand
- **Virtual Scrolling**: Efficient rendering of large lists

#### Bundle Optimization
**Strategies:**
- **Code Splitting**: Route-based and component-based splitting
- **Tree Shaking**: Remove unused code from bundles
- **Dynamic Imports**: Load modules on demand
- **Asset Optimization**: Image optimization and compression

## 4. State Management Approach

### 4.1 State Architecture Design

#### Global State Structure
**State Domains:**
- **Session State**: Authentication, session validity, user context
- **UI State**: Current screen, loading states, error conditions
- **Business State**: Selected FI, account details, linking progress
- **Cache State**: API responses, computed values, temporary data

#### State Persistence Strategy
**Persistence Levels:**
- **Session Storage**: Temporary data for current session
- **Local Storage**: User preferences and non-sensitive cache
- **Memory Only**: Sensitive data that shouldn't persist
- **Server Sync**: Critical state synchronized with backend

### 4.2 State Transition Management

#### Finite State Machine Design
**State Machine Benefits:**
- **Predictable Transitions**: Clear rules for state changes
- **Error Prevention**: Invalid transitions are impossible
- **Debugging Support**: Easy to trace state changes
- **Testing Simplification**: Deterministic state behavior

#### Action Design Patterns
**Action Categories:**
- **Synchronous Actions**: Immediate state updates
- **Asynchronous Actions**: API calls with loading/success/error states
- **Optimistic Actions**: UI updates before server confirmation
- **Rollback Actions**: Revert failed optimistic updates

### 4.3 State Synchronization

#### Server-Client Sync Strategies
**Synchronization Approaches:**
- **Polling**: Regular server state checking
- **WebSocket**: Real-time bidirectional communication
- **Event-Driven**: Server-sent events for state updates
- **Optimistic Updates**: Client-first with server reconciliation

#### Conflict Resolution
**Conflict Handling:**
- **Last-Write-Wins**: Simple timestamp-based resolution
- **Version Vectors**: Track concurrent modifications
- **Merge Strategies**: Intelligent conflict resolution
- **User Intervention**: Manual conflict resolution UI

## 5. API Integration Design

### 5.1 API Client Architecture

#### Service Layer Design
**Service Organization:**
- **Domain Services**: Business-specific API operations (FI, Account, Auth)
- **Infrastructure Services**: Cross-cutting concerns (HTTP, Cache, Analytics)
- **Utility Services**: Helper functions and data transformations
- **Mock Services**: Testing and development support

#### Request/Response Handling
**Processing Pipeline:**
- **Request Interceptors**: Authentication, logging, request transformation
- **Response Interceptors**: Error handling, data transformation, caching
- **Retry Logic**: Exponential backoff, circuit breaker patterns
- **Timeout Management**: Request timeout and cancellation handling

### 5.2 API Integration Patterns

#### Adapter Pattern Implementation
**Adapter Use Cases:**
- **Third-Party APIs**: Normalize different API response formats
- **Version Compatibility**: Handle API version differences
- **Protocol Translation**: REST to GraphQL, WebSocket to REST
- **Mock Integration**: Development and testing environments

#### Circuit Breaker Pattern
**Implementation Strategy:**
- **Failure Threshold**: Configure failure rate limits
- **Timeout Configuration**: Set appropriate timeout values
- **Recovery Testing**: Periodic health checks
- **Fallback Mechanisms**: Alternative service responses

### 5.3 Data Transformation Pipeline

#### Response Normalization
**Normalization Steps:**
- **Schema Validation**: Ensure response structure consistency
- **Data Mapping**: Transform API data to domain models
- **Type Conversion**: Handle data type inconsistencies
- **Error Standardization**: Normalize error response formats

#### Caching Strategy Design
**Caching Levels:**
- **HTTP Caching**: Browser-level response caching
- **Application Caching**: In-memory data storage
- **Persistent Caching**: Local storage for offline support
- **CDN Caching**: Static asset distribution

## 6. Security Implementation Strategy

### 6.1 Client-Side Security Measures

#### Content Security Policy (CSP)
**CSP Configuration Strategy:**
- **Directive Definition**: Specify allowed resource sources
- **Nonce Implementation**: Dynamic script and style validation
- **Report Monitoring**: Track CSP violations
- **Progressive Enhancement**: Gradual CSP tightening

#### iframe Security
**Security Considerations:**
- **Sandbox Attributes**: Restrict iframe capabilities
- **Origin Validation**: Verify parent window origin
- **PostMessage Validation**: Secure cross-frame communication
- **Clickjacking Protection**: Prevent UI redressing attacks

### 6.2 Data Protection Strategies

#### Sensitive Data Handling
**Data Classification:**
- **Public Data**: No special handling required
- **Internal Data**: Encrypted transmission only
- **Confidential Data**: Memory-only storage
- **Restricted Data**: No client-side storage

#### Session Security
**Security Measures:**
- **Token Management**: Secure token storage and transmission
- **Session Timeout**: Automatic session expiration
- **Cross-Site Protection**: CSRF token implementation
- **Secure Communication**: HTTPS enforcement

### 6.3 Authentication Integration Security

#### Mastercard Connect Security
**Security Implementation:**
- **Token Validation**: Verify authentication tokens
- **Callback Validation**: Secure callback URL handling
- **SSL Pinning**: Certificate validation for API calls
- **Rate Limiting**: Prevent abuse and DOS attacks

#### OAuth Security Best Practices
**OAuth Implementation:**
- **PKCE Implementation**: Proof Key for Code Exchange
- **State Parameter**: Prevent CSRF attacks
- **Redirect URI Validation**: Secure callback handling
- **Token Storage**: Secure token management

## 7. Performance Optimization Techniques

### 7.1 Frontend Performance Strategy

#### Rendering Performance
**Optimization Techniques:**
- **Component Memoization**: Prevent unnecessary re-renders
- **State Localization**: Keep state close to where it's used
- **Lazy Initialization**: Defer expensive operations
- **Batched Updates**: Group state changes efficiently

#### Network Performance
**Optimization Strategies:**
- **Request Batching**: Combine multiple API calls
- **Response Compression**: Gzip/Brotli compression
- **Resource Prefetching**: Anticipate user needs
- **Connection Pooling**: Reuse HTTP connections

### 7.2 List Virtualization Implementation

#### Virtual Scrolling Strategy
**Implementation Approach:**
- **Viewport Calculation**: Determine visible items
- **Buffer Management**: Pre-render items for smooth scrolling
- **Dynamic Height**: Handle variable item heights
- **Keyboard Navigation**: Maintain accessibility

#### Search Performance
**Optimization Techniques:**
- **Debouncing**: Reduce API call frequency
- **Client-Side Filtering**: Fast local search
- **Result Caching**: Store previous search results
- **Incremental Search**: Progressive result loading

### 7.3 Memory Management

#### Memory Leak Prevention
**Prevention Strategies:**
- **Event Listener Cleanup**: Remove event listeners on unmount
- **Timer Management**: Clear intervals and timeouts
- **Subscription Cleanup**: Unsubscribe from observables
- **Reference Management**: Avoid circular references

#### Cache Management
**Caching Strategy:**
- **Cache Size Limits**: Prevent unbounded growth
- **LRU Eviction**: Remove least recently used items
- **Cache Invalidation**: Handle stale data removal
- **Memory Monitoring**: Track cache memory usage

## 8. Error Handling Architecture

### 8.1 Error Classification System

#### Error Categories
**Error Types:**
- **Network Errors**: Connection issues, timeouts, server errors
- **Validation Errors**: Input validation failures
- **Business Logic Errors**: Rule violations, invalid operations
- **System Errors**: Runtime exceptions, memory issues
- **User Errors**: Invalid user actions, canceled operations

#### Error Severity Levels
**Severity Classification:**
- **Critical**: Application cannot continue
- **High**: Major functionality impacted
- **Medium**: Minor functionality impacted
- **Low**: Cosmetic issues, warnings
- **Info**: Informational messages

### 8.2 Error Recovery Strategies

#### Graceful Degradation
**Degradation Techniques:**
- **Feature Fallbacks**: Alternative functionality when primary fails
- **Progressive Enhancement**: Core functionality always available
- **Offline Support**: Continue operation without network
- **Cached Data**: Use stale data when fresh data unavailable

#### User Experience During Errors
**UX Strategies:**
- **Clear Error Messages**: User-friendly error descriptions
- **Recovery Actions**: Provide clear next steps
- **Retry Mechanisms**: Allow users to retry failed operations
- **Alternative Paths**: Offer different ways to complete tasks

### 8.3 Error Reporting and Monitoring

#### Error Tracking Implementation
**Tracking Strategy:**
- **Error Boundaries**: Catch React component errors
- **Global Error Handler**: Catch uncaught JavaScript errors
- **API Error Tracking**: Monitor API call failures
- **User Action Context**: Capture user actions leading to errors

#### Monitoring and Alerting
**Monitoring Approach:**
- **Real-Time Alerts**: Immediate notification of critical errors
- **Error Dashboards**: Visual error trend analysis
- **Performance Metrics**: Track error impact on performance
- **User Impact Analysis**: Measure error effect on user experience

## 9. Testing Implementation Strategy

### 9.1 Testing Pyramid Implementation

#### Unit Testing Strategy
**Testing Approach:**
- **Component Testing**: Test individual components in isolation
- **Hook Testing**: Test custom hooks independently
- **Utility Testing**: Test pure functions and helpers
- **Service Testing**: Test API clients with mocked responses

#### Integration Testing Strategy
**Testing Scope:**
- **Component Integration**: Test component interactions
- **API Integration**: Test real API communications
- **Flow Integration**: Test complete user workflows
- **Third-Party Integration**: Test external service integrations

### 9.2 Testing Tools and Techniques

#### Mock Implementation Strategy
**Mocking Approaches:**
- **API Mocking**: Mock external API responses
- **Service Mocking**: Mock internal service dependencies
- **Component Mocking**: Mock child components for isolation
- **Timer Mocking**: Mock time-dependent functionality

#### Test Data Management
**Data Strategy:**
- **Test Fixtures**: Predefined test data sets
- **Factory Functions**: Generate test data programmatically
- **Database Seeding**: Prepare test database state
- **Snapshot Testing**: Track component output changes

### 9.3 End-to-End Testing Implementation

#### E2E Testing Strategy
**Testing Scenarios:**
- **Happy Path Testing**: Test successful user flows
- **Error Scenario Testing**: Test error handling and recovery
- **Cross-Browser Testing**: Ensure compatibility across browsers
- **Performance Testing**: Test application performance under load

#### Accessibility Testing
**Testing Approach:**
- **Automated Scanning**: Use tools to detect accessibility issues
- **Keyboard Navigation**: Test keyboard-only usage
- **Screen Reader Testing**: Test with assistive technologies
- **Color Contrast Testing**: Ensure adequate contrast ratios

## 10. Deployment and Infrastructure Design

### 10.1 Deployment Architecture

#### Container Strategy
**Containerization Approach:**
- **Multi-Stage Builds**: Optimize container size and security
- **Base Image Selection**: Choose appropriate base images
- **Security Scanning**: Scan containers for vulnerabilities
- **Registry Management**: Secure container registry usage

#### Environment Management
**Environment Strategy:**
- **Configuration Management**: Environment-specific configurations
- **Secret Management**: Secure handling of sensitive data
- **Feature Flags**: Control feature rollout across environments
- **Database Migrations**: Handle schema changes safely

### 10.2 Scaling and Performance

#### Horizontal Scaling
**Scaling Strategy:**
- **Load Balancing**: Distribute traffic across instances
- **Session Stickiness**: Handle stateful session requirements
- **Database Scaling**: Scale database read/write operations
- **Cache Scaling**: Distribute cache across multiple nodes

#### Performance Monitoring
**Monitoring Strategy:**
- **Application Metrics**: Track application-specific metrics
- **Infrastructure Metrics**: Monitor server and network performance
- **User Experience Metrics**: Track real user performance
- **Business Metrics**: Monitor business KPIs and conversions

### 10.3 Reliability and Availability

#### Disaster Recovery
**Recovery Strategy:**
- **Backup Procedures**: Regular data and configuration backups
- **Recovery Testing**: Regular disaster recovery drills
- **Failover Mechanisms**: Automatic failover to backup systems
- **Data Replication**: Geographic data distribution

#### Monitoring and Alerting
**Monitoring Implementation:**
- **Health Checks**: Application and infrastructure health monitoring
- **Log Aggregation**: Centralized logging for debugging
- **Alert Configuration**: Proactive alerting for issues
- **Incident Response**: Defined procedures for handling incidents

---

This technical implementation guide provides comprehensive design patterns and strategies for building the Bank Account Linking Experience without overwhelming developers with complete code implementations. Each section focuses on design decisions, architectural patterns, and implementation strategies that guide development while maintaining flexibility for specific implementation choices.
